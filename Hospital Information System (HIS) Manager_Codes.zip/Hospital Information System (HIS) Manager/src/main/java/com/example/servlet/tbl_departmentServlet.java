package com.example.servlet;

import com.example.dao.ConstantItemDao;
import com.example.dao.ConstanttypeDao;
import com.example.dao.DepartmentDao;
import com.example.model.ConstantItem;
import com.example.model.Constanttype;
import com.example.model.Department;
import com.example.model.DiseCategory;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "tbl_departmentServlet", value = "/tbl_departmentServlet")
public class tbl_departmentServlet extends HttpServlet {

    //2.创建数据库访问层对象
    DepartmentDao departmentdao = new DepartmentDao();
    ConstantItemDao constantitemdao = new ConstantItemDao();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request,response);
    }

    /**前端控制器 执行科室添加删除。。。工作
     * 添加方法addmethod
     * updatemethod
     * deletemethod
     * 根据主键查询科室信息:findid
     * 默认执行：查询全部信息
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String methodname = request.getParameter("method");
        if("addmethod".equals(methodname)){
            //添加操作
            addDepartment(request,response);
        }else if("updatemethod".equals(methodname)){

            //修改
            updateDepartment(request,response);
        }else if("deletemethod".equals(methodname)){

            //删除
            deleteDepartmentById(request,response);
        }else if("findid".equals(methodname)){

            //按照特定id查找
            findDepartmentById(request,response);


        }else if("addinput".equals(methodname)){

            addinput(request,response);
        }else{

            //执行全部操作
            findAll(request,response);

        }


    }
    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */

    protected void addDepartment(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取客户端科室信息 deptcode ,deptname  , deptcategoryid ,depttype
        String tbl_departmentCode = request.getParameter("deptcode");
        String tbl_departmentName = request.getParameter("deptname");
        int tbl_departmentCid = Integer.parseInt(request.getParameter("deptcategoryid"));


        //创建department对象
        Department department = new Department();
        department.setDeptcode(tbl_departmentCode);
        department.setDeptname(tbl_departmentName);
        department.setDeptcategoryid(tbl_departmentCid);

        //3.调取数据库访问层中的
        departmentdao.addDepartment(department);


        //4.跳转到成功页面
        findAll(request,response);


    }
    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */

    protected void updateDepartment(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取客户端科室信息 deptcode ,deptname  , deptcategoryid ,depttype
        int id = Integer.parseInt(request.getParameter("id"));
        String tbl_departmentCode = request.getParameter("deptcode");
        String tbl_departmentName = request.getParameter("deptname");
        int tbl_departmentCid = Integer.parseInt(request.getParameter("deptcategoryid"));


        //创建department对象
        Department department = new Department();
        department.setId(id);
        department.setDeptcode(tbl_departmentCode);
        department.setDeptname(tbl_departmentName);
        department.setDeptcategoryid(tbl_departmentCid);

        //3.调取数据库访问层中的修改方法
        departmentdao.updateDepartment(department);


        //4.跳转到成功页面
       findAll(request,response);


    }
    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void deleteDepartmentById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        //1。获取科室编号
        int deptid = Integer.parseInt(request.getParameter("did"));
        //2.调用
        departmentdao.deleteDepartment(deptid);
        //3.跳转到修改页面
        findAll(request,response);

    }


    /**
     *功能：根据编号查询科室信息
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void findDepartmentById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {//1获取科室编号
        int deptid = Integer.parseInt(request.getParameter("deptid"));
        //2.调用数据库访问层中编号查询信息的方法
        Department department = departmentdao.findDepartmentByID(deptid);
        //3.跳转到修改显示页面
        request.setAttribute("deptobj",department);
        List<ConstantItem> constantitems = constantitemdao.findAll();
        request.setAttribute("constantitemObjs",constantitems);
        request.getRequestDispatcher("/system/updatedepartment.jsp").forward(request,response);

    }

    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void findAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {

        List<Department> departments = departmentdao.findAll();
        request.setAttribute("departmentObjs",departments);
        request.getRequestDispatcher("/system/displaydepartment.jsp").forward(request,response);

    }

    protected void addinput(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        List<ConstantItem> constantitems = constantitemdao.findAll();
        request.setAttribute("constantitemObjs",constantitems);
        request.getRequestDispatcher("/system/adddepartment.jsp").forward(request,response);


    }


}
