package com.example.servlet;

import com.example.dao.ConstantItemDao;
import com.example.dao.ConstanttypeDao;
import com.example.model.ConstantItem;
import com.example.model.Constanttype;
import com.example.model.Department;


import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "tbl_constantitemServlet", value = "/tbl_constantitemServlet")
public class tbl_constantitemServlet extends HttpServlet {


    //2.创建数据库访问层对象
    ConstanttypeDao constanttypeDao = new ConstanttypeDao();
    ConstantItemDao constantitemdao = new ConstantItemDao();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request, response);
    }

    /**
     * 前端控制器 执行科室添加删除。。。工作
     * 添加方法addmethod
     * updatemethod
     * deletemethod
     * 根据主键查询科室信息:findid
     * 默认执行：查询全部信息
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String methodname = request.getParameter("method");
        if ("addmethod".equals(methodname)) {
            //添加操作
            addConstantItem(request, response);
        } else if ("updatemethod".equals(methodname)) {

            //修改
            updateConstantItem(request, response);
        } else if ("deletemethod".equals(methodname)) {

            //删除
            deleteConstantItemById(request, response);

        } else if ("findid".equals(methodname)) {

            //按照特定id查找
            findConstantItemById(request, response);
        } else if ("addinput".equals(methodname)) {
            addinput(request, response);
        } else {

            //执行全部操作
            findAll(request, response);

        }


    }


    protected void addConstantItem(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取客户端科室信息 constanttypeid,constantcode,constantname
        int tbl_constanttypeid = Integer.parseInt(request.getParameter("constanttypeid"));
        String tbl_constantcode = request.getParameter("constantcode");
        String tbl_constantname = request.getParameter("constantname");


        //创建constantitem对象
        ConstantItem constantitem = new ConstantItem();
        constantitem.setConstanttypeid(tbl_constanttypeid);
        constantitem.setConstantcode(tbl_constantcode);
        constantitem.setConstantname(tbl_constantname);

        //3.调取数据库访问层中的
        constantitemdao.addConstantItem(constantitem);


        //4.跳转到成功页面
        findAll(request, response);

    }

    /**
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void updateConstantItem(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取客户端科室信息 constanttypeid,constantcode,constantname
        int id = Integer.parseInt(request.getParameter("id"));
        int tbl_constanttypeid = Integer.parseInt(request.getParameter("constanttypeid"));
        String tbl_constantcode = request.getParameter("constantcode");
        String tbl_constantname = request.getParameter("constantname");

        //创建constantitem对象
        ConstantItem constantitem = new ConstantItem();
        constantitem.setId(id);
        constantitem.setConstanttypeid(tbl_constanttypeid);
        constantitem.setConstantcode(tbl_constantcode);
        constantitem.setConstantname(tbl_constantname);

        //3.调取数据库访问层中的
        constantitemdao.updateConstantItem(constantitem);


        //4.跳转到成功页面
        findAll(request, response);

    }


    /**
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void deleteConstantItemById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1。获取科室编号
        int constantitemid = Integer.parseInt(request.getParameter("did"));
        //2.调用
        constantitemdao.deleteConstantItem(constantitemid);
        //3.跳转到修改页面
        findAll(request, response);

    }

    /**
     * 功能：根据编号查询科室信息
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void findConstantItemById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {//1获取科室编号
        int constantitemid = Integer.parseInt(request.getParameter("constantitemid"));
        //2.调用数据库访问层中编号查询信息的方法
        ConstantItem constantitem = constantitemdao.findConstantItemByID(constantitemid);
        //3.跳转到修改显示页面
        request.setAttribute("constantObjs", constantitem);
        List<Constanttype> constanttypes = constanttypeDao.findAll();
        //2.存储部门信息
        request.setAttribute("contobj", constanttypes);

        request.getRequestDispatcher("/system/updateconstantitem.jsp").forward(request, response);

    }


    /**
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void findAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        List<ConstantItem> constantitems = constantitemdao.findAll();
        request.setAttribute("constantitemObjs", constantitems);
        request.getRequestDispatcher("/system/displayconstantitem.jsp").forward(request, response);


    }

    protected void addinput(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.调用数据库访问层中的查询方法
        List<Constanttype> constanttypes = constanttypeDao.findAll();
        //2.存储部门信息
        request.setAttribute("contobj", constanttypes);
        //List<DepartmentLevel> departmentLevels = departmentLevelDao.findAll();
        //2.存储部门信息
        //request.setAttribute("departmentLevelObjs",departmentLevels);
        request.getRequestDispatcher("/system/addconstantitem.jsp").forward(request, response);
    }

}