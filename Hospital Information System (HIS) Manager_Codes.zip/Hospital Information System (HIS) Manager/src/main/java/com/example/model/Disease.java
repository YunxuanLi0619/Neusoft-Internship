package com.example.model;

/**
 * 实体类--科室
 */
public class Disease{
    //id, deptcode,deptname,  depttype
    private Integer id;
    private String diseasecode;
    private String diseasename;
    private String diseaseicd;
    private Integer diseasecategory;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDiseasecode() {
        return diseasecode;
    }

    public void setDiseasecode(String diseasecode) {
        this.diseasecode = diseasecode;
    }

    public String getDiseasename() {
        return diseasename;
    }

    public void setDiseasename(String diseasename) {
        this.diseasename = diseasename;
    }

    public String getDiseaseicd() {
        return diseaseicd;
    }

    public void setDiseaseicd(String diseaseicd) {
        this.diseaseicd = diseaseicd;
    }

    public Integer getDiseasecategory() {
        return diseasecategory;
    }

    public void setDiseasecategory(Integer diseasecategory) {
        this.diseasecategory = diseasecategory;
    }

    @Override
    public String toString() {
        return "Disease{" +
                "id=" + id +
                ", diseasecode='" + diseasecode + '\'' +
                ", diseasename='" + diseasename + '\'' +
                ", diseaseicd='" + diseaseicd + '\'' +
                ", diseasecategory=" + diseasecategory +
                '}';
    }
}
