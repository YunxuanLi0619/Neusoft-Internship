package com.example.model;

public class ConstantItem {

    private Integer id;
    private Integer constanttypeid;
    private String constantcode;
    private String constantname;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getConstanttypeid() {
        return constanttypeid;
    }

    public void setConstanttypeid(Integer constanttypeid) {
        this.constanttypeid = constanttypeid;
    }

    public String getConstantcode() {
        return constantcode;
    }

    public void setConstantcode(String constantcode) {
        this.constantcode = constantcode;
    }

    public String getConstantname() {
        return constantname;
    }

    public void setConstantname(String constantname) {
        this.constantname = constantname;
    }

    @Override
    public String toString() {
        return "ConstantItem{" +
                "id=" + id +
                ", constanttypeid=" + constanttypeid +
                ", constantcode='" + constantcode + '\'' +
                ", constantname='" + constantname + '\'' +
                '}';
    }
}
