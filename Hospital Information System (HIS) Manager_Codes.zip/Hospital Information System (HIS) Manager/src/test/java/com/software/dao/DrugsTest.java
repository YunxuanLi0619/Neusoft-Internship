package com.software.dao;

import com.example.dao.DrugsDao;
import com.example.model.Drugs;
import org.junit.jupiter.api.Test;

import java.util.List;

public class DrugsTest {


    DrugsDao drugsDao = new DrugsDao();


//id,drugscode,drugsname,drugsformat,drugsunit,manufacturer,drugsdosageid,drugstypeid,drugsprice,mnemoniccode,creationdate,lastupdatedate,delmark

    @Test
    public void addMethod1() {
        Drugs drugs = new Drugs();
        drugs.setDrugscode("D00010");
        drugs.setDrugsname("头孢");
        drugs.setDrugsformat("每片10毫克");
        drugs.setDrugsunit("每盒10片");
        drugs.setManufacturer("陕西制药");
        drugs.setDrugsdosageid(15);
        drugs.setDrugstypeid(21);
        drugs.setDrugsprice(20);
        drugs.setMnemoniccode("TB");
        drugs.setCreationdate("2023-3-14");
        drugs.setLastupdatedate("2023-7-15");
        drugs.setDelmark(1);
        boolean flag = this.drugsDao.addDrugs(drugs);
        if (flag) {
            System.out.println("success");
        } else {
            System.out.println("failure");
        }

    }

    @Test
    public void updateDrugs() {
        Drugs drugs = new Drugs();
        drugs.setId(14);
        drugs.setDrugscode("D00010");
        drugs.setDrugsname("头孢");
        drugs.setDrugsformat("每片10毫克");
        drugs.setDrugsunit("每盒10片");
        drugs.setManufacturer("陕西制药");
        drugs.setDrugsdosageid(15);
        drugs.setDrugstypeid(21);
        drugs.setDrugsprice(20);
        drugs.setMnemoniccode("TB");
        drugs.setCreationdate("2023-3-14");
        drugs.setLastupdatedate("2023-7-15");
        boolean flag = this.drugsDao.updateDrugs(drugs);
        if (flag) {
            System.out.println("success");
        } else {
            System.out.println("failure");
        }

    }

    @Test
    public void deleteMethod() {
        boolean flag = this.drugsDao.deleteDrugs(13);
        if (flag) {
            System.out.println("success");
        } else {
            System.out.println("failure");
        }

    }

    @Test
    public void queryDepartment(){
        List<Drugs> drugsList =  drugsDao.findAll();
        for(Drugs drugs : drugsList){
            System.out.println(drugs);
        }

    }
}




