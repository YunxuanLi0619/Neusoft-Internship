package com.example.dao;

import com.example.model.SettleCategory;
import com.example.util.DBCPUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SettleCategoryDao {
    /**
     * 添加科室操作
     * @param settlecategory
     *
     *     private Integer id;
     *     private String settlecode;
     *     private String settlename;
     *     private Integer sequenceno;
     *     private Integer delmark;
     *
     * @return
     */
    public boolean addSettleCategory(SettleCategory settlecategory){
        boolean flag = false;
        String sql ="insert into tbl_settlecategory(settlecode,settlename,sequenceno) " +
                "values(?,?,?)";
        return DBCPUtil.execUpdate(sql,settlecategory.getSettlecode(),settlecategory.getSettlename(),
                settlecategory.getSequenceno());
    }

    /**
     * 功能：根据科室编号修改科室信息
     * @param settlecategory
     * @return
     */
    public boolean updateSettleCategory(SettleCategory settlecategory){
        boolean flag = false;
        String sql ="update tbl_settlecategory set settlecode=?,settlename=?,sequenceno=? where id=?";
        flag = DBCPUtil.execUpdate(sql,settlecategory.getSettlecode(),settlecategory.getSettlename(),
                settlecategory.getSequenceno(),settlecategory.getId());
        return flag;
    }

    /**
     * 功能：根据科室编号删除科室信息
     * @param id
     * @return
     */
    public boolean deleteSettleCategory(int id){
        boolean flag = false;
        String sql ="delete from tbl_settlecategory where id =?";
        //String sql ="update tbl_settlecategory set flag = 1,flag=now() where id=?";
        flag = DBCPUtil.execUpdate(sql,id);
        return flag;
    }




    /**
     * 功能：查询科室的所有信息
     * @return
     */
    public List<SettleCategory> findAll(){
        List<SettleCategory> settlecategorys = new ArrayList<>();
        //1.获取数据库连接对象
        Connection connection =  DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql ="select id,settlecode,settlename,sequenceno from tbl_settlecategory";
        try {
            pstmt = connection.prepareStatement(sql);
            rs = pstmt.executeQuery();
            SettleCategory settlecategory = null;
            while(rs.next()){
                settlecategory = new SettleCategory();
                int id= rs.getInt("id");
                String settlecode = rs.getString("settlecode");
                String settlename = rs.getString("settlename");
                int sequenceno = rs.getInt("sequenceno");


                //每行记录封装为一个对象
                settlecategory.setId(id);
                settlecategory.setSettlecode(settlecode);
                settlecategory.setSettlename(settlename);
                settlecategory.setSequenceno(sequenceno);


                //将对象添加到List集合中
                settlecategorys.add(settlecategory);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return settlecategorys;
    }

    public static SettleCategory findSettleCategoryByID(int setid){
        SettleCategory settlecategory = new SettleCategory();
        //1.获取数据库连接对象
        Connection connection =  DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql ="select id,settlecode,settlename,sequenceno from tbl_settlecategory where id=?";
        try {
            pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1,setid);
            rs = pstmt.executeQuery();

            if (rs.next()){

                int id= rs.getInt("id");
                String settlecode = rs.getString("settlecode");
                String settlename = rs.getString("settlename");
                int sequenceno = rs.getInt("sequenceno");


                //每行记录封装为一个对象
                settlecategory.setId(id);
                settlecategory.setSettlecode(settlecode);
                settlecategory.setSettlename(settlename);
                settlecategory.setSequenceno(sequenceno);


                //将对象添加到List集合中


            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return settlecategory;
    }
    
}
