package com.example.dao;

import com.example.model.Department;
import com.example.util.DBCPUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * 数据库访问层--科室信息的增删改查操作
 */
public class DepartmentDao {

    /**
     * 添加科室操作
     * @param department
     * @return
     */
    public boolean addDepartment(Department department){
        boolean flag = false;
        String sql ="insert into tbl_department(deptcode,deptname,deptcategoryid) " +
                "values(?,?,?)";
        return DBCPUtil.execUpdate(sql,department.getDeptcode(),department.getDeptname(),
                department.getDeptcategoryid());
    }

    /**
     * 功能：根据科室编号修改科室信息
     * @param department
     * @return
     */
    public boolean updateDepartment(Department department){
        boolean flag = false;
        String sql ="update tbl_department set deptcode=?,deptname=?,deptcategoryid=? where id=?";
        flag = DBCPUtil.execUpdate(sql,department.getDeptcode(),department.getDeptname(),department.getDeptcategoryid(),
               department.getId());
        return flag;
    }

    /**
     * 功能：根据科室编号删除科室信息
     * @param id
     * @return
     */
    public boolean deleteDepartment(int id){
        boolean flag = false;
        String sql ="delete from tbl_department where id =?";
        //String sql ="update tbl_department set delmark = 0 where id = ?";
        flag = DBCPUtil.execUpdate(sql,id);
        return flag;

    }




    /**
     * 功能：查询科室的所有信息
     * @return
     */
    public List<Department> findAll(){
        List<Department> departments = new ArrayList<>();
        //1.获取数据库连接对象
        Connection connection =  DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql ="select id,deptcode,deptname,deptcategoryid from tbl_department ";
        try {
            pstmt = connection.prepareStatement(sql);
            rs = pstmt.executeQuery();
            Department department = null;
            while(rs.next()){
                department = new Department();
                int id= rs.getInt("id");
                String deptcode = rs.getString("deptcode");
                String deptname = rs.getString("deptname");
                int deptcategoryid = rs.getInt("deptcategoryid");


                //每行记录封装为一个对象
                department.setId(id);
                department.setDeptcode(deptcode);
                department.setDeptname(deptname);
                department.setDeptcategoryid(deptcategoryid);


                //将对象添加到List集合中
                departments.add(department);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return departments;
    }
    /**
     * 功能：根据主键查询科室信息
     * @param deptid
     * @return
     */
    public Department findDepartmentByID(int deptid){
        Department department = new Department();
        //1.获取数据库连接对象
        Connection connection =  DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql ="select id,deptcode,deptname,deptcategoryid from tbl_department where id=?";
        try {
            pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1,deptid);
            rs = pstmt.executeQuery();

            if(rs.next()){

                int id= rs.getInt("id");
                String deptcode = rs.getString("deptcode");
                String deptname = rs.getString("deptname");
                int deptcategoryid = rs.getInt("deptcategoryid");

                //每行记录封装为一个对象
                department.setId(id);
                department.setDeptcode(deptcode);
                department.setDeptname(deptname);
                department.setDeptcategoryid(deptcategoryid);



            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return department;

    }
}
