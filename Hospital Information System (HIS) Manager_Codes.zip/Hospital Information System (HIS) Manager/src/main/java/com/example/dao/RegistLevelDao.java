package com.example.dao;


import com.example.model.RegistLevel;

import com.example.util.DBCPUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class RegistLevelDao {

    /**
     * 添加科室操作
     * @param registlevel
     *
    *private Integer id;
   * private String registcode;
   * private String registname;
   * private Integer sequenceno;
    *private double registfee;
   * private Integer registquota;
   * private Integer delmark;
     *
     * @return
     */
    public boolean addRegistLevel(RegistLevel registlevel){
        boolean flag = false;
        String sql ="insert into tbl_registlevel (registcode,registname,sequenceno,registfee,registquota) values(?,?,?,?,?)";
        return DBCPUtil.execUpdate(sql,registlevel.getRegistcode(),registlevel.getRegistname(),
                registlevel.getSequenceno(),registlevel.getRegistfee(),registlevel.getRegistquota());
    }

    /**
     * 功能：根据科室编号修改科室信息
     * @param registlevel
     * @return
     */
    public boolean updateRegistLevel(RegistLevel registlevel){
        boolean flag = false;
        String sql ="update tbl_registlevel set registcode=?,registname=?,sequenceno=? ,registfee=?,registquota=? where id=?";
        flag = DBCPUtil.execUpdate(sql,registlevel.getRegistcode(),registlevel.getRegistname(),
                registlevel.getSequenceno(),registlevel.getRegistfee(),registlevel.getRegistquota(),registlevel.getId());
        return flag;
    }

    /**
     * 功能：根据科室编号删除科室信息
     * @param id
     * @return
     */
    public boolean deleteRegistLevel(int id){
        boolean flag = false;
        String sql ="delete from tbl_registLevel where id =?";
        flag = DBCPUtil.execUpdate(sql,id);
        return flag;
    }




    /**
     * 功能：查询科室的所有信息
     * @return
     */
    public List<RegistLevel> findAll(){
        List<RegistLevel> registlevels = new ArrayList<>();
        //1.获取数据库连接对象
        Connection connection =  DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql ="select id,registcode,registname,sequenceno ,registfee,registquota from tbl_registlevel  ";
        try {
            pstmt = connection.prepareStatement(sql);
            rs = pstmt.executeQuery();
            RegistLevel registlevel = null;
            while(rs.next()){
                registlevel = new RegistLevel();
                int id= rs.getInt("id");
                String registcode = rs.getString("registcode");
                String registname = rs.getString("registname");
                int sequenceno = rs.getInt("sequenceno");
                double registfee = rs.getDouble("registfee");
                int registquota = rs.getInt("registquota");


                //每行记录封装为一个对象
                registlevel.setId(id);
                registlevel.setRegistcode(registcode);
                registlevel.setRegistname(registname);
                registlevel.setSequenceno(sequenceno);
                registlevel.setRegistfee(registfee);
                registlevel.setRegistquota(registquota);


                //将对象添加到List集合中
                registlevels.add(registlevel);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return registlevels;
    }

    /**
     * 功能：查询科室的所有信息
     * @return
     */
    public RegistLevel findRegistLevelByID(int registlevelid){
        RegistLevel registlevel = new RegistLevel();
        //1.获取数据库连接对象
        Connection connection =  DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql ="select id,registcode,registname,sequenceno ,registfee,registquota from tbl_registlevel where id=? ";
        try {
            pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1,registlevelid);
            rs = pstmt.executeQuery();

            if(rs.next()){

                int id= rs.getInt("id");
                String registcode = rs.getString("registcode");
                String registname = rs.getString("registname");
                int sequenceno = rs.getInt("sequenceno");
                double registfee = rs.getDouble("registfee");
                int registquota = rs.getInt("registquota");

                //每行记录封装为一个对象
                registlevel.setId(id);
                registlevel.setRegistcode(registcode);
                registlevel.setRegistname(registname);
                registlevel.setSequenceno(sequenceno);
                registlevel.setRegistfee(registfee);
                registlevel.setRegistquota(registquota);


                //将对象添加到List集合中


            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return registlevel;
    }


  

}
