package com.example.servlet;

import com.example.dao.*;
import com.example.model.*;


import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "RegisterServlet", value = "/RegisterServlet")
public class RegisterServlet extends HttpServlet {
    //创建数据库访问层对象
    RegisterDao registerDao = new RegisterDao();
    SettleCategoryDao settleCategoryDao = new SettleCategoryDao();//外键
    DepartmentDao departmentDao = new DepartmentDao();//外键
    UserDao userDao = new UserDao();//外键
    RegistLevelDao registLevelDao = new RegistLevelDao();//外键

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request, response);
    }

    /**
     * 前端控制器——执行患者挂号信息的添加，修改，查询操作
     * 添加操作的方法名：addregister
     * 修改：updateregister
     * 根据主键查询信息：findid
     * 调用外键数据:addinput
     * 作废信息：cancel
     * 默认执行：查询全部信息
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String methodname = request.getParameter("method");
        if ("addregister".equals(methodname)) {
            addregister(request, response);
        } else if ("updateregister".equals(methodname)) {
            updateregister(request, response);
        } else if ("findid".equals(methodname)) {
            findRegisterByid(request, response);
        } else if ("addinput".equals(methodname)) {
            addinput(request, response);
        } else if ("cancel".equals(methodname)) {
            cancelRegisterById(request, response);
        } else {
            findAll(request, response);
        }
    }

    protected void addregister(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        int gender = Integer.parseInt(request.getParameter("gender"));
        int deptid = Integer.parseInt(request.getParameter("deptid"));
        int userid = Integer.parseInt(request.getParameter("userid"));
        int registleid = Integer.parseInt(request.getParameter("registleid"));
        int settleid = Integer.parseInt(request.getParameter("settleid"));
        int registerid = Integer.parseInt(request.getParameter("registerid"));
        int age = Integer.parseInt(request.getParameter("age"));
        String casenumber = request.getParameter("casenumber");
        String realname = request.getParameter("realname");
        String idnumber = request.getParameter("idnumber");
        String birthdate = request.getParameter("birthdate");
        String agetype = request.getParameter("agetype");
        String homeaddress = request.getParameter("homeaddress");
        String noon = request.getParameter("noon");
        String isbook = request.getParameter("isbook");

        //创建Register对象
        Register register = new Register();
        register.setCasenumber(casenumber);
        register.setRealname(realname);
        register.setGender(gender);
        register.setIdnumber(idnumber);
        register.setBirthdate(birthdate);
        register.setAge(age);
        register.setAgetype(agetype);
        register.setHomeaddress(homeaddress);
        register.setNoon(noon);
        register.setDeptid(deptid);
        register.setUserid(userid);
        register.setRegistleid(registleid);
        register.setSettleid(settleid);
        register.setIsbook(isbook);
        register.setRegisterid(registerid);
        //调用数据库的添加方法
        registerDao.addRegister(register);

        //跳转到查询页面
        findAll(request, response);
    }

    protected void updateregister(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


        int id = Integer.parseInt(request.getParameter("id"));
        int visitstate = Integer.parseInt(request.getParameter("visitstate"));


        //创建Register对象
        Register register = new Register();
        register.setId(id);
        register.setVisitstate(visitstate);
        //调用数据库的添加方法
        registerDao.updateRegister(register);

        //跳转到查询页面
        findAll(request, response);
    }

    /**
     * 根据主键查询
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void findRegisterByid(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //获取患者挂号编号
        int regid = Integer.parseInt(request.getParameter("regid"));
        //调用数据库访问层中的根据编号查询的方法
        Register register = registerDao.findRegisterByid(regid);
        //跳转到修改显示页面
        request.setAttribute("registerObj", register);
        request.getRequestDispatcher("/hushi_web/updateregister.jsp").forward(request, response);
    }

    /**查询患者挂号信息
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void findAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Register> registers = registerDao.findAll();
        request.setAttribute("registerObjs", registers);
        request.getRequestDispatcher("/hushi_web/displayregister.jsp").forward(request, response);
    }

    protected void addinput(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<SettleCategory> settleCategorys = settleCategoryDao.findAll();
        request.setAttribute("settleCategoryObjs", settleCategorys);
        List<Department> departments = departmentDao.findAll();
        request.setAttribute("departmentObjs", departments);
        List<User> users = userDao.findAll();
        request.setAttribute("userObjs", users);
        List<RegistLevel> registLevels = registLevelDao.findAll();
        request.setAttribute("registLevelObjs", registLevels);
        request.getRequestDispatcher("/hushi_web/addregister.jsp").forward(request, response);
    }
    protected void cancelRegisterById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("regid"));
        //创建Register对象
        Register register = new Register();
        register.setId(id);
        //调用数据库的作废方法
        registerDao.cancelRegisterById(register);
        //跳转到查询页面
        findAll(request, response);
    }

}

