package com.software.dao;

import com.example.dao.RegisterDao;
import com.example.model.Register;
import com.example.model.expenseclass;
import org.junit.jupiter.api.Test;

import java.util.List;

public class RegisterDaoTest {

    /**
     * 单元测试：科室数据库访问层连接数据库实现添加、修改、删除、查询的操作
     */


        //创建数据库访问层对象
        RegisterDao registerDao = new RegisterDao();

        /**
         * 单元测试--科室添加操作
         */
        @Test
        public void addMethod1(){
            //1.创建添加的科室测试用例
            Register register = new Register();
            register.setCasenumber("1");
            register.setRealname("小四");
            register.setGender(23);
            register.setIdnumber("216358925636874259");
            register.setBirthdate("1968/7/4");
            register.setAge(62);
            register.setAgetype("老年");
            register.setHomeaddress("Shanghai");
            register.setNoon("上午");
            register.setDeptid(1);
            register.setUserid(1);
            register.setRegistleid(1);
            register.setSettleid(1);
            register.setIsbook("是");
            register.setRegisttime("2023/7/16");
            register.setRegisterid(8);
            register.setVisitstate(3);


            //2.调用数据库访问层的方法实现添加操作
            boolean flag = registerDao.addRegister(register);
            if(flag){
                System.out.println("success");
            }else{
                System.out.println("failure");
            }
        }

        /**
         * 单元测试--科室信息的修改操作 仅挂号状态可修改
         */
        @Test
        public void updateRegister(){
            //1.创建修改科室测试用例
            Register register = new Register();
            register.setId(8);
            register.setCasenumber("1");
            register.setRealname("小三");
            register.setGender(23);
            register.setIdnumber("216358925636874259");
            register.setBirthdate("1968/7/4");
            register.setAge(62);
            register.setAgetype("老年");
            register.setHomeaddress("Shanghai");
            register.setNoon("上午");
            register.setDeptid(1);
            register.setUserid(1);
            register.setRegistleid(1);
            register.setSettleid(1);
            register.setIsbook("是");
            register.setRegisttime("2023/7/16");
            register.setRegisterid(8);
            register.setVisitstate(3);


            //2.调用数据库访问层的方法实现添加操作
            boolean flag = registerDao.updateRegister(register);
            if(flag){
                System.out.println("success");
            }else{
                System.out.println("failure");
            }
        }



        @Test
        public void queryRegister(){
            List<Register> registerList =  registerDao.findAll();
            for(Register register : registerList){
                System.out.println(register);
            }
        }
    @Test
    public void queryregisterByid(){
        Register register = registerDao.findRegisterByid(1);
        System.out.println(register);
    }

    }

