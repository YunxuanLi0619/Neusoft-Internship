package com.example.servlet;

import com.example.dao.DrugsDao;
import com.example.dao.PrescriptionDao;
import com.example.dao.PrescriptiondetailedDao;
import com.example.model.*;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
@WebServlet(name = "PrescriptiondetailedServlet", value = "/PrescriptiondetailedServlet")
public class PrescriptiondetailedServlet extends HttpServlet {
    //创建数据库访问层对象
    PrescriptiondetailedDao prescriptiondetailedDao = new PrescriptiondetailedDao();
    PrescriptionDao prescriptionDao = new PrescriptionDao();
    DrugsDao drugsDao = new DrugsDao();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request, response);
    }

    /**
     * 前端控制器——执行疾病表的添加，修改，删除，查询操作
     * 添加操作的方法名：adddisease
     * 修改：updatedisease
     * 删除：deletedisease
     * 根据主键查询信息：findid
     * 默认执行：查询全部信息
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String methodname = request.getParameter("method");
        if ("addmethod".equals(methodname)) {
            addPrescriptiondetailed(request, response);
        } else if ("updatemethod".equals(methodname)) {
            updatePrescriptiondetailed(request, response);

            /**
             * } else if ("deletemethod".equals(methodname)) {
             *             deletePrescriptiondetailedById(request, response);
             */


        } else if ("findid".equals(methodname)) {
            findPrescriptiondetailedByID(request, response);
        }else if("addinput".equals(methodname)){
            addinput(request,response);

        } else {
            findAll(request, response);
        }
    }

    /**
     * 功能 —— 添加疾病表信息
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void addPrescriptiondetailed(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int prescriptionid = Integer.parseInt(request.getParameter("prescriptionid"));
        int drugsid = Integer.parseInt(request.getParameter("drugsid"));
        int state = Integer.parseInt(request.getParameter("state"));
        String drugsusage = request.getParameter("drugsusage");
        String dosage = request.getParameter("dosage");
        String frequency = request.getParameter("frequency");
        Double amount = Double.parseDouble(request.getParameter("amount"));

        //创建Register对象
        Prescriptiondetailed prescriptiondetailed = new Prescriptiondetailed();
        prescriptiondetailed.setPrescriptionid(prescriptionid);
        prescriptiondetailed.setDrugsid(drugsid);
        prescriptiondetailed.setDrugsusage(drugsusage);
        prescriptiondetailed.setDosage(dosage);
        prescriptiondetailed.setFrequency(frequency);
        prescriptiondetailed.setAmount(amount);
        prescriptiondetailed.setState(state);
        //调用数据库的添加方法
        prescriptiondetailedDao.addPrescriptiondetailed(prescriptiondetailed);

        //跳转到成功页面
        findAll(request, response);
    }

    protected void updatePrescriptiondetailed(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取客户端输入的科室信息 (deptcode ,deptname  , deptcategoryid ,depttype)
        int id = Integer.parseInt(request.getParameter("id"));
        int prescriptionid = Integer.parseInt(request.getParameter("prescriptionid"));
        int drugsid = Integer.parseInt(request.getParameter("drugsid"));
        int state = Integer.parseInt(request.getParameter("state"));
        String drugsusage = request.getParameter("drugsusage");
        String dosage = request.getParameter("dosage");
        String frequency = request.getParameter("frequency");
        Double amount = Double.parseDouble(request.getParameter("amount"));

        //创建Deparmtn对象
        Prescriptiondetailed prescriptiondetailed = new Prescriptiondetailed();
        prescriptiondetailed.setId(id);
        prescriptiondetailed.setPrescriptionid(prescriptionid);
        prescriptiondetailed.setDrugsid(drugsid);
        prescriptiondetailed.setDrugsusage(drugsusage);
        prescriptiondetailed.setDosage(dosage);
        prescriptiondetailed.setFrequency(frequency);
        prescriptiondetailed.setAmount(amount);
        prescriptiondetailed.setState(state);

        //3.调用数据库访问层中的修改方法
        prescriptiondetailedDao.updatePrescriptiondetailed(prescriptiondetailed);

        //4.跳转到显示页面
        findAll(request, response);

    }


    /**
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void findAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Prescriptiondetailed> prescriptiondetaileds = prescriptiondetailedDao.findAll();
        request.setAttribute("prescriptiondetailedObjs", prescriptiondetaileds);
        request.getRequestDispatcher("/system/displayprescriptiondetailed.jsp").forward(request, response);
    }

    /**
     * 功能：根据科室编号查询科室信息
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void findPrescriptiondetailedByID(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取科室编号
        int predid = Integer.parseInt(request.getParameter("predid"));
        //2.调用数据库访问层中的根据科室编号查询科室信息的方法
        Prescriptiondetailed prescriptiondetailed = prescriptiondetailedDao.findPrescriptiondetailedByID(predid);

        //3.跳转到修改显示页面
        request.setAttribute("predobj", prescriptiondetailed);
        List<Prescription> prescriptions = prescriptionDao.findAll();
        request.setAttribute("prescriptionObjs",prescriptions);
        List<Drugs> drugs = drugsDao.findAll();
        request.setAttribute("drugsObjs", drugs);
        request.getRequestDispatcher("/system/updateprescriptiondetailed.jsp").forward(request,response);

    }

    /**
     * 功能：根据科室编号查询科室信息
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    /**protected void deletePrescriptiondetailedById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取科室编号
        int predid = Integer.parseInt(request.getParameter("did"));
        //2.调用数据库访问层中的根据科室编号删除科室信息的方法
        prescriptiondetailedDao.deletePrescriptiondetailed(predid);
        //3.跳转到修改显示页面
        findAll(request,response);
    }*/
    protected void addinput(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Prescription> prescriptions = prescriptionDao.findAll();
        request.setAttribute("prescriptionObjs",prescriptions);
        List<Drugs> drugs = drugsDao.findAll();
        request.setAttribute("drugsObjs", drugs);
        request.getRequestDispatcher("/system/addprescriptiondetailed.jsp").forward(request,response);
    }



}



