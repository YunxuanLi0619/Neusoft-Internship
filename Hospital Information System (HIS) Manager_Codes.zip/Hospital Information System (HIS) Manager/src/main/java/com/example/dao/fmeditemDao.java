package com.example.dao;
import com.example.model.fmeditem;
import com.example.util.DBCPUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * 数据库访问层--科室信息的增删改查操作
 */

public class fmeditemDao {
    /**
     * 添加科室操作
     * @param Fmeditem
     * @return
     */
    public boolean addfmeditem(fmeditem Fmeditem){
        boolean flag = false;
        String sql ="insert into tbl_fmeditem(itemcode,itemname,format,price,expclassid,deptid,mnemoniccode," +
                "creationdate,lastupdatedate,recordtype) " +
                "values(?,?,?,?,?,?,?,?,?,?)";
        return DBCPUtil.execUpdate(sql,Fmeditem.getItemcode(),Fmeditem.getItemname(),Fmeditem.getFormat(),Fmeditem.
                getPrice(),Fmeditem.getExpclassid(),Fmeditem.getDeptid(),Fmeditem.getMnemoniccode(),
                Fmeditem.getCreationdate(),Fmeditem.getLastupdatedate(),Fmeditem.getRecordtype());
    }

    /**
     * 功能：根据科室编号修改科室信息
     * @param Fmeditem
     * @return
     */
    public boolean updatefmeditem(fmeditem Fmeditem){
        boolean flag = false;
        String sql ="update tbl_fmeditem set itemcode=?,itemname=?,format=?,price=?,expclassid=?,deptid=?,mnemoniccode=?" +
                ",creationdate=?,lastupdatedate=?,recordtype=? where id=?";
        flag = DBCPUtil.execUpdate(sql,Fmeditem.getItemcode(),Fmeditem.getItemname(),Fmeditem.getFormat(),Fmeditem.
                        getPrice(),Fmeditem.getExpclassid(),Fmeditem.getDeptid(),Fmeditem.getMnemoniccode(),
                Fmeditem.getCreationdate(),Fmeditem.getLastupdatedate(),Fmeditem.getRecordtype()
                ,Fmeditem.getId());
        return flag;
    }

    /**
     * 功能：根据科室编号删除科室信息
     * @param id
     * @return
     */
    public boolean deletefmeditem(int id){
        boolean flag = false;
        String sql ="delete from tbl_fmeditem where id =?";
        flag = DBCPUtil.execUpdate(sql,id);
        return flag;
    }





    /**
     * 功能：查询科室的所有信息
     * @return
     */
    public List<fmeditem> findAll(){
        List<fmeditem> fmeditems = new ArrayList<>();
        //1.获取数据库连接对象
        Connection connection =  DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql ="select id,itemcode,itemname,format,price,expclassid,deptid,mnemoniccode,creationdate," +
                "lastupdatedate,recordtype from tbl_fmeditem";
        try {
            pstmt = connection.prepareStatement(sql);
            rs = pstmt.executeQuery();
            fmeditem Fmeditem = null;
            while(rs.next()){
                Fmeditem = new fmeditem();
                int id = rs.getInt("id");
                String itemcode = rs.getString("itemcode");
                String itemname = rs.getString("itemname");
                String format = rs.getString("format");
                Double price = rs.getDouble("price");
                int expclassid = rs.getInt("expclassid");
                int deptid = rs.getInt("deptid");
                String mnemoniccode = rs.getString("mnemoniccode");
                String creationdate = rs.getString("creationdate");
                String lastupdatedate = rs.getString("lastupdatedate");
                int recordtype = rs.getInt("recordtype");

                //每行记录封装为一个对象
                Fmeditem.setId(id);
                Fmeditem.setItemcode(itemcode);
                Fmeditem.setItemname(itemname);
                Fmeditem.setFormat(format);
                Fmeditem.setFormat(format);
                Fmeditem.setPrice(price);
                Fmeditem.setExpclassid(expclassid);
                Fmeditem.setDeptid(deptid);
                Fmeditem.setMnemoniccode(mnemoniccode);
                Fmeditem.setCreationdate(creationdate);
                Fmeditem.setLastupdatedate(lastupdatedate);
                Fmeditem.setRecordtype(recordtype);

                //将对象添加到List集合中
                fmeditems.add(Fmeditem);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return fmeditems;
    }

    public fmeditem findFmeditemById(int fmeditemid){
        fmeditem fmeditem = new fmeditem();
        //1.获取数据库连接对象
        Connection connection =  DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql ="select id,itemcode,itemname,format,price,expclassid,deptid,mnemoniccode,creationdate," +
                "lastupdatedate,recordtype from tbl_fmeditem where id=?";
        try {
            pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1,fmeditemid);

            rs = pstmt.executeQuery();

            if(rs.next()){

                int id = rs.getInt("id");
                String itemcode = rs.getString("itemcode");
                String itemname = rs.getString("itemname");
                String format = rs.getString("format");
                Double price = rs.getDouble("price");
                int expclassid = rs.getInt("expclassid");
                int deptid = rs.getInt("deptid");
                String mnemoniccode = rs.getString("mnemoniccode");
                String creationdate = rs.getString("creationdate");
                String lastupdatedate = rs.getString("lastupdatedate");
                int recordtype = rs.getInt("recordtype");


                //每行记录封装为一个对象
                fmeditem.setId(id);
                fmeditem.setItemcode(itemcode);
                fmeditem.setItemname(itemname);
                fmeditem.setFormat(format);
                fmeditem.setFormat(format);
                fmeditem.setPrice(price);
                fmeditem.setExpclassid(expclassid);
                fmeditem.setDeptid(deptid);
                fmeditem.setMnemoniccode(mnemoniccode);
                fmeditem.setCreationdate(creationdate);
                fmeditem.setLastupdatedate(lastupdatedate);
                fmeditem.setRecordtype(recordtype);




            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return fmeditem;
    }

}
