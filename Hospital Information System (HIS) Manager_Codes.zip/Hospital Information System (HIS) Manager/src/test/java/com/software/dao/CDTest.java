package com.software.dao;

import com.example.dao.CheckapplyDao;
import com.example.model.Checkapply;
import org.junit.jupiter.api.Test;

import java.util.List;

/**
 * 单元测试：科室数据库访问层连接数据库实现添加、修改、删除、查询的操作
 */
public class CDTest {

    //创建数据库访问层对象
    CheckapplyDao checkapplyDao = new CheckapplyDao();


    /**
     * 单元测试--科室添加操作   医生添加
     */
    @Test
    public void addMethod1(){
        //1.创建添加的科室测试用例
        Checkapply checkapply = new Checkapply();
        checkapply.setMedicalid(11);
        checkapply.setRegistid(11);
        checkapply.setItemid(11);
        checkapply.setObjective("检查心脏");
        checkapply.setUrgent(0);
        checkapply.setNum(1);
        checkapply.setCreationtime("2023/1/13");
        checkapply.setDoctorid(7);


        //2.调用数据库访问层的方法实现添加操作
        boolean flag = checkapplyDao.addCheckapply(checkapply);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    /**
     * 单元测试--科室信息的修改操作 检验员操作
     */
    @Test
    public void updateCheckapply(){
        //1.创建修改科室测试用例
        Checkapply checkapply = new Checkapply();
        checkapply.setResultoperid(7);
        checkapply.setChecktime("2023/1/14");
        checkapply.setResult("心脏病");
        checkapply.setResulttime("2023/1/14");
        checkapply.setState(5);
        checkapply.setRecordtype(1);


        //2.调用数据库访问层的方法实现添加操作

        boolean flag = CheckapplyDao.updateCheckapply(checkapply);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    /**
     * 单元测试--删除操作 修改状态
     */


    @Test
    public void queryCheckapply(){
        List<Checkapply> checkapplyList = checkapplyDao.findAll();
        for(Checkapply checkapply : checkapplyList){
            System.out.println(checkapply);
        }
    }


}
