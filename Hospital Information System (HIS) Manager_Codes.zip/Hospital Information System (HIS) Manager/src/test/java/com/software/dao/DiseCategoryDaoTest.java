package com.software.dao;

import com.example.dao.DiseCategoryDao;
import com.example.model.DiseCategory;
import org.junit.jupiter.api.Test;

import java.util.List;

public class DiseCategoryDaoTest {


    //创建数据库访问层对象
    DiseCategoryDao disecategorydao = new DiseCategoryDao();

    /**
     * 单元测试--科室添加操作         id,dicacode,dicaname,sequenceno,dicatype ,delmark
     */
    @Test
    public void addMethod1(){
        //1.创建添加的科室测试用例
        DiseCategory disecategory = new  DiseCategory();
        disecategory.setDicacode("D0011");
        disecategory.setDicaname("皮肤类疾病");
        disecategory.setSequenceno(2);
        disecategory.setDicatype(3);


        //2.调用数据库访问层的方法实现添加操作
        boolean flag = disecategorydao.addDiseCategory(disecategory);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    /**
     * 单元测试--科室信息的修改操作
     */
    @Test
    public void updateMethod(){
        //1.创建修改科室测试用例
        DiseCategory disecategory = new DiseCategory();

        disecategory.setDicacode("D008");
        disecategory.setDicaname("妇科疾病");
        disecategory.setSequenceno(8);
        disecategory.setDicatype(1);
        disecategory.setId(1);

        //2.调用数据库访问层的方法实现添加操作
        boolean flag = disecategorydao.updateDiseCategory(disecategory);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    /**
     * 单元测试--删除操作
     */
    @Test
    public void deleteMethod(){
        boolean flag = disecategorydao.deleteDiseCategory(5);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    @Test
    public void queryMethod(){
        List<DiseCategory> disecategoryList =  disecategorydao.findAll();
        for(DiseCategory disecategory : disecategoryList){
            System.out.println(disecategory);
        }
    }
}
