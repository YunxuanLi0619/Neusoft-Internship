package com.example.servlet;

import com.example.dao.RegistLevelDao;

import com.example.model.RegistLevel;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "tbl_registlevelServlet", value = "/tbl_registlevelServlet")
public class tbl_registlevelServlet extends HttpServlet {


    //2.创建数据库访问层对象
    RegistLevelDao registleveldao = new RegistLevelDao();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request,response);
    }

    /**前端控制器 执行科室添加删除。。。工作
     * 添加方法addmethod
     * updatemethod
     * deletemethod
     * 根据主键查询科室信息:findid
     * 默认执行：查询全部信息
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String methodname = request.getParameter("method");
        if("addmethod".equals(methodname)){
            //添加操作
            addRegistLevel(request,response);
        }else if("updatemethod".equals(methodname)){

            //修改
            updateRegistLevel(request,response);
        }else if("deletemethod".equals(methodname)){

            //删除
            deleteRegistLevel(request,response);
        }else if("findid".equals(methodname)){

            //按照特定id查找
            findRegistLevelById(request,response);

        }else{

            //执行全部操作
            findAll(request,response);

        }


    }
    
    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */




    protected void addRegistLevel(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取客户端科室信息 registcode,registname,sequenceno ,registfee,registquota
        String tbl_registcode = request.getParameter("registcode");
        String tbl_registname = request.getParameter("registname");
        int tbl_sequenceno = Integer.parseInt(request.getParameter("sequenceno"));
        double tbl_registfee = Double.parseDouble(request.getParameter("registfee"));
        int tbl_registquota = Integer.parseInt(request.getParameter("registquota"));


        //创建registlevel对象
        RegistLevel registlevel = new RegistLevel();
        registlevel.setRegistcode(tbl_registcode);
        registlevel.setRegistname(tbl_registname);
        registlevel.setSequenceno(tbl_sequenceno);
        registlevel.setRegistfee(tbl_registfee);
        registlevel.setRegistquota(tbl_registquota);

        //3.调取数据库访问层中的
        registleveldao.addRegistLevel(registlevel);


        //4.跳转到成功页面
        findAll(request,response);

    }
    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */




    protected void updateRegistLevel(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取客户端科室信息 registcode,registname,sequenceno ,registfee,registquota
        int id = Integer.parseInt(request.getParameter("id"));
        String tbl_registcode = request.getParameter("registcode");
        String tbl_registname = request.getParameter("registname");
        int tbl_sequenceno = Integer.parseInt(request.getParameter("sequenceno"));
        double tbl_registfee = Double.parseDouble(request.getParameter("registfee"));
        int tbl_registquota = Integer.parseInt(request.getParameter("registquota"));



        //创建registlevel对象
        RegistLevel registlevel = new RegistLevel();
        registlevel.setId(id);
        registlevel.setRegistcode(tbl_registcode);
        registlevel.setRegistname(tbl_registname);
        registlevel.setSequenceno(tbl_sequenceno);
        registlevel.setRegistfee(tbl_registfee);
        registlevel.setRegistquota(tbl_registquota);

        //3.调取数据库访问层中的
        registleveldao.updateRegistLevel(registlevel);


        //4.跳转到成功页面
        findAll(request,response);

    }


    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void deleteRegistLevel(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        //1。获取科室编号
        int registlevelid = Integer.parseInt(request.getParameter("did"));
        //2.调用
        registleveldao.deleteRegistLevel(registlevelid);
        //3.跳转到修改页面
        findAll(request,response);

    }


    /**
     *功能：根据编号查询科室信息
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void findRegistLevelById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {//1获取科室编号
        int registlevelid = Integer.parseInt(request.getParameter("registlevelid"));
        //2.调用数据库访问层中编号查询信息的方法
        RegistLevel registlevel = registleveldao.findRegistLevelByID(registlevelid);
        //3.跳转到修改显示页面
        request.setAttribute("registlevelobj",registlevel);
        request.getRequestDispatcher("/system/updateregistlevel.jsp").forward(request,response);

    }

    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void findAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {

        List<RegistLevel> registlevels = registleveldao.findAll();
        request.setAttribute("registlevelObjs",registlevels);
        request.getRequestDispatcher("/system/displayregistlevel.jsp").forward(request,response);



    }

}
