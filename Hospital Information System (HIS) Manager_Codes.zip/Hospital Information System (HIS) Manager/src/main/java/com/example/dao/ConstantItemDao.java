

package com.example.dao;

import com.example.model.ConstantItem;
import com.example.util.DBCPUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
    /**
     * 数据库访问层--科室信息的增删改查操作
     */
    public class ConstantItemDao {

        /**
         * 添加科室操作
         * @param constantitem
         * @return
         */
        public boolean addConstantItem(ConstantItem constantitem){
            boolean flag = false;
            String sql ="insert into tbl_constantitem(constanttypeid,constantcode,constantname) " +
                    "values(?,?,?)";
            return DBCPUtil.execUpdate(sql,constantitem.getConstanttypeid(),constantitem.getConstantcode(),
                    constantitem.getConstantname());
        }

        /**
         * 功能：根据科室编号修改科室信息
         * @param constantitem
         * @return
         */
        public boolean updateConstantItem(ConstantItem constantitem){
            boolean flag = false;
            String sql ="update tbl_constantitem set constanttypeid=?,constantcode=?,constantname=? where id=?";
            flag = DBCPUtil.execUpdate(sql,constantitem.getConstanttypeid(),constantitem.getConstantcode(),
                    constantitem.getConstantname(),constantitem.getId());
            return flag;
        }

        /**
         * 功能：根据科室编号删除科室信息
         * @param id
         * @return
         */
        public boolean deleteConstantItem(int id){
            boolean flag = false;
            String sql ="delete from tbl_constantitem where id =?";
            flag = DBCPUtil.execUpdate(sql,id);
            return flag;
        }



        /**
         * 功能：查询科室的所有信息
         * @return
         */
        public List<ConstantItem> findAll(){
            List<ConstantItem> constantitems = new ArrayList<>();
            //1.获取数据库连接对象
            Connection connection =  DBCPUtil.getConnection();
            PreparedStatement pstmt = null;
            ResultSet rs = null;
            String sql ="select id,constanttypeid,constantcode,constantname  from tbl_constantitem ";
            try {
                pstmt = connection.prepareStatement(sql);
                rs = pstmt.executeQuery();
                ConstantItem constantitem = null;
                while(rs.next()){
                    constantitem = new ConstantItem();
                    int id= rs.getInt("id");
                    int constanttypeid = rs.getInt("constanttypeid");
                    String constantcode = rs.getString("constantcode");
                    String constantname = rs.getString("constantname");

                    //每行记录封装为一个对象
                    constantitem.setId(id);
                    constantitem.setConstanttypeid(constanttypeid);
                    constantitem.setConstantcode(constantcode);
                    constantitem.setConstantname(constantname);


                    //将对象添加到List集合中
                    constantitems.add(constantitem);

                }

            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                DBCPUtil.release(connection,pstmt,rs);
            }
            return constantitems;
        }
        /**
         * 功能：根据主键查询科室信息
         * @param constantitemid
         * @return
         */


        public ConstantItem findConstantItemByID(int constantitemid){

            ConstantItem constantitem = new ConstantItem();
            //1.获取数据库连接对象
            Connection connection =  DBCPUtil.getConnection();
            PreparedStatement pstmt = null;
            ResultSet rs = null;
            String sql ="select id,constanttypeid,constantcode,constantname  from tbl_constantitem where id=?";
            try {
                pstmt = connection.prepareStatement(sql);
                pstmt.setInt(1,constantitemid);
                rs = pstmt.executeQuery();

                if(rs.next()){

                    int id= rs.getInt("id");
                    int constanttypeid = rs.getInt("constanttypeid");
                    String constantcode = rs.getString("constantcode");
                    String constantname = rs.getString("constantname");


                    //每行记录封装为一个对象
                    constantitem.setId(id);
                    constantitem.setConstanttypeid(constanttypeid);
                    constantitem.setConstantcode(constantcode);
                    constantitem.setConstantname(constantname);


                    //将对象添加到List集合中


                }

            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                DBCPUtil.release(connection,pstmt,rs);
            }
            return constantitem;
        }

    }
