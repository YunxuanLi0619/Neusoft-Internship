package com.example.servlet;

import com.example.dao.DiseCategoryDao;
import com.example.dao.DiseaseDao;
import com.example.model.DiseCategory;
import com.example.model.Disease;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "DiseCategoryServlet", value = "/DiseCategoryServlet")
public class DiseCategoryServlet extends HttpServlet {
    //2.创建数据库访问层对象


    DiseCategoryDao disecategoryDao = new DiseCategoryDao();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        execute(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        execute(request, response);
    }

    /**
     * 前端控制器
     * 添加方法的参数名：addmethod
     * 修改：    updatemethod
     * 删除：    deletemethod
     * 根据主键查询科室信息: findid
     * 默认执行：查询全部信息
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String methodname = request.getParameter("method");
        if ("addmethod".equals(methodname)) {
            //添加操作
            addDiseCategorys(request, response);
        } else if ("updatemethod".equals(methodname)) {
            //修改操作
            updateDiseCategorys(request,response);
        } else if ("deletemethod".equals(methodname)) {
            //删除操作
            deleteDiseCategoryById(request,response);
        } else if ("findid".equals(methodname)) {
            //根据主键查询数据表信息
            findDiseCategorysById(request, response);
        }else {
            findAll(request,response);//执行查询所有记录
        }
    }



    /**
     * 前端控制器-添加项目
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void addDiseCategorys(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        //1.获取客户端输入

        String neodicacode = request.getParameter("dicacode");
        String neodicaname = request.getParameter("dicaname");
        int neosequenceno = Integer.parseInt(request.getParameter("sequenceno"));
        int neodicatype = Integer.parseInt(request.getParameter("dicatype"));


        //创建对象
        DiseCategory disecategory = new DiseCategory();
        disecategory.setDicacode(neodicacode);
        disecategory.setDicaname(neodicaname);
        disecategory.setSequenceno(neosequenceno);
        disecategory.setDicatype(neodicatype);


        //3.调用添加方法
        disecategoryDao.addDiseCategory(disecategory);
        //4.跳转到成功
        findAll(request,response);

    }


    /**
     * 前端控制器-修改项目
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void updateDiseCategorys(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        //1.获取客户端输入

        int id = Integer.parseInt(request.getParameter("id"));
        String neodicacode = request.getParameter("dicacode");
        String neodicaname = request.getParameter("dicaname");
        int neosequenceno = Integer.parseInt(request.getParameter("sequenceno"));
        int neodicatype = Integer.parseInt(request.getParameter("dicatype"));


        //创建对象
        DiseCategory disecategory = new DiseCategory();
        disecategory.setId(id);
        disecategory.setDicacode(neodicacode);
        disecategory.setDicaname(neodicaname);
        disecategory.setSequenceno(neosequenceno);
        disecategory.setDicatype(neodicatype);


        //3.调用修改方法
        disecategoryDao.updateDiseCategory(disecategory);
        //4.跳转到查询
        findAll(request,response);


    }



    /**
     * 查询
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void findAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.调用访问方法
        List<DiseCategory> DiseCategorys = disecategoryDao.findAll();
        //2.跳转到显示界面
        request.setAttribute("disecategoryObjs",DiseCategorys);
        request.getRequestDispatcher("/system/displayDiseCategory.jsp").forward(request,response);
    }


    /**
    *根据编号查询、
    * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void findDiseCategorysById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取编号
        int dcid=Integer.parseInt(request.getParameter("dcid"));
        //2.调用数据库访问层
        DiseCategory disecategory=disecategoryDao.findDCByID(dcid);
        //3.跳转到修改显示
        request.setAttribute("dcobj",disecategory);
        request.getRequestDispatcher("/system/updateDiseCategory.jsp").forward(request,response);
    }


    /**
     *根据编号删除、
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void deleteDiseCategoryById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取编号
        int dcid=Integer.parseInt(request.getParameter("Did"));
        //2.调用数据库访问层
        disecategoryDao.deleteDiseCategory(dcid);
        //3.跳转到修改显示
        findAll(request,response);
    }





}
