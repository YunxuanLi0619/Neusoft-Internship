package com.software.dao;

import com.example.dao.RegistLevelDao;

import com.example.model.RegistLevel;

import org.junit.jupiter.api.Test;
import java.util.List;


public class RegistLevelDaoTest {
    //创建数据库访问层对象
    RegistLevelDao registleveldao = new RegistLevelDao();

    /**
     * 单元测试--科室添加操作   id,registcode,registname,sequenceno ,registfee,registquota, delmark
     */
    @Test
    public void addMethod1(){
        //1.创建添加的科室测试用例
        RegistLevel registlevel = new  RegistLevel();

        registlevel.setRegistcode("ADVANCED");
        registlevel.setRegistname("专家");
        registlevel.setSequenceno(2);
        registlevel.setRegistfee(40);
        registlevel.setRegistquota(30);


        //2.调用数据库访问层的方法实现添加操作
        boolean flag = registleveldao.addRegistLevel(registlevel);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    /**
     * 单元测试--科室信息的修改操作
     */
    @Test
    public void updateMethod(){
        //1.创建修改科室测试用例
        RegistLevel registlevel = new RegistLevel();
        registlevel.setId(3);
        registlevel.setRegistcode("ADVANCED");
        registlevel.setRegistname("专家");
        registlevel.setSequenceno(2);
        registlevel.setRegistfee(40);
        registlevel.setRegistquota(30);


        //2.调用数据库访问层的方法实现添加操作
        boolean flag = registleveldao.updateRegistLevel(registlevel);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    /**
     * 单元测试--删除操作
     */
    @Test
    public void deleteMethod(){
        boolean flag = registleveldao.deleteRegistLevel(10);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    @Test
    public void queryMethod(){
        List<RegistLevel> registlevelList =  registleveldao.findAll();
        for(RegistLevel registlevel : registlevelList){
            System.out.println(registlevel);
        }
    }
    
}
