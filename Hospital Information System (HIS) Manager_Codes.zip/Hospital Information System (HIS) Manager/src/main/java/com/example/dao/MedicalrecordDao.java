package com.example.dao;

import com.example.model.Medicalrecord;
import com.example.util.DBCPUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class MedicalrecordDao {
    public static boolean addMedicalrecord(Medicalrecord medicalrecord){
        boolean flag = false;
        String sql ="insert into tbl_medicalrecord(casenumber,registid,readme,present,presenttreat,history,allergy,diagnosis,handling,casestate) " +
                "values(?,?,?,?,?,?,?,?,?,?)";
        return DBCPUtil.execUpdate(sql,medicalrecord.getCasenumber(),medicalrecord.getRegistid(),medicalrecord.getReadme(),
                medicalrecord.getPresent(),medicalrecord.getPresenttreat(),medicalrecord.getHistory(),medicalrecord.getAllergy(),
                medicalrecord.getDiagnosis(),medicalrecord.getHandling(),medicalrecord.getCasestate());
    }

    public static boolean deleteMedicalrecord(int id){
        boolean flag = false;
        String sql ="update tbl_medicalrecord set casestate = 4 where id = ?";
        flag = DBCPUtil.execUpdate(sql,id);
        return flag;
    }

    public static boolean updateMedicalrecord(Medicalrecord medicalrecord){
        boolean flag = false;
        String sql ="update tbl_medicalrecord set casenumber=?,registid=?,readme=?,present=?,presenttreat=?,history=?,allergy=?,diagnosis=?,handling=?,casestate=? where id=?";
        flag = DBCPUtil.execUpdate(sql,medicalrecord.getCasenumber(),medicalrecord.getRegistid(),medicalrecord.getReadme(),
                medicalrecord.getPresent(),medicalrecord.getPresenttreat(),medicalrecord.getHistory(),medicalrecord.getAllergy(),
                medicalrecord.getDiagnosis(),medicalrecord.getHandling(),medicalrecord.getCasestate(),medicalrecord.getId());
        return flag;
    }

    public static List<Medicalrecord> findAll(){
        List<Medicalrecord> medicalrecords = new ArrayList<>();
        //1.获取数据库连接对象
        Connection connection =  DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql ="select id,casenumber,registid,readme,present,presenttreat,history,allergy,diagnosis,handling,casestate from tbl_medicalrecord where casestate < 4";
        try {
            pstmt = connection.prepareStatement(sql);
            rs = pstmt.executeQuery();
            Medicalrecord medicalrecord = null;
            while(rs.next()){
                medicalrecord = new Medicalrecord();
                int id = rs.getInt("id");
                String casenumber = rs.getString("casenumber");
                int registid = rs.getInt("registid");
                String readme = rs.getString("readme");
                String present = rs.getString("present");
                String presenttreat = rs.getString("presenttreat");
                String history = rs.getString("history");
                String allergy = rs.getString("allergy");
                String diagnosis = rs.getString("diagnosis");
                String handling = rs.getString("handling");
                int casestate = rs.getInt("casestate");


                //每行记录封装为一个对象
                medicalrecord.setId(id);
                medicalrecord.setCasenumber(casenumber);
                medicalrecord.setRegistid(registid);
                medicalrecord.setReadme(readme);
                medicalrecord.setPresent(present);
                medicalrecord.setPresenttreat(presenttreat);
                medicalrecord.setHistory(history);
                medicalrecord.setAllergy(allergy);
                medicalrecord.setDiagnosis(diagnosis);
                medicalrecord.setHandling(handling);
                medicalrecord.setCasestate(casestate);


                //将对象添加到List集合中
                medicalrecords.add(medicalrecord);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return medicalrecords;
    }

    public Medicalrecord findMedicalrecordById(int medicalredordid){
        Medicalrecord medicalrecord = new Medicalrecord();
        //1.获取数据库连接对象
        Connection connection =  DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql ="select id,casenumber,registid,readme,present,presenttreat,history,allergy,diagnosis,handling,casestate from tbl_medicalrecord where id=?";
        try {
            pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1,medicalredordid);
            rs = pstmt.executeQuery();

            if(rs.next()){
                medicalrecord = new Medicalrecord();
                int id = rs.getInt("id");
                String casenumber = rs.getString("casenumber");
                int registid = rs.getInt("registid");
                String readme = rs.getString("readme");
                String present = rs.getString("present");
                String presenttreat = rs.getString("presenttreat");
                String history = rs.getString("history");
                String allergy = rs.getString("allergy");
                String diagnosis = rs.getString("diagnosis");
                String handling = rs.getString("handling");
                int casestate = rs.getInt("casestate");


                //每行记录封装为一个对象
                medicalrecord.setId(id);
                medicalrecord.setCasenumber(casenumber);
                medicalrecord.setRegistid(registid);
                medicalrecord.setReadme(readme);
                medicalrecord.setPresent(present);
                medicalrecord.setPresenttreat(presenttreat);
                medicalrecord.setHistory(history);
                medicalrecord.setAllergy(allergy);
                medicalrecord.setDiagnosis(diagnosis);
                medicalrecord.setHandling(handling);
                medicalrecord.setCasestate(casestate);


                //将对象添加到List集合中


            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return medicalrecord;
    }

}
