package com.software.dao;
import com.example.dao.fmeditemDao;
import com.example.model.fmeditem;
import org.junit.jupiter.api.Test;

import java.util.List;

/**
 * 单元测试：科室数据库访问层连接数据库实现添加、修改、删除、查询的操作
 */
public class fmeditemDaoTest {
    //创建数据库访问层对象
    fmeditemDao FmeditemDao = new fmeditemDao();

    /**
     * 单元测试--科室添加操作
     */
    @Test
    public void addMethod1(){
        //1.创建添加的科室测试用例
        fmeditem Fmeditem = new fmeditem();
        Fmeditem.setItemcode("F006");
        Fmeditem.setItemname("车辆接送");
        Fmeditem.setFormat("*/公里");
        Fmeditem.setPrice(2.5);
        Fmeditem.setExpclassid(1);
        Fmeditem.setDeptid(1);
        Fmeditem.setMnemoniccode("CL");
        Fmeditem.setCreationdate("2019.08.19");
        Fmeditem.setLastupdatedate("2023.07.15");
        Fmeditem.setRecordtype(3);





        //2.调用数据库访问层的方法实现添加操作
        boolean flag = FmeditemDao.addfmeditem(Fmeditem);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    /**
     * 单元测试--科室信息的修改操作
     */
    @Test
    public void updatefmeditem(){
        //1.创建修改科室测试用例
        fmeditem Fmeditem = new fmeditem();
        Fmeditem.setId(1);
        Fmeditem.setItemcode("F001");
        Fmeditem.setItemname("皮试");
        Fmeditem.setFormat("*/次");
        Fmeditem.setPrice(25.0);
        Fmeditem.setExpclassid(9);
        Fmeditem.setDeptid(2);
        Fmeditem.setMnemoniccode("PS");
        Fmeditem.setCreationdate("2019.08.15");
        Fmeditem.setLastupdatedate("2023.07.17");
        Fmeditem.setRecordtype(3);



        //2.调用数据库访问层的方法实现添加操作
        boolean flag = FmeditemDao.updatefmeditem(Fmeditem);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    /**
     * 单元测试--删除操作
     */
    @Test
    public void deleteMethod(){
        boolean flag = FmeditemDao.deletefmeditem(6);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    @Test
    public void queryfmeditem(){
        List<fmeditem> FmeditemList =  FmeditemDao.findAll();
        for(fmeditem Fmeditem : FmeditemList){
            System.out.println(Fmeditem);
        }
    }
}
