package com.example.model;

public class Checkapply {
    //id,medicalid,registid,itemid,objective,isurgent,num,creationtime,doctorid,resultoperid,checktime,result,resulttime,state,recordtype
    private Integer id;
    private Integer medicalid;
    private Integer registid;
    private Integer itemid;
    private String objective;
    private Integer urgent;
    private Integer num;
    private String creationtime;
    private Integer doctorid;
    private Integer resultoperid;
    private String checktime;
    private String result;
    private String resulttime;
    private Integer state;
    private Integer recordtype;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getMedicalid() {
        return medicalid;
    }

    public void setMedicalid(Integer medicalid) {
        this.medicalid = medicalid;
    }

    public Integer getRegistid() {
        return registid;
    }

    public void setRegistid(Integer registid) {
        this.registid = registid;
    }

    public Integer getItemid() {
        return itemid;
    }

    public void setItemid(Integer itemid) {
        this.itemid = itemid;
    }

    public String getObjective() {
        return objective;
    }

    public void setObjective(String objective) {
        this.objective = objective;
    }

    public Integer getUrgent() {
        return urgent;
    }

    public void setUrgent(Integer urgent) {
        this.urgent = urgent;
    }

    public Integer getNum() {
        return num;
    }

    public void setNum(Integer num) {
        this.num = num;
    }

    public String getCreationtime() {
        return creationtime;
    }

    public void setCreationtime(String creationtime) {
        this.creationtime = creationtime;
    }

    public Integer getDoctorid() {
        return doctorid;
    }

    public void setDoctorid(Integer doctorid) {
        this.doctorid = doctorid;
    }

    public Integer getResultoperid() {
        return resultoperid;
    }

    public void setResultoperid(Integer resultoperid) {
        this.resultoperid = resultoperid;
    }

    public String getChecktime() {
        return checktime;
    }

    public void setChecktime(String checktime) {
        this.checktime = checktime;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getResulttime() {
        return resulttime;
    }

    public void setResulttime(String resulttime) {
        this.resulttime = resulttime;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public Integer getRecordtype() {
        return recordtype;
    }

    public void setRecordtype(Integer recordtype) {
        this.recordtype = recordtype;
    }

    @Override
    public String toString() {
        return "Checkapply{" +
                "id=" + id +
                ", medicalid=" + medicalid +
                ", registid=" + registid +
                ", itemid=" + itemid +
                ", objective='" + objective + '\'' +
                ", urgent=" + urgent +
                ", num=" + num +
                ", creationtime='" + creationtime + '\'' +
                ", doctorid=" + doctorid +
                ", resultoperid=" + resultoperid +
                ", checktime='" + checktime + '\'' +
                ", result='" + result + '\'' +
                ", resulttime='" + resulttime + '\'' +
                ", state=" + state +
                ", recordtype=" + recordtype +
                '}';
    }
}
