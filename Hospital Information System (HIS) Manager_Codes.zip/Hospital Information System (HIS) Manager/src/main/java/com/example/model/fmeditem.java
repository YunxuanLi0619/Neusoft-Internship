package com.example.model;

public class fmeditem {
    //id,itemcode,itemname,format,price,expclassid,deptid,mnemoniccode,creationdate,lstupdatedate,recordtype,delmark
    private  Integer id;
    private  String itemcode;
    private  String itemname;
    private  String format;
    private  Double price;
    private  Integer expclassid;
    private Integer deptid;
    private String mnemoniccode;
    private  String creationdate;
    private  String lastupdatedate;
    private  Integer recordtype;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getItemcode() {
        return itemcode;
    }

    public void setItemcode(String itemcode) {
        this.itemcode = itemcode;
    }

    public String getItemname() {
        return itemname;
    }

    public void setItemname(String itemname) {
        this.itemname = itemname;
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Integer getExpclassid() {
        return expclassid;
    }

    public void setExpclassid(Integer expclassid) {
        this.expclassid = expclassid;
    }

    public Integer getDeptid() {
        return deptid;
    }

    public void setDeptid(Integer deptid) {
        this.deptid = deptid;
    }

    public String getMnemoniccode() {
        return mnemoniccode;
    }

    public void setMnemoniccode(String mnemoniccode) {
        this.mnemoniccode = mnemoniccode;
    }

    public String getCreationdate() {
        return creationdate;
    }

    public void setCreationdate(String creationdate) {
        this.creationdate = creationdate;
    }

    public String getLastupdatedate() {
        return lastupdatedate;
    }

    public void setLastupdatedate(String lastupdatedate) {
        this.lastupdatedate = lastupdatedate;
    }

    public Integer getRecordtype() {
        return recordtype;
    }

    public void setRecordtype(Integer recordtype) {
        this.recordtype = recordtype;
    }


    @Override
    public String toString() {
        return "fmeditem{" +
                "id=" + id +
                ", itemcode='" + itemcode + '\'' +
                ", itemname='" + itemname + '\'' +
                ", format='" + format + '\'' +
                ", price=" + price +
                ", expclassid=" + expclassid +
                ", deptid=" + deptid +
                ", mnemoniccode='" + mnemoniccode + '\'' +
                ", creationdate='" + creationdate + '\'' +
                ", lastupdatedate='" + lastupdatedate + '\'' +
                ", recordtype=" + recordtype +
                '}';
    }
}
