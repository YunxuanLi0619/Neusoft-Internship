package com.software.dao;


import com.example.dao.SettleCategoryDao;

import com.example.model.SettleCategory;
import org.junit.jupiter.api.Test;

import java.util.List;

public class SettleCategoryDaoTest {
    //创建数据库访问层对象
    SettleCategoryDao settlecategorydao = new SettleCategoryDao();

    /**
     * 单元测试--科室添加操作        id,settlecode,settlename,sequenceno ,delmark
     */
    @Test
    public void addMethod1(){
        //1.创建添加的科室测试用例
        SettleCategory settlecategory = new  SettleCategory();
        settlecategory.setSettlecode("Z008");
        settlecategory.setSettlename("支付宝");
        settlecategory.setSequenceno(8);


        //2.调用数据库访问层的方法实现添加操作
        boolean flag = settlecategorydao.addSettleCategory(settlecategory);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    /**
     * 单元测试--科室信息的修改操作
     */
    @Test
    public void updateMethod(){
        //1.创建修改科室测试用例
        SettleCategory settlecategory = new SettleCategory();
        settlecategory.setId(27);
        settlecategory.setSettlecode("Z009");
        settlecategory.setSettlename("蚂蚁金服");
        settlecategory.setSequenceno(9);

        //2.调用数据库访问层的方法实现添加操作
        boolean flag = settlecategorydao.updateSettleCategory(settlecategory);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    /**
     * 单元测试--删除操作
     */
    @Test
    public void deleteMethod(){
        boolean flag = settlecategorydao.deleteSettleCategory(5);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    @Test
    public void queryMethod(){
        List<SettleCategory> settlecategoryList =  settlecategorydao.findAll();
        for(SettleCategory settlecategory : settlecategoryList){
            System.out.println(settlecategory);
        }
    }
    
}
