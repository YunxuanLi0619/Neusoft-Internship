package com.example.dao;


import com.example.model.Prescriptiondetailed;
import com.example.util.DBCPUtil;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class PrescriptiondetailedDao {
    public static boolean addPrescriptiondetailed(Prescriptiondetailed prescriptiondetailed) {
        boolean flag = false;
        String sql = "insert into tbl_prescriptiondetailed(prescriptionid,drugsid,drugsusage,dosage,frequency,amount,state) " +
                "values(?,?,?,?,?,?,?)";
        return DBCPUtil.execUpdate(sql, prescriptiondetailed.getPrescriptionid(), prescriptiondetailed.getDrugsid(),
                prescriptiondetailed.getDrugsusage(), prescriptiondetailed.getDosage(), prescriptiondetailed.getFrequency(),
                prescriptiondetailed.getAmount(), prescriptiondetailed.getState());
    }




    public static boolean updatePrescriptiondetailed(Prescriptiondetailed prescriptiondetailed){
        boolean flag = false;
        String sql ="update tbl_prescriptiondetailed set prescriptionid=?,drugsid=?,drugsusage=?,dosage=?,frequency=?,amountstate=? where id=?";
        flag = DBCPUtil.execUpdate(sql, prescriptiondetailed.getPrescriptionid(), prescriptiondetailed.getDrugsid(),
                prescriptiondetailed.getDrugsusage(), prescriptiondetailed.getDosage(), prescriptiondetailed.getFrequency(),
                prescriptiondetailed.getAmount(), prescriptiondetailed.getState(), prescriptiondetailed.getId());
        return flag;
    }




    public static List<Prescriptiondetailed> findAll(){
        List<Prescriptiondetailed> prescriptiondetaileds = new ArrayList<>();
        //1.获取数据库连接对象
        Connection connection =  DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql ="select id,prescriptionid,drugsid,drugsusage,dosage,frequency,amount,state from tbl_prescriptiondetailed";
        try {
            pstmt = connection.prepareStatement(sql);
            rs = pstmt.executeQuery();
            Prescriptiondetailed prescriptiondetailed = null;
            while(rs.next()){
                prescriptiondetailed = new Prescriptiondetailed();
                int id= rs.getInt("id");
                int prescriptionid = rs.getInt("prescriptionid");
                int drugsid = rs.getInt("drugsid");
                String drugsusage = rs.getString("drugsusage");
                String dosage = rs.getString("dosage");
                String frequency = rs.getString("frequency");
                Double amount = rs.getDouble("amount");
                int state = rs.getInt("state");

                //每行记录封装为一个对象
                prescriptiondetailed.setId(id);
                prescriptiondetailed.setPrescriptionid(prescriptionid);
                prescriptiondetailed.setDrugsid(drugsid);
                prescriptiondetailed.setDrugsusage(drugsusage);
                prescriptiondetailed.setDosage(dosage);
                prescriptiondetailed.setFrequency(frequency);
                prescriptiondetailed.setAmount(amount);
                prescriptiondetailed.setState(state);

                //将对象添加到List集合中
                prescriptiondetaileds.add(prescriptiondetailed);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return prescriptiondetaileds;
    }
    /**
     * 功能：根据主键查询科室信息
     * @param predid
     * @return
     */
    public Prescriptiondetailed findPrescriptiondetailedByID(int predid){
        Prescriptiondetailed prescriptiondetailed = new Prescriptiondetailed();
        //1.获取数据库连接对象
        Connection connection =  DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql ="select id,prescriptionid,drugsid,drugsusage,dosage,frequency,amount,state from tbl_prescriptiondetailed where id=?";
        try {
            pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1,predid);

            rs = pstmt.executeQuery();

            if(rs.next()){
                int id= rs.getInt("id");
                int prescriptionid = rs.getInt("prescriptionid");
                int drugsid = rs.getInt("drugsid");
                String drugsusage = rs.getString("drugsusage");
                String dosage = rs.getString("dosage");
                String frequency = rs.getString("frequency");
                Double amount = rs.getDouble("amount");
                int state = rs.getInt("state");

                //每行记录封装为一个对象
                prescriptiondetailed.setId(id);
                prescriptiondetailed.setPrescriptionid(prescriptionid);
                prescriptiondetailed.setDrugsid(drugsid);
                prescriptiondetailed.setDrugsusage(drugsusage);
                prescriptiondetailed.setDosage(dosage);
                prescriptiondetailed.setFrequency(frequency);
                prescriptiondetailed.setAmount(amount);
                prescriptiondetailed.setState(state);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return prescriptiondetailed;
    }
}
