package com.example.dao;

import com.example.model.Constanttype;
import com.example.model.Disease;
import com.example.util.DBCPUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * 数据库访问层--科室信息的增删改查操作
 */
public class DiseaseDao {

    /**
     * 添加科室操作
     * @param disease
     * @return
     */
    public boolean addDisease(Disease disease){
        boolean flag = false;
        String sql ="insert into tbl_disease(diseasecode,diseasename,diseaseicd ,diseasecategory) " +
                "values(?,?,?,?)";
        return DBCPUtil.execUpdate(sql,disease.getDiseasecode(),disease.getDiseasename(),
                disease.getDiseaseicd(),disease.getDiseasecategory());
    }

    /**
     * 功能：根据科室编号修改科室信息
     * @param disease
     * @return
     */
    public boolean updateDisease(Disease disease){
        boolean flag = false;
        String sql ="update tbl_disease set diseasecode=?,diseasename=?,diseaseicd=?,diseasecategory=? where id=?";
        flag = DBCPUtil.execUpdate(sql,disease.getDiseasecode(),disease.getDiseasename(),
                disease.getDiseaseicd(),disease.getDiseasecategory(),disease.getId());
        return flag;
    }

    /**
     * 功能：根据科室编号删除科室信息
     * @param id
     * @return
     */
    public boolean deleteDisease(int id){
        boolean flag = false;
        String sql ="delete from tbl_disease where id =?";
        flag = DBCPUtil.execUpdate(sql,id);
        return flag;
    }




    /**
     * 功能：查询科室的所有信息
     * @return
     */
    public List<Disease> findAll(){
        List<Disease> diseases = new ArrayList<>();
        //1.获取数据库连接对象
        Connection connection =  DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql ="select id,diseasecode,diseasename,diseaseicd,diseasecategory from tbl_disease";
        try {
            pstmt = connection.prepareStatement(sql);
            rs = pstmt.executeQuery();
            Disease disease = null;
            while(rs.next()){
                disease = new Disease();
                int id= rs.getInt("id");
                String diseasecode = rs.getString("diseasecode");
                String diseasename = rs.getString("diseasename");
                String diseaseicd = rs.getString("diseaseicd");
                int diseasecategory = rs.getInt("diseasecategory");



                //每行记录封装为一个对象
                disease.setId(id);
                disease.setDiseasecode(diseasecode);
                disease.setDiseasename(diseasename);
                disease.setDiseaseicd(diseaseicd);
                disease.setDiseasecategory(diseasecategory);


                //将对象添加到List集合中
                diseases.add(disease);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return diseases;
    }
    /**
     * 功能：根据主键查询科室信息
     * @param contid
     * @return
     */
    public Disease findDiseaseByID(int contid){
        Disease disease = new Disease();
        //1.获取数据库连接对象
        Connection connection =  DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql ="select id,diseasecode,diseasename,diseaseicd,diseasecategory from tbl_disease where id=?";
        try {
            pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1,contid);

            rs = pstmt.executeQuery();

            if(rs.next()){
                int id= rs.getInt("id");
                String diseasecode = rs.getString("diseasecode");
                String diseasename = rs.getString("diseasename");
                String diseaseicd = rs.getString("diseaseicd");
                int diseasecategory = rs.getInt("diseasecategory");


                //每行记录封装为一个对象
                disease.setId(id);
                disease.setDiseasecode(diseasecode);
                disease.setDiseasename(diseasename);
                disease.setDiseaseicd(diseaseicd);
                disease.setDiseasecategory(diseasecategory);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return disease;
    }
}
