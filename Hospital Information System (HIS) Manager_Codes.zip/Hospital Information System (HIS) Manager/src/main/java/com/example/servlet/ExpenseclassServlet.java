package com.example.servlet;


import java.io.IOException;

import com.example.dao.expenseclassDao;

import com.example.model.expenseclass;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.List;

@WebServlet(name = "ExpenseclassServlet", value = "/ExpenseclassServlet")
public class ExpenseclassServlet extends HttpServlet {
    //创建数据库访问层对象

    expenseclassDao ExpenseclassDao = new expenseclassDao();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request,response);
    }
    /**
     * 前端控制器——执行疾病表的添加，修改，删除，查询操作
     *            添加操作的方法名：adddexpenseclass
     *            修改：updateexpenseclass
     *            删除：deleteexpenseclass
     *            根据主键查询信息：findid
     *            默认执行：查询全部信息
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String methodname = request.getParameter("method");
        if ("addexpenseclass".equals(methodname)){
            addexpenseclass(request, response);
        }else if("updateexpenseclass".equals(methodname)){
            updateexpenseclass(request, response);
        }else if("deleteexpenseclass".equals(methodname)){
            deleteExpenseclassByid(request, response);
        }else if("findid".equals(methodname)){
            findExpenseclassByid(request, response);


        }else{
            findAll(request, response);
        }
    }
    protected void addexpenseclass(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String expcode = request.getParameter("expcode");
        String expname = request.getParameter("expname");

        //创建Register对象
        expenseclass Expenseclass = new expenseclass();
        Expenseclass.setExpcode(expcode);
        Expenseclass.setExpname(expname);

        //调用数据库的添加方法
        ExpenseclassDao.addexpenseclass(Expenseclass);

        //跳转到成功页面
        findAll(request,response);
    }

    protected void updateexpenseclass(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


        int id = Integer.parseInt( request.getParameter("id"));
        String expcode = request.getParameter("expcode");
        String expname = request.getParameter("expname");

        //创建Expenseclass对象
        expenseclass Expenseclass = new expenseclass();
        Expenseclass.setId(id);
        Expenseclass.setExpcode(expcode);
        Expenseclass.setExpname(expname);

        //调用数据库的修改方法
        ExpenseclassDao.updateexpenseclass(Expenseclass);

        //跳转到成功页面
        findAll(request, response);
    }

    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void findExpenseclassByid(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        //获取费用科目编号
        int expcid=Integer.parseInt(request.getParameter("expcid"));
        //调用数据库访问层中的根据编号查询的方法
        expenseclass Expenseclass = ExpenseclassDao.findExpenseclassByid(expcid);
        //跳转到修改显示页面
        request.setAttribute("expenseclassObj",Expenseclass);
        request.getRequestDispatcher("/system/updateexpenseclass.jsp").forward(request, response);
    }


    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void findAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        List<expenseclass> expenseclasses = ExpenseclassDao.findAll();
        request.setAttribute("expenseclassObjs",expenseclasses);
        request.getRequestDispatcher("/system/displayexpenseclass.jsp").forward(request, response);
    }

    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void deleteExpenseclassByid(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //获取科室编号
        int expcid = Integer.parseInt(request.getParameter("did"));
        //调用数据库访问层中的根据编号查询的方法
        ExpenseclassDao.deleteexpenseclass(expcid);
        //跳转到修改显示页面
        findAll(request, response);
    }




}
