package com.software.dao;

import com.example.dao.DepartmentDao;
import com.example.model.Department;
import org.junit.jupiter.api.Test;

import java.util.List;

/**
 * 单元测试：科室数据库访问层连接数据库实现添加、修改、删除、查询的操作
 */
public class DepartmentDaoTest {

    //创建数据库访问层对象
    DepartmentDao departmentDao = new DepartmentDao();

    /**
     * 单元测试--科室添加操作
     */
    @Test
    public void addDepartment(){
        //1.创建添加的科室测试用例
        Department department = new Department();
        department.setDeptcode("SJ1002");
        department.setDeptname("神经科2");
        department.setDeptcategoryid(1);


        //2.调用数据库访问层的方法实现添加操作
        boolean flag = departmentDao.addDepartment(department);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    /**
     * 单元测试--科室信息的修改操作
     */
    @Test
    public void updateDepartment(){
        //1.创建修改科室测试用例
        Department department = new Department();
        department.setId(13);
        department.setDeptcode("FS1002");
        department.setDeptname("放射科2");
        department.setDeptcategoryid(1);


        //2.调用数据库访问层的方法实现添加操作
        boolean flag = departmentDao.updateDepartment(department);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    /**
     * 单元测试--删除操作
     */
    @Test
    public void deleteMethod(){
        boolean flag = departmentDao.deleteDepartment(14);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    @Test
    public void queryDepartment(){
        List<Department> departmentList =  departmentDao.findAll();
        for(Department department : departmentList){
            System.out.println(department);
        }
    }

    @Test
    public void queryDepartByID(){

        Department department=departmentDao.findDepartmentByID(8);
        System.out.println(department);
    }


}
