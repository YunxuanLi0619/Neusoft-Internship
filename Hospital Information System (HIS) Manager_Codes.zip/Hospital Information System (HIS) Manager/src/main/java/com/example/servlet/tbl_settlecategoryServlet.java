package com.example.servlet;

import com.example.dao.SettleCategoryDao;
import com.example.model.SettleCategory;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "tbl_settlecategoryServlet", value = "/tbl_settlecategoryServlet")
public class tbl_settlecategoryServlet extends HttpServlet {

    //2.创建数据库访问层对象

    SettleCategoryDao settlecategoryDao = new SettleCategoryDao();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        execute(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request,response);
    }

    //前端控制器-- 执行药品的添加，修改，删除，查询操作
    //添加：addmethod,修改：updatemethod,删除：deletemethod,根据主键查询科室信息：findid,默认执行：查询全部信息
    protected void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String methodname = request.getParameter("method");
        if("addmethod".equals(methodname)){
            //添加操作
            addSettleCategory(request,response);
        }else if("updatemethod".equals(methodname)){
            //修改操作
            updateSettleCategory(request,response);
        }else if("deletemethod".equals(methodname)){
            //删除操作
            deleteSettleCategoryById(request,response);
        }else if("findid".equals(methodname)){
            //根据主键查询数据表信息
            findSettleCategoryByID(request,response);

        }else {
            //执行查询所有记录
            findAll(request,response);
        }
    }
    //前端控制器--添加药品操作
    protected void addSettleCategory(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取客户端输入的药品信息(settlecode,settlename,sequenceno,delmark )


        String settlecode = request.getParameter("settlecode");
        String settlename = request.getParameter("settlename");
        int sequenceno = Integer.parseInt(request.getParameter("sequenceno"));


        //创建Drugs对象
        SettleCategory settleCategory = new SettleCategory();
        settleCategory.setSettlecode(settlecode);
        settleCategory.setSettlename(settlename);
        settleCategory.setSequenceno(sequenceno);



        //3.调用数据库访问层中的添加方法
        settlecategoryDao.addSettleCategory(settleCategory);

        //4.跳转到成功提示页面
        findAll(request,response);

    }
    protected void updateSettleCategory(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取客户端输入的药品信息(settlecode,settlename,sequenceno,delmark )

        int id =Integer.parseInt(request.getParameter("id"));
        String settlecode = request.getParameter("settlecode");
        String settlename = request.getParameter("settlename");
        int sequenceno = Integer.parseInt(request.getParameter("sequenceno"));


        //创建Drugs对象
        SettleCategory settleCategory = new SettleCategory();
        settleCategory.setId(id);
        settleCategory.setSettlecode(settlecode);
        settleCategory.setSettlename(settlename);
        settleCategory.setSequenceno(sequenceno);



        //3.调用数据库访问层中的添加方法
        settlecategoryDao.updateSettleCategory(settleCategory);

        //4.跳转到成功提示页面
        findAll(request,response);

    }



    protected void findAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.调用数据库访问层中的查询方法
        List<SettleCategory> settlecategorys = settlecategoryDao.findAll();
        //2.跳转到页面上
        request.setAttribute("settleCategorysObj",settlecategorys);
        request.getRequestDispatcher("/system/displaysettlecategory.jsp").forward(request,response);
    }
    protected void findSettleCategoryByID(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取科室编号
        int setid = Integer.parseInt(request.getParameter("setid"));
        //2.调用数据库访问层中的根据科室编号查询科室信息的方法
        SettleCategory settlecategory= settlecategoryDao.findSettleCategoryByID(setid);

        //3.跳转到修改显示页面
        request.setAttribute("setObj",settlecategory);
        request.getRequestDispatcher("/system/updatesettlecategory.jsp").forward(request,response);
    }

    protected void deleteSettleCategoryById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取科室编号
        int setid = Integer.parseInt(request.getParameter("did"));
        settlecategoryDao.deleteSettleCategory(setid);
        findAll(request, response);
    }


}
