package com.example.util;

import javax.sql.DataSource;
import java.sql.*;

public class DBCPUtil {
    private static DataSource ds = null;

    private static String DRIVER ="com.mysql.jdbc.Driver";
    private static String URL ="jdbc:mysql://localhost:3306/yunxuan?useSSL=false&useUnicode=true&characterEncoding=UTF-8";
    private static String USERNMAE ="root";
    private static String PASSWORD ="123456";

    /**
     * 功能：获取数据库连接对象
     * @return
     */
    public static Connection getConnection(){
        Connection connection = null;
        try {
            Class.forName(DRIVER);
            connection = DriverManager.getConnection(URL, USERNMAE, PASSWORD);
            return connection ;
        } catch (Exception e) {
            throw new RuntimeException("数据库连接异常");
        }
    }

    /**
     * 功能：关闭数据库连接对象
     * @param conn
     * @param stmt
     * @param rs
     */
    public static void release(Connection conn,Statement stmt,ResultSet rs){
        if(rs!=null){
            try {
                rs.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            rs = null;
        }
        if(stmt!=null){
            try {
                stmt.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            stmt = null;
        }
        if(conn!=null){
            try {
                conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            conn = null;
        }
    }


    /**
     * 执行单表的增、删、改操作
     * @param sql
     * @param param
     * @return
     */
    public static boolean execUpdate(String sql, Object... param) {
        Connection conn = getConnection();
        PreparedStatement pstmt = null;
        int result = 0;
        try {
            pstmt = conn.prepareStatement(sql);
            if(param!=null && param.length>0){
                for (int i = 0; i < param.length; i++) {
                    pstmt.setObject(i + 1, param[i]);
                }
            }
            result = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            release(conn, pstmt,null );
        }
        if(result > 0){
            return true;
        }
        return false;
    }

    /**
     * 功能：批量执行sql语句的操作
     * @param sqls：批量执行的sql语句
     *              insert into table1()..
     *              insert into table2()..
     * @return
     */
    public static boolean executeBatchUpdate(String[] sqls) {
        boolean flag = false;
        Connection conn = getConnection();
        Statement stmt = null;

        try {
            stmt= conn.createStatement();
            if (sqls !=null && sqls.length>0){
                for(String sql : sqls){
                    stmt.addBatch(sql);
                }
                //批量执行sql语句
                stmt.executeBatch();
                flag = true;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            release(conn, stmt,null );
        }
        return flag;
    }


}
