package com.example.dao;
import com.example.model.expenseclass;
import com.example.util.DBCPUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * 数据库访问层--科室信息的增删改查操作
 */


public class expenseclassDao {
    /**
     * 添加科室操作
     * @param Expenseclass
     * @return
     */
    public boolean addexpenseclass(expenseclass Expenseclass){
        boolean flag = false;
        String sql ="insert into tbl_expenseclass(expcode,expname) values(?,?)";
        return DBCPUtil.execUpdate(sql,Expenseclass.getExpcode(),Expenseclass.getExpname());
    }

    /**
     * 功能：根据科室编号修改科室信息
     * @param Expenseclass
     * @return
     */
    public boolean updateexpenseclass(expenseclass Expenseclass){
        boolean flag = false;
        String sql ="update tbl_expenseclass set expcode=?,expname=? where id=?";
        flag = DBCPUtil.execUpdate(sql,Expenseclass.getExpcode(),Expenseclass.getExpname(),
                Expenseclass.getId());
        return flag;
    }

    /**
     * 功能：根据科室编号删除科室信息
     * @param id
     * @return
     */
    public boolean deleteexpenseclass(int id){
        boolean flag = false;
        String sql ="delete from tbl_expenseclass where id =?";
        //String sql ="update tbl_expenseclass set delmark = 0 where id =?";
        flag = DBCPUtil.execUpdate(sql,id);
        return flag;
    }


    /**
     * 功能：查询科室的所有信息
     * @return
     */
    public List<expenseclass> findAll(){
        List<expenseclass> expenseclasses = new ArrayList<>();
        //1.获取数据库连接对象
        Connection connection =  DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql ="select id,expcode,expname from tbl_expenseclass";
        try {
            pstmt = connection.prepareStatement(sql);
            rs = pstmt.executeQuery();
            expenseclass Expenseclass = null;
            while(rs.next()){
                Expenseclass = new expenseclass();
                int id = rs.getInt("id");
                String expcode = rs.getString("expcode");
                String expname = rs.getString("expname");


                //每行记录封装为一个对象
                Expenseclass.setId(id);
                Expenseclass.setExpcode(expcode);
                Expenseclass.setExpname(expname);


                //将对象添加到List集合中
                expenseclasses.add(Expenseclass);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return expenseclasses;
    }

    /**
     * 功能：根据主键查询信息
     * @param expcid
     * @return
     */


    public expenseclass findExpenseclassByid(int expcid){
        expenseclass Expenseclass = new expenseclass();
        //1.获取数据库连接对象
        Connection connection =  DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql ="select id,expcode,expname from tbl_expenseclass where id=?";
        try {
            pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1,expcid);
            rs = pstmt.executeQuery();
            if(rs.next()){
                int id = rs.getInt("id");
                String expcode = rs.getString("expcode");
                String expname = rs.getString("expname");

                //每行记录封装为一个对象
                Expenseclass.setId(id);
                Expenseclass.setExpcode(expcode);
                Expenseclass.setExpname(expname);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return Expenseclass;
    }
}
