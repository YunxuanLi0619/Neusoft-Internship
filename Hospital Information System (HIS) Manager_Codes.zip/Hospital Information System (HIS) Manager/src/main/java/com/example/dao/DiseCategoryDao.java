package com.example.dao;

import com.example.model.DiseCategory;
import com.example.util.DBCPUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DiseCategoryDao {

    /**
     * 添加科室操作
     * @param disecategory
     * @return
     *
     *     private Integer id;
     *     private String dicacode;
     *     private String dicaname;
     *     private Integer sequenceno;
     *     private Integer dicatype;
     *     private Integer delmark;
     *
     */
    public boolean addDiseCategory(DiseCategory disecategory){
        boolean flag = false;
        String sql ="insert into tbl_disecategory(dicacode,dicaname,sequenceno,dicatype) " +
                "values(?,?,?,?)";
        return DBCPUtil.execUpdate(sql,disecategory.getDicacode(),disecategory.getDicaname(),
                disecategory.getSequenceno(),disecategory.getDicatype());
    }

    /**
     * 功能：根据科室编号修改科室信息
     * @param disecategory
     * @return
     */
    public boolean updateDiseCategory(DiseCategory disecategory){
        boolean flag = false;
        String sql ="update tbl_disecategory set dicacode=?,dicaname=?,sequenceno=?,dicatype=? where id=?";
        flag = DBCPUtil.execUpdate(sql,disecategory.getDicacode(),disecategory.getDicaname(),
                disecategory.getSequenceno(),disecategory.getDicatype(),disecategory.getId());
        return flag;
    }

    /**
     * 功能：根据科室编号删除科室信息
     * @param id
     * @return
     */
    public boolean deleteDiseCategory(int id){
        boolean flag = false;
        String sql ="delete from tbl_disecategory where id =?";
        //String sql ="update tbl_disecategory set delmark = 0 where id =?";
        flag = DBCPUtil.execUpdate(sql,id);
        return flag;
    }



    /**
     * 功能：查询科室的所有信息
     * @return
     */
    public List<DiseCategory> findAll(){
        List<DiseCategory> disecategorys = new ArrayList<>();
        //1.获取数据库连接对象
        Connection connection =  DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql ="select id,dicacode,dicaname,sequenceno,dicatype from tbl_disecategory";
        try {
            pstmt = connection.prepareStatement(sql);
            rs = pstmt.executeQuery();
            DiseCategory disecategory = null;
            while(rs.next()){
                disecategory = new DiseCategory();
                int id= rs.getInt("id");
                String dicacode = rs.getString("dicacode");
                String dicaname = rs.getString("dicaname");
                int sequenceno = rs.getInt("sequenceno");
                int dicatype= rs.getInt("dicatype");


                //每行记录封装为一个对象
                disecategory.setId(id);
                disecategory.setDicacode(dicacode);
                disecategory.setDicaname(dicaname);
                disecategory.setSequenceno(sequenceno);
                disecategory.setDicatype(dicatype);


                //将对象添加到List集合中
                disecategorys.add(disecategory);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return disecategorys;
    }


    /**
     * 功能：主键查询科室信息
     * @param neoid
     * @return
     */
    public DiseCategory findDCByID(int neoid){

        DiseCategory disecategory = new DiseCategory();
        //1.获取数据库连接对象
        Connection connection =  DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql ="select id,dicacode,dicaname,sequenceno,dicatype  from tbl_disecategory where id=?";
        try {
            pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1,neoid);
            rs = pstmt.executeQuery();

            if (rs.next()){

                int id= rs.getInt("id");
                String dicacode = rs.getString("dicacode");
                String dicaname = rs.getString("dicaname");
                int sequenceno = rs.getInt("sequenceno");
                int dicatype= rs.getInt("dicatype");


                //每行记录封装为一个对象
                disecategory.setId(id);
                disecategory.setDicacode(dicacode);
                disecategory.setDicaname(dicaname);
                disecategory.setSequenceno(sequenceno);
                disecategory.setDicatype(dicatype);




            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return disecategory;
    }
    
}
