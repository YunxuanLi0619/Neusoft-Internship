package com.software.dao;

import com.example.dao.UserDao;
import com.example.model.User;
import org.junit.jupiter.api.Test;
import java.util.List;

public class UserDaoTest{
    //创建数据库访问层对象
    UserDao userdao = new UserDao();

    /**
     * 单元测试--科室添加操作   id,username,password,realname,usetype,doctitleid,deptid,registleid,delmark
     */
    @Test
    public void addMethod1(){
        //1.创建添加的科室测试用例
        User user = new  User();
        user.setUsername("zhangyi");
        user.setPassword("125789");
        user.setRealname("张一");
        user.setUsetype(3);
        user.setDoctitleid(12);
        user.setDeptid(1);
        user.setRegistleid(1);


        //2.调用数据库访问层的方法实现添加操作
        boolean flag = userdao.addUser(user);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    /**
     * 单元测试--科室信息的修改操作
     */
    @Test
    public void updateMethod(){
        //1.创建修改科室测试用例
        User user = new User();
        user.setId(4);
        user.setUsername("zhangyi");
        user.setPassword("125789");
        user.setRealname("张一");
        user.setUsetype(3);
        user.setDoctitleid(12);
        user.setDeptid(1);
        user.setRegistleid(1);



        //2.调用数据库访问层的方法实现添加操作
        boolean flag = userdao.updateUser(user);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    /**
     * 单元测试--删除操作
     */
    @Test
    public void deleteMethod(){
        boolean flag = userdao.deleteUser(5);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    @Test
    public void queryMethod(){
        List<User> userList =  userdao.findAll();
        for(User user : userList){
            System.out.println(user);
        }
    }



}

