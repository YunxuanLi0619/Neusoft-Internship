package com.example.dao;

import com.example.model.Checkapply;
import com.example.util.DBCPUtil;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CheckapplyDao {


    public boolean addCheckapply(Checkapply checkapply){
        boolean flag = false;
        String sql ="insert into tbl_checkapply(medicalid,registid,itemid,objective,urgent,num,creationtime,doctorid,resultoperid,checktime,result,resulttime,state,recordtype) " +
                "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        return DBCPUtil.execUpdate(sql,checkapply.getMedicalid(),checkapply.getRegistid(),checkapply.getItemid(),
                checkapply.getObjective(),checkapply.getUrgent(),checkapply.getNum(),checkapply.getCreationtime(),
                checkapply.getDoctorid(),checkapply.getResultoperid(),checkapply.getChecktime(),checkapply.getResult(),
                checkapply.getResulttime(),checkapply.getState(),checkapply.getRecordtype());
    }

    public static boolean updateCheckapply(Checkapply checkapply){
        boolean flag = false;
        String sql ="update tbl_checkapply set resultoperid=?,checktime=?,result=?,resulttime=?,state=?,recordtype=? where id=?";
        flag = DBCPUtil.execUpdate(sql,checkapply.getResultoperid(),checkapply.getChecktime(),checkapply.getResult(),
                checkapply.getResulttime(),checkapply.getState(),checkapply.getRecordtype(),checkapply.getId());
        return flag;
    }

    public boolean deleteCheckapply(int id){
        boolean flag = false;
        String sql ="update tbl_checkapply set state = 7 where id =?";
        flag = DBCPUtil.execUpdate(sql,id);
        return flag;
    }


    public List<Checkapply> findAll(){
        List<Checkapply> checkapplies = new ArrayList<>();
        //1.获取数据库连接对象
        Connection connection =  DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql ="select id,medicalid,registid,itemid,objective,urgent,num,creationtime,doctorid,resultoperid,checktime,result,resulttime,state,recordtype from tbl_checkapply where state < 7";
        try {
            pstmt = connection.prepareStatement(sql);
            rs = pstmt.executeQuery();
            Checkapply checkapply = null;
            while(rs.next()){
                checkapply = new Checkapply();
                int id= rs.getInt("id");
                int medicalid = rs.getInt("medicalid");
                int registid = rs.getInt("registid");
                int itemid = rs.getInt("itemid");
                String objective = rs.getString("objective");
                int urgent = rs.getInt("urgent");
                int num = rs.getInt("num");
                String creationtime = rs.getString("creationtime");
                int doctorid = rs.getInt("doctorid");
                int resultoperid = rs.getInt("resultoperid");
                String checktime = rs.getString("checktime");
                String result = rs.getString("result");
                String resulttime = rs.getString("resulttime");
                int state = rs.getInt("state");
                int recordtype = rs.getInt("recordtype");

                //每行记录封装为一个对象
                checkapply.setId(id);
                checkapply.setMedicalid(medicalid);
                checkapply.setRegistid(registid);
                checkapply.setItemid(itemid);
                checkapply.setObjective(objective);
                checkapply.setUrgent(urgent);
                checkapply.setNum(num);
                checkapply.setCreationtime(creationtime);
                checkapply.setDoctorid(doctorid);
                checkapply.setResultoperid(resultoperid);
                checkapply.setChecktime(checktime);
                checkapply.setResult(result);
                checkapply.setResulttime(resulttime);
                checkapply.setState(state);
                checkapply.setRecordtype(recordtype);

                //将对象添加到List集合中
                checkapplies.add(checkapply);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return checkapplies;
    }

    public Checkapply findCheckapplyByID(int checkapplyid){
        Checkapply checkapply = new Checkapply();
        //1.获取数据库连接对象
        Connection connection =  DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql ="select id,medicalid,registid,itemid,objective,urgent,num,creationtime,doctorid,resultoperid,checktime,result,resulttime,state,recordtype from tbl_checkapply where id=?";
        try {
            pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1,checkapplyid);
            rs = pstmt.executeQuery();


            if(rs.next()){

                int id = rs.getInt("id");
                int medicalid = rs.getInt("medicalid");
                int registid = rs.getInt("registid");
                int itemid = rs.getInt("itemid");
                String objective = rs.getString("objective");
                int urgent = rs.getInt("urgent");
                int num = rs.getInt("num");
                String creationtime = rs.getString("creationtime");
                int doctorid = rs.getInt("doctorid");
                int resultoperid = rs.getInt("resultoperid");
                String checktime = rs.getString("checktime");
                String result = rs.getString("result");
                String resulttime = rs.getString("resulttime");
                int state = rs.getInt("state");
                int recordtype = rs.getInt("recordtype");

                //每行记录封装为一个对象
                checkapply.setId(id);
                checkapply.setMedicalid(medicalid);
                checkapply.setRegistid(registid);
                checkapply.setItemid(itemid);
                checkapply.setObjective(objective);
                checkapply.setUrgent(urgent);
                checkapply.setNum(num);
                checkapply.setCreationtime(creationtime);
                checkapply.setDoctorid(doctorid);
                checkapply.setResultoperid(resultoperid);
                checkapply.setChecktime(checktime);
                checkapply.setResult(result);
                checkapply.setResulttime(resulttime);
                checkapply.setState(state);
                checkapply.setRecordtype(recordtype);


            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return checkapply;
    }
}
