package com.example.dao;

import com.example.model.Prescription;
import com.example.util.DBCPUtil;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PrescriptionDao {
    public static boolean addPrescription(Prescription prescription){
        boolean flag = false;
        String sql ="insert into tbl_prescription(medicalid,registid,userid,prescriptionname,prescriptiontime,prescriptionstate) " +
                "values(?,?,?,?,?,?)";
        return DBCPUtil.execUpdate(sql,prescription.getMedicalid(),prescription.getRegistid(),prescription.getUserid(),
                prescription.getPrescriptionname(),prescription.getPrescriptiontime(),prescription.getPrescriptionstate());
    }


    public static boolean updatePrescription(Prescription prescription){
        boolean flag = false;
        String sql ="update tbl_prescription set medicalid=?,registid=?,userid=?,prescriptionname=?,prescriptiontime=?,prescriptionstate=? where id=?";
        flag = DBCPUtil.execUpdate(sql,prescription.getMedicalid(),prescription.getRegistid(),prescription.getUserid(),
                prescription.getPrescriptionname(),prescription.getPrescriptiontime(),prescription.getPrescriptionstate(),
                prescription.getId());
        return flag;
    }





    public static List<Prescription> findAll(){
        List<Prescription> prescriptions = new ArrayList<>();
        //1.获取数据库连接对象
        Connection connection =  DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql ="select id,medicalid,registid,userid,prescriptionname,prescriptiontime,prescriptionstate from tbl_prescription where prescriptionstate < 3";
        try {
            pstmt = connection.prepareStatement(sql);
            rs = pstmt.executeQuery();
            Prescription prescription = null;
            while(rs.next()){
                prescription = new Prescription();
                int id= rs.getInt("id");
                int medicalid = rs.getInt("medicalid");
                int registid = rs.getInt("registid");
                int userid = rs.getInt("userid");
                String prescriptionname = rs.getString("prescriptionname");
                String prescriptiontime = rs.getString("prescriptiontime");
                int prescriptionstate = rs.getInt("prescriptionstate");

                //每行记录封装为一个对象
                prescription.setId(id);
                prescription.setMedicalid(medicalid);
                prescription.setRegistid(registid);
                prescription.setUserid(userid);
                prescription.setPrescriptionname(prescriptionname);
                prescription.setPrescriptiontime(prescriptiontime);
                prescription.setPrescriptionstate(prescriptionstate);

                //将对象添加到List集合中
                prescriptions.add(prescription);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return prescriptions;
    }
    /**
     * 功能：根据主键查询科室信息
     * @param presid
     * @return
     */
    public Prescription findPrescriptionByID(int presid){
        Prescription prescription = new Prescription();
        //1.获取数据库连接对象
        Connection connection =  DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql ="select id,medicalid,registid,userid,prescriptionname,prescriptiontime,prescriptionstate from tbl_prescription where id=?";
        try {
            pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1,presid);

            rs = pstmt.executeQuery();

            if(rs.next()){
                int id= rs.getInt("id");
                int medicalid = rs.getInt("medicalid");
                int registid = rs.getInt("registid");
                int userid = rs.getInt("userid");
                String prescriptionname = rs.getString("prescriptionname");
                String prescriptiontime = rs.getString("prescriptiontime");
                int prescriptionstate = rs.getInt("prescriptionstate");

                //每行记录封装为一个对象
                prescription.setId(id);
                prescription.setMedicalid(medicalid);
                prescription.setRegistid(registid);
                prescription.setUserid(userid);
                prescription.setPrescriptionname(prescriptionname);
                prescription.setPrescriptiontime(prescriptiontime);
                prescription.setPrescriptionstate(prescriptionstate);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return prescription;
    }
    public static boolean deletePrescription(int id){
        boolean flag = false;
        String sql ="update tbl_prescription set prescriptionstate = 3 where id =?";
        flag = DBCPUtil.execUpdate(sql,id);
        return flag;
    }
}
