package com.example.dao;

import com.example.model.Register;
import com.example.model.expenseclass;
import com.example.util.DBCPUtil;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;



public class RegisterDao {
    /**
     * 数据库访问层--患者挂号信息的增改查操作
     */


        /**
         * 添加患者挂号信息操作
         * @param register
         * @return
         */
        public boolean addRegister(Register register){
            boolean flag = false;
            String sql ="insert into tbl_register(casenumber,realname,gender,idnumber,birthdate," +
                    "age,agetype,homeaddress,noon,deptid,userid,registleid,settleid,isbook," +
                    "registtime,registerid,visitstate,cancelflag) " + "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,now(),?,1,0)";
            return DBCPUtil.execUpdate(sql,register.getCasenumber(),register.getRealname(),register.getGender()
                    ,register.getIdnumber(),register.getBirthdate(),register.getAge(),register.getAgetype(),register.getHomeaddress(),register.getNoon()
                    ,register.getDeptid(),register.getUserid(),register.getRegistleid(),register.getSettleid(),register.getIsbook()
                    ,register.getRegisterid());
        }

        /**
         * 功能：根据科室编号修改患者挂号信息
         * @param register
         * @return
         */
        public boolean updateRegister(Register register){
            boolean flag = false;
            String sql ="update tbl_register set visitstate=? where id=?";
            flag = DBCPUtil.execUpdate(sql,register.getVisitstate(),register.getId());
            return flag;
        }
    public boolean cancelRegisterById(Register register){
        boolean flag = false;
        String sql ="update tbl_register set cancelflag=1, canceltime=now() where id=?";
        flag = DBCPUtil.execUpdate(sql,register.getId());
        return flag;
    }



        /**
         * 功能：查询患者挂号的所有信息
         * @return
         */
        public List<Register> findAll(){
            List<Register> registers = new ArrayList<>();
            //1.获取数据库连接对象
            Connection connection =  DBCPUtil.getConnection();
            PreparedStatement pstmt = null;
            ResultSet rs = null;
            String sql ="select id,casenumber,realname,gender,idnumber,birthdate," +
                    "age,agetype,homeaddress,noon,deptid,userid,registleid,settleid,isbook," +
                    "registtime,registerid,visitstate from tbl_register where cancelflag=0";
            try {
                pstmt = connection.prepareStatement(sql);
                rs = pstmt.executeQuery();
                Register register = null;
                while(rs.next()){
                    register = new Register();
                    int id = rs.getInt("id");
                    String casenumber = rs.getString("casenumber");
                    String realname = rs.getString("realname");
                    int gender = rs.getInt("gender");
                    String idnumber = rs.getString("idnumber");
                    String birthdate = rs.getString("birthdate");
                    int age = rs.getInt("age");
                    String agetype = rs.getString("agetype");
                    String homeaddress = rs.getString("homeaddress");
                    String noon = rs.getString("noon");
                    int deptid = rs.getInt("deptid");
                    int userid = rs.getInt("userid");
                    int registleid = rs.getInt("registleid");
                    int settleid = rs.getInt("settleid");
                    String isbook = rs.getString("isbook");
                    String registtime = rs.getString("registtime");
                    int registerid = rs.getInt("registerid");
                    int visitstate = rs.getInt("visitstate");



                    //每行记录封装为一个对象
                    register.setId(id);
                    register.setCasenumber(casenumber);
                    register.setRealname(realname);
                    register.setGender(gender);
                    register.setIdnumber(idnumber);
                    register.setBirthdate(birthdate);
                    register.setAge(age);
                    register.setAgetype(agetype);
                    register.setHomeaddress(homeaddress);
                    register.setNoon(noon);
                    register.setDeptid(deptid);
                    register.setUserid(userid);
                    register.setRegistleid(registleid);
                    register.setSettleid(settleid);
                    register.setIsbook(isbook);
                    register.setRegisttime(registtime);
                    register.setRegisterid(registerid);
                    register.setVisitstate(visitstate);

                    //将对象添加到List集合中
                    registers.add(register);

                }

            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                DBCPUtil.release(connection,pstmt,rs);
            }
            return registers;
        }
    /**
     * 功能：根据主键查询信息
     * @param expcid
     * @return
     */


    public Register findRegisterByid(int regid){
        Register register = new Register();
        //1.获取数据库连接对象
        Connection connection =  DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql ="select id,casenumber,realname,gender,idnumber,birthdate," +
                "age,agetype,homeaddress,noon,deptid,userid,registleid,settleid,isbook," +
                "registtime,registerid,visitstate from tbl_register where id=?";
        try {
            pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1,regid);
            rs = pstmt.executeQuery();
            if(rs.next()){
             register = new Register();
                int id = rs.getInt("id");
                String casenumber = rs.getString("casenumber");
                String realname = rs.getString("realname");
                int gender = rs.getInt("gender");
                String idnumber = rs.getString("idnumber");
                String birthdate = rs.getString("birthdate");
                int age = rs.getInt("age");
                String agetype = rs.getString("agetype");
                String homeaddress = rs.getString("homeaddress");
                String noon = rs.getString("noon");
                int deptid = rs.getInt("deptid");
                int userid = rs.getInt("userid");
                int registleid = rs.getInt("registleid");
                int settleid = rs.getInt("settleid");
                String isbook = rs.getString("isbook");
                String registtime = rs.getString("registtime");
                int registerid = rs.getInt("registerid");
                int visitstate = rs.getInt("visitstate");



                //每行记录封装为一个对象
                register.setId(id);
                register.setCasenumber(casenumber);
                register.setRealname(realname);
                register.setGender(gender);
                register.setIdnumber(idnumber);
                register.setBirthdate(birthdate);
                register.setAge(age);
                register.setAgetype(agetype);
                register.setHomeaddress(homeaddress);
                register.setNoon(noon);
                register.setDeptid(deptid);
                register.setUserid(userid);
                register.setRegistleid(registleid);
                register.setSettleid(settleid);
                register.setIsbook(isbook);
                register.setRegisttime(registtime);
                register.setRegisterid(registerid);
                register.setVisitstate(visitstate);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return register;
    }

}


