package com.example.model;

public class expenseclass {
    //id,expcode,expname,delmark
    private  Integer id;
    private  String expcode;
    private  String expname;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getExpcode() {
        return expcode;
    }

    public void setExpcode(String expcode) {
        this.expcode = expcode;
    }

    public String getExpname() {
        return expname;
    }

    public void setExpname(String expname) {
        this.expname = expname;
    }

    @Override
    public String toString() {
        return "expenseclass{" +
                "id=" + id +
                ", expcode='" + expcode + '\'' +
                ", expname='" + expname + '\'' +
                '}';
    }
}
