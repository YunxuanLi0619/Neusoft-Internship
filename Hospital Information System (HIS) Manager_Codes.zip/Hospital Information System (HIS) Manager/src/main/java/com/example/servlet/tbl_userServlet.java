package com.example.servlet;

import com.example.dao.ConstantItemDao;
import com.example.dao.DepartmentDao;
import com.example.dao.RegistLevelDao;
import com.example.dao.UserDao;
import com.example.model.*;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "tbl_userServlet", value = "/tbl_userServlet")
public class tbl_userServlet extends HttpServlet {
    //2.创建数据库访问层对象
    UserDao userdao = new UserDao();
    ConstantItemDao constantitemdao = new ConstantItemDao();
    RegistLevelDao registleveldao = new RegistLevelDao();
    DepartmentDao departmentdao = new DepartmentDao();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request,response);
    }

    /**前端控制器 执行科室添加删除。。。工作
     * 添加方法addmethod
     * updatemethod
     * deletemethod
     * 根据主键查询科室信息:findid
     * 默认执行：查询全部信息
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String methodname = request.getParameter("method");
        if("addmethod".equals(methodname)){
            //添加操作
            addUser(request,response);
        }else if("updatemethod".equals(methodname)){

            //修改
            updateUser(request,response);
        }else if("deletemethod".equals(methodname)){

            //删除
            deleteUserById(request,response);
        }else if("findid".equals(methodname)) {

            //按照特定id查找
            findUserById(request, response);
        }
        else if("addinput".equals(methodname)){

            addinput(request,response);

        }else{

            //执行全部操作
            findAll(request,response);

        }


    }
    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */

    protected void addUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取客户端科室信息 id,username,password,realname,usetype,doctitleid,deptid,registleid,delmark

        String tbl_username = request.getParameter("username");
        String tbl_password = request.getParameter("password");
        String tbl_realname = request.getParameter("realname");
        int tbl_usetype = Integer.parseInt(request.getParameter("usetype"));
        int tbl_doctitleid = Integer.parseInt(request.getParameter("doctitleid"));
        int tbl_deptid = Integer.parseInt(request.getParameter("deptid"));
        int tbl_registleid = Integer.parseInt(request.getParameter("registleid"));



        //创建user对象
        User user = new User();
        user.setUsername(tbl_username);
        user.setPassword(tbl_password);
        user.setRealname(tbl_realname);
        user.setUsetype(tbl_usetype);
        user.setDoctitleid(tbl_doctitleid);
        user.setDeptid(tbl_deptid);
        user.setRegistleid(tbl_registleid);

        //3.调取数据库访问层中的
        userdao.addUser(user);


        //4.跳转到成功页面
        findAll(request,response);


    }


    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */

    protected void updateUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取客户端科室信息 id,username,password,realname,usetype,doctitleid,deptid,registleid,delmark

        int id = Integer.parseInt(request.getParameter("id"));
        String tbl_username = request.getParameter("username");
        String tbl_password = request.getParameter("password");
        String tbl_realname = request.getParameter("realname");
        int tbl_usetype = Integer.parseInt(request.getParameter("usetype"));
        int tbl_doctitleid = Integer.parseInt(request.getParameter("doctitleid"));
        int tbl_deptid = Integer.parseInt(request.getParameter("deptid"));
        int tbl_registleid = Integer.parseInt(request.getParameter("registleid"));



        //创建user对象
        User user = new User();
        user.setId(id);
        user.setUsername(tbl_username);
        user.setPassword(tbl_password);
        user.setRealname(tbl_realname);
        user.setUsetype(tbl_usetype);
        user.setDoctitleid(tbl_doctitleid);
        user.setDeptid(tbl_deptid);
        user.setRegistleid(tbl_registleid);

        //3.调取数据库访问层中的
        userdao.updateUser(user);


        //4.跳转到成功页面
        findAll(request,response);


    }
    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void deleteUserById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {
        //1。获取科室编号
        int userid = Integer.parseInt(request.getParameter("did"));
        //2.调用
        userdao.deleteUser(userid);
        //3.跳转到修改页面
        findAll(request,response);

    }

    /**
     *功能：根据编号查询科室信息
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void findUserById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {//1获取科室编号
        int userid = Integer.parseInt(request.getParameter("userid"));
        //2.调用数据库访问层中编号查询信息的方法
        User user = userdao.findUserByID(userid);
        //3.跳转到修改显示页面
        request.setAttribute("userobj",user);
        List<Department> departments = departmentdao.findAll();
        List<RegistLevel> registlevels = registleveldao.findAll();
        List<ConstantItem> constantitems = constantitemdao.findAll();
        request.setAttribute("departmentObjs",departments);
        request.setAttribute("registlevelObjs",registlevels);
        request.setAttribute("constantitemObjs",constantitems);
        request.getRequestDispatcher("/system/updateuser.jsp").forward(request,response);

    }

    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void findAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
    {

        List<User> users = userdao.findAll();
        request.setAttribute("userObjs",users);
        request.getRequestDispatcher("/system/displayuser.jsp").forward(request,response);



    }
    protected void addinput(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{

        List<Department> departments = departmentdao.findAll();
        List<RegistLevel> registlevels = registleveldao.findAll();
        List<ConstantItem> constantitems = constantitemdao.findAll();
        request.setAttribute("departmentObjs",departments);
        request.setAttribute("registlevelObjs",registlevels);
        request.setAttribute("constantitemObjs",constantitems);
        request.getRequestDispatcher("/system/adduser.jsp").forward(request,response);


    }


}
