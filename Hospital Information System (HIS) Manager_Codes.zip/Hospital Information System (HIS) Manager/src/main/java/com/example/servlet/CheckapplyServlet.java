package com.example.servlet;

import com.example.dao.*;
import com.example.model.*;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "CheckapplyServlet", value = "/CheckapplyServlet")
public class CheckapplyServlet extends HttpServlet {

    CheckapplyDao checkapplyDao = new CheckapplyDao();
    MedicalrecordDao medicalrecordDao = new MedicalrecordDao();
    RegisterDao registerDao = new RegisterDao();
    fmeditemDao fmeditemDao = new fmeditemDao();
    UserDao userDao = new UserDao();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request, response);

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request, response);

    }

    protected void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String methodname = request.getParameter("method");
        if ("addmethod".equals(methodname)) {
            addCheckapply(request, response);
        } else if ("updatemethod".equals(methodname)) {
            updateCheckapply(request, response);
        } else if ("deletemethod".equals(methodname)) {
            deleteCheckapplyById(request,response);

        } else if ("findid".equals(methodname)) {
            findCheckapplyById(request,response);
        } else if ("addinput".equals(methodname)) {
            addinput(request, response);

        } else {
            findAll(request, response);
        }
    }

    protected void addCheckapply(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        int medicalid = Integer.parseInt(request.getParameter("medicalid"));
        int registid = Integer.parseInt(request.getParameter("registid"));
        int itemid = Integer.parseInt(request.getParameter("itemid"));
        String objective = request.getParameter("objective");
        int urgent = Integer.parseInt(request.getParameter("urgent"));
        int num = Integer.parseInt(request.getParameter("num"));
        String creationtime = request.getParameter("creationtime");
        int doctorid = Integer.parseInt(request.getParameter("doctorid"));
        int resultoperid = Integer.parseInt(request.getParameter("resultoperid"));
        String checktime = request.getParameter("checktime");
        String result = request.getParameter("result");
        String resulttime = request.getParameter("resulttime");
        int state = Integer.parseInt(request.getParameter("state"));
        int recordtype = Integer.parseInt(request.getParameter("recordtype"));

        Checkapply checkapply = new Checkapply();

        checkapply.setMedicalid(medicalid);
        checkapply.setRegistid(registid);
        checkapply.setItemid(itemid);
        checkapply.setObjective(objective);
        checkapply.setUrgent(urgent);
        checkapply.setNum(num);
        checkapply.setCreationtime(creationtime);
        checkapply.setDoctorid(doctorid);
        checkapply.setResultoperid(resultoperid);
        checkapply.setChecktime(checktime);
        checkapply.setResult(result);
        checkapply.setResulttime(resulttime);
        checkapply.setState(state);
        checkapply.setRecordtype(recordtype);

        checkapplyDao.addCheckapply(checkapply);

        findAll(request,response);


    }

    protected void updateCheckapply(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        int id = Integer.parseInt(request.getParameter("id"));
        int resultoperid = Integer.parseInt(request.getParameter("resultoperid"));
        String checktime = request.getParameter("checktime");
        String result = request.getParameter("result");
        String resulttime = request.getParameter("resulttime");
        int state = Integer.parseInt(request.getParameter("state"));

        Checkapply checkapply = new Checkapply();
        checkapply.setId(id);
        checkapply.setResultoperid(resultoperid);
        checkapply.setChecktime(checktime);
        checkapply.setResult(result);
        checkapply.setResulttime(resulttime);
        checkapply.setState(state);

        checkapplyDao.updateCheckapply(checkapply);


        findAll(request,response);


    }

    protected void findAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Checkapply> checkapplies = checkapplyDao.findAll();
        request.setAttribute("checkapplyObjs", checkapplies);
        request.getRequestDispatcher("/system/displaycheckapply.jsp").forward(request, response);
    }

    protected void findCheckapplyById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

            int checkapplyid = Integer.parseInt(request.getParameter("checkapplyid"));
            Checkapply checkapply = checkapplyDao.findCheckapplyByID(checkapplyid);
            request.setAttribute("checkapplyObj", checkapply);
            List<User> users = userDao.findAll();
            request.setAttribute("userObjs",users);
            request.getRequestDispatcher("/system/updatecheckapply.jsp").forward(request,response);

        }

    protected void deleteCheckapplyById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int checkapplyid = Integer.parseInt(request.getParameter("did"));
        checkapplyDao.deleteCheckapply(checkapplyid);
        findAll(request, response);
    }

    protected void addinput(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Medicalrecord> medicalrecords = medicalrecordDao.findAll();
        request.setAttribute("medicalrecordObj",medicalrecords);
        List<Register> registers = registerDao.findAll();
        request.setAttribute("registerObjs",medicalrecords);
        List<fmeditem> fmeditems = fmeditemDao.findAll();
        request.setAttribute("fmeditemObjs", fmeditems);
        List<User> users = userDao.findAll();
        request.setAttribute("userObjs",users);
        request.getRequestDispatcher("/system/addcheckapply.jsp").forward(request,response);
    }

}


