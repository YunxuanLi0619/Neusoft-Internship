package com.software.dao;

import com.example.dao.PrescriptionDao;
import com.example.model.Prescription;
import org.junit.jupiter.api.Test;

import java.util.List;

public class PDTest {
    Prescription prescription = new Prescription();


    /**
     * 单元测试--科室添加操作
     */
    @Test
    public void addMethod1(){
        //1.创建添加的科室测试用例
        Prescription prescription = new Prescription();
        prescription.setMedicalid(11);
        prescription.setRegistid(11);
        prescription.setUserid(11);
        prescription.setPrescriptionname("砒霜");
        prescription.setPrescriptiontime("2205/1/2");
        prescription.setPrescriptionstate(1);

        //2.调用数据库访问层的方法实现添加操作
        boolean flag = PrescriptionDao.addPrescription(prescription);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    /**
     * 单元测试--科室信息的修改操作 只能改状态
     */
    @Test
    public void updatePrescription(){
        Prescription prescription = new Prescription();
        prescription.setId(6);
        prescription.setPrescriptionstate(1);


        //2.调用数据库访问层的方法实现添加操作

        boolean flag = PrescriptionDao.updatePrescription(prescription);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    /**
     * 单元测试--删除操作
     */



    @Test
    public void queryPrescription(){
        List<Prescription> PrescriptionList = PrescriptionDao.findAll();
        for(Prescription Prescription : PrescriptionList){
            System.out.println(Prescription);
        }
    }


}
