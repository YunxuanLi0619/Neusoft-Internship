package com.example.model;

/**
 * 实体类--科室
 */
public class Department {
    //id, deptcode,deptname,  depttype
    private Integer id;
    private String deptcode;
    private String deptname;
    private Integer deptcategoryid;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDeptcode() {
        return deptcode;
    }

    public void setDeptcode(String deptcode) {
        this.deptcode = deptcode;
    }

    public String getDeptname() {
        return deptname;
    }

    public void setDeptname(String deptname) {
        this.deptname = deptname;
    }

    public Integer getDeptcategoryid() {
        return deptcategoryid;
    }

    public void setDeptcategoryid(Integer deptcategoryid) {
        this.deptcategoryid = deptcategoryid;
    }

    @Override
    public String toString() {
        return "Department{" +
                "id=" + id +
                ", deptcode='" + deptcode + '\'' +
                ", deptname='" + deptname + '\'' +
                ", deptcategoryid=" + deptcategoryid +
                '}';
    }
}
