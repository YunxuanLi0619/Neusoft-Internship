package com.example.model;

public class Medicalrecord {
    //id,casenumber,registid,readme,present,presenttreat,history,allergy,diagnosis,handling,casestate
    private Integer id;
    private String casenumber;
    private Integer registid;
    private String readme;
    private String present;
    private String presenttreat;
    private String history;
    private String allergy;
    private String diagnosis;
    private String handling;
    private Integer casestate;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCasenumber() {
        return casenumber;
    }

    public void setCasenumber(String casenumber) {
        this.casenumber = casenumber;
    }

    public Integer getRegistid() {
        return registid;
    }

    public void setRegistid(Integer registid) {
        this.registid = registid;
    }

    public String getReadme() {
        return readme;
    }

    public void setReadme(String readme) {
        this.readme = readme;
    }

    public String getPresent() {
        return present;
    }

    public void setPresent(String present) {
        this.present = present;
    }

    public String getPresenttreat() {
        return presenttreat;
    }

    public void setPresenttreat(String presenttreat) {
        this.presenttreat = presenttreat;
    }

    public String getHistory() {
        return history;
    }

    public void setHistory(String history) {
        this.history = history;
    }

    public String getAllergy() {
        return allergy;
    }

    public void setAllergy(String allergy) {
        this.allergy = allergy;
    }

    public String getDiagnosis() {
        return diagnosis;
    }

    public void setDiagnosis(String diagnosis) {
        this.diagnosis = diagnosis;
    }

    public String getHandling() {
        return handling;
    }

    public void setHandling(String handling) {
        this.handling = handling;
    }

    public Integer getCasestate() {
        return casestate;
    }

    public void setCasestate(Integer casestate) {
        this.casestate = casestate;
    }

    @Override
    public String toString() {
        return "Medicalrecord{" +
                "id=" + id +
                ", casenumber='" + casenumber + '\'' +
                ", registid=" + registid +
                ", readme='" + readme + '\'' +
                ", present='" + present + '\'' +
                ", presenttreat='" + presenttreat + '\'' +
                ", history='" + history + '\'' +
                ", allergy='" + allergy + '\'' +
                ", diagnosis='" + diagnosis + '\'' +
                ", handling='" + handling + '\'' +
                ", casestate=" + casestate +
                '}';
    }
}

