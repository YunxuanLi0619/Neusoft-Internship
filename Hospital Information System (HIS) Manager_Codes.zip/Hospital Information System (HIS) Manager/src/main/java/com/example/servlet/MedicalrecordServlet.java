package com.example.servlet;

import com.example.dao.MedicalrecordDao;
import com.example.dao.RegisterDao;
import com.example.model.Medicalrecord;
import com.example.model.Register;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "MedicalrecordServlet", value = "/MedicalrecordServlet")
public class MedicalrecordServlet extends HttpServlet {

    MedicalrecordDao medicalrecordDao = new MedicalrecordDao();
    RegisterDao registerDao = new RegisterDao();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request, response);

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request, response);

    }

    protected void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String methodname = request.getParameter("method");
        if ("addmethod".equals(methodname)) {
            addMedicalrecord(request, response);

        } else if ("updatemethod".equals(methodname)) {
            updateMedicalrecord(request, response);

        } else if ("deletemethod".equals(methodname)) {
            deleteMedicalrecordById(request, response);

        } else if ("findid".equals(methodname)) {
            findMedicalrecordById(request, response);
        }else if ("addinput".equals(methodname)) {
            addinput(request,response);

        } else {
            findAll(request, response);
        }
    }

    protected void addMedicalrecord(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String casenumber = request.getParameter("casenumber");
        int registid = Integer.parseInt(request.getParameter("registid"));
        String readme = request.getParameter("readme");
        String present = request.getParameter("present");
        String presenttreat = request.getParameter("presenttreat");
        String history = request.getParameter("history");
        String allergy = request.getParameter("allergy");
        String diagnosis = request.getParameter("diagnosis");
        String handling = request.getParameter("handling");
        int casestate = Integer.parseInt(request.getParameter("casestate"));

        Medicalrecord medicalrecord = new Medicalrecord();
        medicalrecord.setCasenumber(casenumber);
        medicalrecord.setRegistid(registid);
        medicalrecord.setReadme(readme);
        medicalrecord.setPresent(present);
        medicalrecord.setPresenttreat(presenttreat);
        medicalrecord.setHistory(history);
        medicalrecord.setAllergy(allergy);
        medicalrecord.setDiagnosis(diagnosis);
        medicalrecord.setHandling(handling);
        medicalrecord.setCasestate(casestate);

        medicalrecordDao.addMedicalrecord(medicalrecord);

        findAll(request,response);


    }

    protected void updateMedicalrecord(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        int id = Integer.parseInt(request.getParameter("id"));
        String casenumber = request.getParameter("casenumber");
        int registid = Integer.parseInt(request.getParameter("registid"));
        String readme = request.getParameter("readme");
        String present = request.getParameter("present");
        String presenttreat = request.getParameter("presenttreat");
        String history = request.getParameter("history");
        String allergy = request.getParameter("allergy");
        String diagnosis = request.getParameter("diagnosis");
        String handling = request.getParameter("handling");
        int casestate = Integer.parseInt(request.getParameter("casestate"));

        Medicalrecord medicalrecord = new Medicalrecord();
        medicalrecord.setId(id);
        medicalrecord.setCasenumber(casenumber);
        medicalrecord.setRegistid(registid);
        medicalrecord.setReadme(readme);
        medicalrecord.setPresent(present);
        medicalrecord.setPresenttreat(presenttreat);
        medicalrecord.setHistory(history);
        medicalrecord.setAllergy(allergy);
        medicalrecord.setDiagnosis(diagnosis);
        medicalrecord.setHandling(handling);
        medicalrecord.setCasestate(casestate);

        medicalrecordDao.updateMedicalrecord(medicalrecord);



        findAll(request, response);


    }

    protected void deleteMedicalrecordById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int medicalrecordid = Integer.parseInt(request.getParameter("mid"));
        medicalrecordDao.deleteMedicalrecord(medicalrecordid);
        findAll(request, response);


    }

    protected void findAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Medicalrecord> medicalrecords = medicalrecordDao.findAll();
        request.setAttribute("medicalrecordObjs", medicalrecords);

        request.getRequestDispatcher("/system/displaymedicalrecord.jsp").forward(request, response);
    }

    protected void findMedicalrecordById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        int medicalrecordid = Integer.parseInt(request.getParameter("medicalrecordid"));
        Medicalrecord medicalrecord = medicalrecordDao.findMedicalrecordById(medicalrecordid);
        request.setAttribute("medicalrecordObj", medicalrecord);
        List<Register> registers = registerDao.findAll();
        request.setAttribute("registerObjs",registers);
        request.getRequestDispatcher("/system/updatemedicalrecord.jsp").forward(request, response);
    }

    protected void addinput(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Register> registers = registerDao.findAll();
        request.setAttribute("registerObjs",registers);
        request.getRequestDispatcher("/system/addmedicalrecord.jsp").forward(request,response);
    }



}
