package com.example.model;

public class SettleCategory {
    private Integer id;
    private String settlecode;
    private String settlename;
    private Integer sequenceno;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSettlecode() {
        return settlecode;
    }

    public void setSettlecode(String settlecode) {
        this.settlecode = settlecode;
    }

    public String getSettlename() {
        return settlename;
    }

    public void setSettlename(String settlename) {
        this.settlename = settlename;
    }

    public Integer getSequenceno() {
        return sequenceno;
    }

    public void setSequenceno(Integer sequenceno) {
        this.sequenceno = sequenceno;
    }


    @Override
    public String toString() {
        return "SettleCategory{" +
                "id=" + id +
                ", settlecode='" + settlecode + '\'' +
                ", settlename='" + settlename + '\'' +
                ", sequenceno=" + sequenceno +
                '}';
    }
}
