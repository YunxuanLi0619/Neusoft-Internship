package com.software.dao;
import com.example.dao.expenseclassDao;
import com.example.model.expenseclass;
import org.junit.jupiter.api.Test;

import java.util.List;

/**
 * 单元测试：科室数据库访问层连接数据库实现添加、修改、删除、查询的操作
 */
public class expenseclassDaoTest {
    //创建数据库访问层对象
    expenseclassDao ExpenseclassDao = new expenseclassDao();

    /**
     * 单元测试--科室添加操作
     */
    @Test
    public void addMethod1(){
        //1.创建添加的科室测试用例
        expenseclass Expenseclass = new expenseclass();
        Expenseclass.setExpcode("E10011");
        Expenseclass.setExpname("打印费");





        //2.调用数据库访问层的方法实现添加操作
        boolean flag = ExpenseclassDao.addexpenseclass(Expenseclass);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    /**
     * 单元测试--科室信息的修改操作
     */
    @Test
    public void updatefmeditem(){
        //1.创建修改科室测试用例
        expenseclass Expenseclass = new expenseclass();
        Expenseclass.setId(1);
        Expenseclass.setExpcode("E10001");
        Expenseclass.setExpname("床位费");



        //2.调用数据库访问层的方法实现添加操作
        boolean flag = ExpenseclassDao.updateexpenseclass(Expenseclass);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    /**
     * 单元测试--删除操作
     */
    @Test
    public void deleteMethod(){
        boolean flag = ExpenseclassDao.deleteexpenseclass(6);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    @Test
    public void queryexpenseclass(){
        List<expenseclass> ExpenseclassList =  ExpenseclassDao.findAll();
        for(expenseclass Expenseclass : ExpenseclassList){
            System.out.println(Expenseclass);
        }
    }

    @Test
    public void queryexpenseclassByid(){
        expenseclass Expenseclass = ExpenseclassDao.findExpenseclassByid(1);
        System.out.println(Expenseclass);
    }
}
