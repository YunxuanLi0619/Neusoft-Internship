package com.example.servlet;

import com.example.dao.DrugsDao;
import com.example.dao.ConstantItemDao;
import com.example.model.ConstantItem;
import com.example.model.Drugs;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "tbl_drugsServlet", value = "/tbl_drugsServlet")
public class tbl_drugsServlet extends HttpServlet {

    //2.创建数据库访问层对象

    DrugsDao drugsDao = new DrugsDao();
    ConstantItemDao constantitemdao = new ConstantItemDao();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request, response);
    }

    //前端控制器-- 执行药品的添加，修改，删除，查询操作
    //添加：addmethod,修改：updatemethod,删除：deletemethod,根据主键查询科室信息：findid,默认执行：查询全部信息
    protected void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String methodname = request.getParameter("method");
        if ("addmethod".equals(methodname)) {
            //添加操作
            addDrugs(request, response);
        } else if ("updatemethod".equals(methodname)) {
            //修改操作
            updateDrugs(request, response);
        } else if ("deletemethod".equals(methodname)) {
            deleteDrugsByID(request, response);
            //删除操作
        } else if ("findid".equals(methodname)) {
            //根据主键查询数据表信息
            findDrugsByID(request, response);
        } else if ("cancelmethod".equals(methodname)) {
            cancelmethod(request, response);
        }else if("addinput".equals(methodname)) {
            addinput(request,response);
        } else {
            //执行查询所有记录
            findAll(request, response);
        }
    }

    //前端控制器--添加药品操作
    protected void addDrugs(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取客户端输入的药品信息(drugscode ,drugsname  , drugsformat ,drugsunit ,manfacturer ,drugsdosageid ,drugstypeid ,drugsprice ,mnemoniccode ,creationdate ,lastupdatedate ,delmark)

        String drugscode = request.getParameter("drugscode");
        String drugsname = request.getParameter("drugsname");
        String drugsformat = request.getParameter("drugsformat");
        String drugsunit = request.getParameter("drugsunit");
        String manfacturer = request.getParameter("manfacturer");
        int drugsdosageid = Integer.parseInt(request.getParameter("drugsdosageid"));
        int drugstypeid = Integer.parseInt(request.getParameter("drugstypeid"));
        double drugsprice = Double.parseDouble(request.getParameter("drugsprice"));
        String mnemoniccode = request.getParameter("mnemoniccode");
        String creationdate = request.getParameter("creationdate");
        String lastupdatedate = request.getParameter("lastupdatedate");
        int delmark = Integer.parseInt(request.getParameter("delmark"));


        //创建Drugs对象
        Drugs drugs = new Drugs();
        drugs.setDrugscode(drugscode);
        drugs.setDrugsname(drugsname);
        drugs.setDrugsformat(drugsformat);
        drugs.setDrugsunit(drugsunit);
        drugs.setManufacturer(manfacturer);
        drugs.setDrugsdosageid(drugsdosageid);
        drugs.setDrugstypeid(drugstypeid);
        drugs.setDrugsprice(drugsprice);
        drugs.setMnemoniccode(mnemoniccode);
        drugs.setCreationdate(creationdate);
        drugs.setLastupdatedate(lastupdatedate);
        drugs.setDelmark(delmark);


        //3.调用数据库访问层中的添加方法
        drugsDao.addDrugs(drugs);

        //4.跳转到成功提示页面
        findAll(request, response);

    }

    protected void updateDrugs(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取客户端输入的药品信息(drugscode ,drugsname  , drugsformat ,drugsunit ,manfacturer ,drugsdosageid ,drugstypeid ,drugsprice ,mnemoniccode ,creationdate ,lastupdatedate ,delmark)

        int id = Integer.parseInt(request.getParameter("id"));
        String drugscode = request.getParameter("drugscode");
        String drugsname = request.getParameter("drugsname");
        String drugsformat = request.getParameter("drugsformat");
        String drugsunit = request.getParameter("drugsunit");
        String manufacturer = request.getParameter("manufacturer");
        int drugsdosageid = Integer.parseInt(request.getParameter("drugsdosageid"));
        int drugstypeid = Integer.parseInt(request.getParameter("drugstypeid"));
        double drugsprice = Double.parseDouble(request.getParameter("drugsprice"));
        String mnemoniccode = request.getParameter("mnemoniccode");
        String creationdate = request.getParameter("creationdate");
        String lastupdatedate = request.getParameter("lastupdatedate");
        int delmark = Integer.parseInt(request.getParameter("delmark"));


        //创建Drugs对象
        Drugs drugs = new Drugs();
        drugs.setId(id);
        drugs.setDrugscode(drugscode);
        drugs.setDrugsname(drugsname);
        drugs.setDrugsformat(drugsformat);
        drugs.setDrugsunit(drugsunit);
        drugs.setManufacturer(manufacturer);
        drugs.setDrugsdosageid(drugsdosageid);
        drugs.setDrugstypeid(drugstypeid);
        drugs.setDrugsprice(drugsprice);
        drugs.setMnemoniccode(mnemoniccode);
        drugs.setCreationdate(creationdate);
        drugs.setLastupdatedate(lastupdatedate);
        drugs.setDelmark(delmark);

        //3.调用数据库访问层中的添加方法
        drugsDao.updateDrugs(drugs);

        //4.跳转到成功提示页面
        findAll(request, response);

    }


    protected void findAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.调用数据库访问层中的查询方法
        List<Drugs> drugs = drugsDao.findAll();
        //2.跳转到页面上
        request.setAttribute("drugsObjs", drugs);
        request.getRequestDispatcher("/system/displaydrugs.jsp").forward(request, response);
    }

    protected void findDrugsByID(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        int druid = Integer.parseInt(request.getParameter("druid"));



        Drugs drugs = drugsDao.findDrugsnByID(druid);

        request.setAttribute("drugObjs", drugs);
        List<ConstantItem> constantitems = constantitemdao.findAll();
        //2.跳转到页面上
        request.setAttribute("constantitemObjs", constantitems);
        request.getRequestDispatcher("/system/updatedrugs.jsp").forward(request, response);
    }

    protected void deleteDrugsByID(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        int druid = Integer.parseInt(request.getParameter("did"));

        drugsDao.deleteDrugs(druid);

        findAll(request, response);

    }

    protected void cancelmethod(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        int druid = Integer.parseInt(request.getParameter("did"));

        drugsDao.cancelDrugs(druid);

        findAll(request, response);
    }
    protected void addinput(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.调用数据库访问层中的查询方法
        List<ConstantItem> constantitems = constantitemdao.findAll();
        //2.跳转到页面上
        request.setAttribute("constantitemObjs", constantitems);
        request.getRequestDispatcher("/system/adddrugs.jsp").forward(request, response);
    }
}
