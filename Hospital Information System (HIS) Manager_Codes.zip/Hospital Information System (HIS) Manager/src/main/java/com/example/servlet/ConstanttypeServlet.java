package com.example.servlet;

import com.example.dao.ConstanttypeDao;
import com.example.model.Constanttype;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "ConstanttypeServlet", value = "/ConstanttypeServlet")
public class ConstanttypeServlet extends HttpServlet {

    //2.创建数据库访问层对象
    ConstanttypeDao constanttypeDao = new ConstanttypeDao();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request,response);
    }

    /**
     * 前端控制器-- 执行科室的添加、修改、删除、查询操作
     *            添加方法的参数名：addmethod
     *            修改：    updatemethod
     *            删除：    deletemethod
     *            根据主键查询科室信息: findid
     *            默认执行：查询全部信息
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String methodname =  request.getParameter("method");
        if("addmethod".equals(methodname)){
            //添加操作
            addConstanttype(request,response);
        }else if("updatemethod".equals(methodname)){
            //修改操作
            updateConstanttype(request,response);
        }else if("deletemethod".equals(methodname)){
            deleteConstanttypeById(request,response);
            //删除操作
        }else if("findid".equals(methodname)){
            //根据主键查询数据表信息
            findConstanttypeByID(request,response);
            /** }else if("cancelmethod".equals(methodname)){
            cancelmethod(request, response);
             */}else{
            //执行查询所有记录
            findAll(request,response);
        }
    }

    /**
     * 功能：前端控制器--添加科室操作
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void addConstanttype(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        //1.获取客户端输入的科室信息 (deptcode ,deptname  , deptcategoryid ,depttype)
        String constanttypeCode = request.getParameter("constanttypecode");
        String constanttypeName = request.getParameter("constanttypename");

        //double departmentType = Double.parseDouble(request.getParameter("depttype"));

        //创建Department对象
        Constanttype constanttype = new Constanttype();

        constanttype.setConstanttypecode(constanttypeCode);
        constanttype.setConstanttypename(constanttypeName);

        //3.调用数据库访问层中的添加方法
        constanttypeDao.addConstanttype(constanttype);


        //4.跳转到成功提示页面
        findAll(request,response);


    }
    protected void updateConstanttype(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取客户端输入的科室信息 (deptcode ,deptname  , deptcategoryid ,depttype)
        int id = Integer.parseInt(request.getParameter("id"));
        String constanttypeCode = request.getParameter("constanttypecode");
        String constanttypeName = request.getParameter("constanttypename");

        //double departmentType = Double.parseDouble(request.getParameter("depttype"));

        //创建Deparmtn对象
        Constanttype constanttype = new Constanttype();
        constanttype.setId(id);
        constanttype.setConstanttypecode(constanttypeCode);
        constanttype.setConstanttypename(constanttypeName);


        //3.调用数据库访问层中的修改方法
        constanttypeDao.updateConstanttype(constanttype);

        //4.跳转到显示页面
        findAll(request,response);

    }
    /**
     * 功能：查询科室信息
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void findAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.调用数据库访问层中的查询方法
        List<Constanttype> constanttypes = constanttypeDao.findAll();
        //2.跳转到显示页面中
        request.setAttribute("constanttypeObjs",constanttypes);
        request.getRequestDispatcher("/system/displayconstanttype.jsp").forward(request,response);
    }
    /**
     * 功能：根据科室编号查询科室信息
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void findConstanttypeByID(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取科室编号
        int contid = Integer.parseInt(request.getParameter("contid"));
        //2.调用数据库访问层中的根据科室编号查询科室信息的方法
        Constanttype constanttype= constanttypeDao.findConstanttypeByID(contid);

        //3.跳转到修改显示页面
        request.setAttribute("contobj",constanttype);
        request.getRequestDispatcher("/system/updateconstanttype.jsp").forward(request,response);
    }
    /**
     * 功能：根据科室编号查询科室信息
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void deleteConstanttypeById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取科室编号
        int contid = Integer.parseInt(request.getParameter("did"));
        //2.调用数据库访问层中的根据科室编号删除科室信息的方法
        constanttypeDao.deleteConstanttype(contid);
        //3.跳转到修改显示页面
        findAll(request,response);
    }

    /**
     * 功能：逻辑删除
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException

    protected void cancelmethod(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取科室编号
        int contid = Integer.parseInt(request.getParameter("did"));
        //2.调用数据库访问层中的根据科室编号删除科室信息的方法
        constanttypeDao.cancelConstanttype(contid);
        //3.跳转到修改显示页面
        findAll(request,response);
    }*/

}
