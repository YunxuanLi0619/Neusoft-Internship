package com.example.model;

/**
 * 实体类--科室
 */
public class Constanttype {
    //id, deptcode,deptname,  depttype
    private Integer id;
    private String constanttypecode;
    private String constanttypename;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getConstanttypecode() {
        return constanttypecode;
    }

    public void setConstanttypecode(String constanttypecode) {
        this.constanttypecode = constanttypecode;
    }

    public String getConstanttypename() {
        return constanttypename;
    }

    public void setConstanttypename(String constanttypename) {
        this.constanttypename = constanttypename;
    }

    @Override
    public String toString() {
        return "Constanttype{" +
                "id=" + id +
                ", constanttypecode='" + constanttypecode + '\'' +
                ", constanttypename='" + constanttypename + '\'' +
                '}';
    }
}
