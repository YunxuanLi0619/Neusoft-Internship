package com.software.dao;

import com.example.dao.ConstanttypeDao;
import com.example.model.Constanttype;
import org.junit.jupiter.api.Test;

import java.util.List;

/**
 * 单元测试：科室数据库访问层连接数据库实现添加、修改、删除、查询的操作
 */
public class ConstanttypeDaoTest {

    //创建数据库访问层对象
    ConstanttypeDao constanttypeDao = new ConstanttypeDao();

    /**
     * 单元测试--科室添加操作
     */
    @Test
    public void addMethod1(){
        //1.创建添加的科室测试用例
        Constanttype constanttype = new Constanttype();
        constanttype.setConstanttypecode("SJ1002");
        constanttype.setConstanttypename("神经科2");


        //2.调用数据库访问层的方法实现添加操作
        boolean flag = constanttypeDao.addConstanttype(constanttype);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    /**
     * 单元测试--科室信息的修改操作
     */
    @Test
    public void updateConstanttype(){
        //1.创建修改科室测试用例
        Constanttype constanttype = new Constanttype();
        constanttype.setId(9);
        constanttype.setConstanttypecode("FS1002");
        constanttype.setConstanttypename("放射科2");


        //2.调用数据库访问层的方法实现添加操作
        boolean flag = constanttypeDao.updateConstanttype(constanttype);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    /**
     * 单元测试--删除操作
     */
    @Test
    public void deleteMethod(){
        boolean flag = constanttypeDao.deleteConstanttype(10);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    @Test
    public void queryConstanttype(){
       List<Constanttype> constanttypeList =  constanttypeDao.findAll();
       for(Constanttype constanttype : constanttypeList){
           System.out.println(constanttype);
       }
    }


}
