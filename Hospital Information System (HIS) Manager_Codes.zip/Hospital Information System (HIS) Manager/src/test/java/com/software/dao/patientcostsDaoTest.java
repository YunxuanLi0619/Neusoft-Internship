package com.software.dao;
import com.example.dao.patientcostsDao;
import com.example.model.patientcosts;
import org.junit.jupiter.api.Test;

import java.util.List;

/**
 * 单元测试：科室数据库访问层连接数据库实现添加、修改、删除、查询的操作
 */
public class patientcostsDaoTest {
    //创建数据库访问层对象
    patientcostsDao PatientcostsDao = new patientcostsDao();

    /**
     * 单元测试--科室添加操作
     */
    @Test
    public void addMethod1(){
        //1.创建添加的科室测试用例
        patientcosts Patientcosts = new patientcosts();
        Patientcosts.setRegistid(11);
        Patientcosts.setInvoiceid(11);
        Patientcosts.setItemid(11);
        Patientcosts.setItemtype(1);
        Patientcosts.setName("CF");
        Patientcosts.setPrice(114.0);
        Patientcosts.setAmount(1.0);
        Patientcosts.setDeptid(2);
        Patientcosts.setCreatetime("2022.05.03");
        Patientcosts.setCreateoperid(8);
        Patientcosts.setPaytime("2022.11.14 05:14");
        Patientcosts.setRegisterid(8);
        Patientcosts.setFeetype(1);
        Patientcosts.setBackid(11);
        Patientcosts.setState(0);




        //2.调用数据库访问层的方法实现添加操作
        boolean flag = PatientcostsDao.addpatientcosts(Patientcosts);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    /**
     * 单元测试--科室信息的修改操作
     */
    @Test
    public void updatepatientcosts(){
        //1.创建修改科室测试用例
        patientcosts Patientcosts = new patientcosts();
        Patientcosts.setId(1);
        Patientcosts.setState(2);


        //2.调用数据库访问层的方法实现添加操作
        boolean flag = PatientcostsDao.updatepatientcosts(Patientcosts);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    @Test
    public void querypatientcosts(){
        List<patientcosts> PatientcostsList =  PatientcostsDao.findAll();
        for(patientcosts Patientcosts : PatientcostsList){
            System.out.println(Patientcosts);
        }
    }

}

