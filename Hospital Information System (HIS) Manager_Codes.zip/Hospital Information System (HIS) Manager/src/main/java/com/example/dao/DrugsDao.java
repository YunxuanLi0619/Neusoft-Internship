package com.example.dao;

import com.example.model.Drugs;
import com.example.util.DBCPUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DrugsDao {

    public boolean addDrugs(Drugs drugs) {
        boolean flag = false;
        String sql = "insert into tbl_drugs(drugscode,drugsname,drugsformat ,drugsunit, manufacturer,drugsdosageid,drugstypeid,drugsprice,mnemoniccode,creationdate,lastupdatedate,delmark) values(?,?,?,?,?,?,?,?,?,?,?,?)";
        return DBCPUtil.execUpdate(sql,drugs.getDrugscode(), drugs.getDrugsname(),
                drugs.getDrugsformat(), drugs.getDrugsunit(),drugs.getManufacturer(),drugs.getDrugsdosageid(),drugs.getDrugstypeid(),drugs.getDrugsprice(),drugs.getMnemoniccode(),drugs.getCreationdate(),drugs.getLastupdatedate(),drugs.getDelmark());
    }

    public boolean updateDrugs(Drugs drugs) {
        boolean flag = false;
        String sql = "update tbl_drugs set drugscode=?,drugsname=?,drugsformat=? ,drugsunit=?,manufacturer=?,drugsdosageid=?,drugstypeid=?,drugsprice=?,mnemoniccode=?,creationdate=?,lastupdatedate=?,delmark=? where id=?";
        flag = DBCPUtil.execUpdate(sql, drugs.getDrugscode(), drugs.getDrugsname(), drugs.getDrugsformat(), drugs.getDrugsunit(),drugs.getManufacturer(),drugs.getDrugsdosageid(),drugs.getDrugstypeid(),drugs.getDrugsprice(),drugs.getMnemoniccode(),drugs.getCreationdate(),drugs.getLastupdatedate(),drugs.getDelmark(),drugs.getId());
        return flag;
    }

    public boolean deleteDrugs(int id) {
        boolean flag = false;
        String sql = "update tbl_drugs set delmark=0 where id =?";
        flag = DBCPUtil.execUpdate(sql,id);
        return flag;
    }

    public boolean cancelDrugs(int id){
        String sql = "update tbl_drugs set delmark=0 ,deltime = now() where id=?";
        return DBCPUtil.execUpdate(sql,id);
    }

    public List<Drugs> findAll() {
        List<Drugs> drugss = new ArrayList();
        Connection connection = DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = "select id,drugscode,drugsname,drugsformat,drugsunit,manufacturer,drugsdosageid,drugstypeid,drugsprice,mnemoniccode,creationdate,lastupdatedate,delmark from tbl_drugs where delmark=1";

        try {
            pstmt = connection.prepareStatement(sql);
            rs = pstmt.executeQuery();
            Drugs drugs = null;

            while(rs.next()) {
                drugs = new Drugs();
                int id = rs.getInt("id");
                String drugscode = rs.getString("drugscode");
                String drugsname = rs.getString("drugsname");
                String drugsformat = rs.getString("drugsformat");
                String drugsunit = rs.getString("drugsunit");
                String manufacturer = rs.getString("manufacturer");
                int drugsdosageid = rs.getInt("drugsdosageid");
                int  drugstypeid = rs.getInt("drugstypeid");
                double drugsprice = rs.getDouble("drugsprice");
                String mnemoniccode = rs.getString("mnemoniccode");
                String creationdate = rs.getString("creationdate");
                String lastupdatedate = rs.getString("lastupdatedate");
                int delmark = rs.getInt("delmark");

                drugs.setId(id);
                drugs.setDrugscode(drugscode);
                drugs.setDrugsname(drugsname);
                drugs.setDrugsformat(drugsformat);
                drugs.setDrugsunit(drugsunit);
                drugs.setManufacturer(manufacturer);
                drugs.setDrugsdosageid(drugsdosageid);
                drugs.setDrugstypeid(drugstypeid);
                drugs.setDrugsprice(drugsprice);
                drugs.setMnemoniccode(mnemoniccode);
                drugs.setCreationdate(creationdate);
                drugs.setLastupdatedate(lastupdatedate);
                drugs.setDelmark(delmark);
                drugss.add(drugs);

            }
        } catch (SQLException var15) {
            var15.printStackTrace();
        } finally {
            DBCPUtil.release(connection, pstmt, rs);
        }

        return drugss;
    }

    public Drugs findDrugsnByID(int druid) {
        Drugs drugs = new Drugs();
        Connection connection = DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = "select id,drugscode,drugsname,drugsformat,drugsunit,manufacturer,drugsdosageid,drugstypeid,drugsprice,mnemoniccode,creationdate,lastupdatedate,delmark from tbl_drugs where id=? ";

        try {
            pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1,druid);
            rs = pstmt.executeQuery();


            if (rs.next()) {

                int id = rs.getInt("id");
                String drugscode = rs.getString("drugscode");
                String drugsname = rs.getString("drugsname");
                String drugsformat = rs.getString("drugsformat");
                String drugsunit = rs.getString("drugsunit");
                String manufacturer = rs.getString("manufacturer");
                int drugsdosageid = rs.getInt("drugsdosageid");
                int  drugstypeid = rs.getInt("drugstypeid");
                double drugsprice = rs.getDouble("drugsprice");
                String mnemoniccode = rs.getString("mnemoniccode");
                String creationdate = rs.getString("creationdate");
                String lastupdatedate = rs.getString("lastupdatedate");
                int delmark = rs.getInt("delmark");


                drugs.setId(id);
                drugs.setDrugscode(drugscode);
                drugs.setDrugsname(drugsname);
                drugs.setDrugsformat(drugsformat);
                drugs.setDrugsunit(drugsunit);
                drugs.setManufacturer(manufacturer);
                drugs.setDrugsdosageid(drugsdosageid);
                drugs.setDrugstypeid(drugstypeid);
                drugs.setDrugsprice(drugsprice);
                drugs.setMnemoniccode(mnemoniccode);
                drugs.setCreationdate(creationdate);
                drugs.setLastupdatedate(lastupdatedate);
                drugs.setDelmark(delmark);


            }
        } catch (SQLException var15) {
            var15.printStackTrace();
        } finally {
            DBCPUtil.release(connection, pstmt, rs);
        }

        return drugs;
    }
}
