package com.example.servlet;

import com.example.dao.DiseCategoryDao;
import com.example.dao.DiseaseDao;
import com.example.model.DiseCategory;
import com.example.model.Disease;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "DiseaseServlet", value = "/DiseaseServlet")

public class DiseaseServlet extends HttpServlet {
    //创建数据库访问层对象
    DiseaseDao diseaseDao = new DiseaseDao();

    DiseCategoryDao disecategoryDao = new DiseCategoryDao();

@Override
        protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            execute(request,response);
        }
@Override
        protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            execute(request,response);
        }

    /**
     * 前端控制器——执行疾病表的添加，修改，删除，查询操作
     *            添加操作的方法名：adddisease
     *            修改：updatedisease
     *            删除：deletedisease
     *            根据主键查询信息：findid
     *            默认执行：查询全部信息
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
        protected void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
          String methodname = request.getParameter("method");
          if ("addmethod".equals(methodname)){
              addDisease(request, response);
          }else if("updatemethod".equals(methodname)){
              updatedisease(request,response);
          }else if("deletemethod".equals(methodname)){
              deleteDiseaseById(request,response);
          }else if("findid".equals(methodname)){
              findDiseaseById(request,response);

          }else  if("addinput".equals(methodname)){

            addinput(request,response);

          }else{
                  findAll(request, response);
              }
          }


    /**
     * 功能 —— 添加疾病表信息
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void addDisease(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int diseaseCategory = Integer.parseInt( request.getParameter("diseasecategory"));
        String diseaseCode = request.getParameter("diseasecode");
        String diseaseName = request.getParameter("diseasename");
        String diseaseIcd = request.getParameter("diseaseicd");


        //创建Register对象
        Disease disease = new Disease();
        disease.setDiseasecode(diseaseCode);
        disease.setDiseasename(diseaseName);
        disease.setDiseaseicd(diseaseIcd);
        disease.setDiseasecategory(diseaseCategory);

        //调用数据库的添加方法
        diseaseDao.addDisease(disease);

        //跳转到成功页面
        findAll(request,response);
    }
    protected void updatedisease(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取客户端输入的科室信息 (deptcode ,deptname  , deptcategoryid ,depttype)
        int id = Integer.parseInt(request.getParameter("id"));
        int diseasecategory = Integer.parseInt( request.getParameter("diseasecategory"));
        String diseasecode = request.getParameter("diseasecode");
        String diseasename = request.getParameter("diseasename");
        String diseaseicd = request.getParameter("diseaseicd");

        //创建Deparmtn对象
        Disease disease = new Disease();
        disease.setId(id);
        disease.setDiseasecode(diseasecode);
        disease.setDiseasename(diseasename);
        disease.setDiseaseicd(diseaseicd);
        disease.setDiseasecategory(diseasecategory);


        //3.调用数据库访问层中的修改方法
        diseaseDao.updateDisease(disease);

        //4.跳转到显示页面
        findAll(request,response);

    }

    /**
     *默认——自动查询所有信息
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void findAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        List<Disease> diseases = diseaseDao.findAll();
        request.setAttribute("diseaseObjs",diseases);
        request.getRequestDispatcher("/system/displaydisease.jsp").forward(request, response);
    }
    /**
     * 功能：根据科室编号查询科室信息
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void findDiseaseById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取科室编号
        int diseid = Integer.parseInt(request.getParameter("diseid"));
        //2.调用数据库访问层中的根据科室编号查询科室信息的方法
        Disease disease= diseaseDao.findDiseaseByID(diseid);

        //3.跳转到修改显示页面
        request.setAttribute("diseobj",disease);
        List<DiseCategory> disecategorys = disecategoryDao.findAll();

        request.setAttribute("disecategoryObjs",disecategorys);
        request.getRequestDispatcher("/system/updatedisease.jsp").forward(request,response);
    }

    /**
     * 功能：根据科室编号查询科室信息
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void deleteDiseaseById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取科室编号
        int diseid = Integer.parseInt(request.getParameter("did"));
        //2.调用数据库访问层中的根据科室编号删除科室信息的方法
        diseaseDao.deleteDisease(diseid);
        //3.跳转到修改显示页面
        findAll(request,response);
    }




    protected void addinput(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        List<DiseCategory> disecategorys = disecategoryDao.findAll();

        request.setAttribute("disecategoryObjs",disecategorys);
        request.getRequestDispatcher("/system/adddisease.jsp").forward(request,response);


    }






}


