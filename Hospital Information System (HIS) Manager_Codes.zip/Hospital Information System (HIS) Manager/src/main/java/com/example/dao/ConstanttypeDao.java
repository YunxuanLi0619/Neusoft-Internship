package com.example.dao;

import com.example.model.Constanttype;
import com.example.util.DBCPUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * 数据库访问层--科室信息的增删改查操作
 */
public class ConstanttypeDao {

    /**
     * 添加科室操作
     * @param constanttype
     * @return
     */
    public boolean addConstanttype(Constanttype constanttype){
        boolean flag = false;
        String sql ="insert into tbl_constanttype(constanttypecode,constanttypename) " +
                "values(?,?)";
        return DBCPUtil.execUpdate(sql,constanttype.getConstanttypecode(),constanttype.getConstanttypename());
    }

    /**
     * 功能：根据科室编号修改科室信息
     * @param constanttype
     * @return
     */
    public boolean updateConstanttype(Constanttype constanttype){
        boolean flag = false;
        String sql ="update tbl_constanttype set constanttypecode=?,constanttypename=? where id=?";
        flag = DBCPUtil.execUpdate(sql,constanttype.getConstanttypecode(),constanttype.getConstanttypename(),
                constanttype.getId());
        return flag;
    }

    /**
     * 功能：根据科室编号删除科室信息
     * @param id
     * @return
     */
    public boolean deleteConstanttype(int id){
        boolean flag = false;
        String sql ="delete from tbl_constanttype where id =?";
        flag = DBCPUtil.execUpdate(sql,id);
        return flag;
    }

    /**
     * 功能：作废操作
     * @param id
     * @return

    public boolean cancelConstanttype(int id){

        String sql = "update tbl_constanttype set delmark=0 ,timea=now() where id=?";
        return DBCPUtil.execUpdate(sql,id);

    }
     */
    /**
     * 功能：查询科室的所有信息
     * @return
     */
    public List<Constanttype> findAll(){
        List<Constanttype> constanttypes = new ArrayList<>();
        //1.获取数据库连接对象
        Connection connection =  DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql ="select id,constanttypecode,constanttypename from tbl_constanttype ";
        try {
            pstmt = connection.prepareStatement(sql);
            rs = pstmt.executeQuery();
            Constanttype constanttype = null;
            while(rs.next()){
                constanttype = new Constanttype();
                int id= rs.getInt("id");
                String constanttypecode = rs.getString("constanttypecode");
                String constanttypename = rs.getString("constanttypename");


                //每行记录封装为一个对象
                constanttype.setId(id);
                constanttype.setConstanttypecode(constanttypecode);
                constanttype.setConstanttypename(constanttypename);


                //将对象添加到List集合中
                constanttypes.add(constanttype);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return constanttypes;
    }
    /**
     * 功能：根据主键查询科室信息
     * @param contid
     * @return
     */
    public Constanttype findConstanttypeByID(int contid){
        Constanttype constanttype = new Constanttype();
        //1.获取数据库连接对象
        Connection connection =  DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql ="select id,constanttypecode,constanttypename from tbl_constanttype where id=?";
        try {
            pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1,contid);

            rs = pstmt.executeQuery();

            if(rs.next()){
                int id= rs.getInt("id");
                String constanttypecode = rs.getString("constanttypecode");
                String constanttypename = rs.getString("constanttypename");


                //每行记录封装为一个对象
                constanttype.setId(id);
                constanttype.setConstanttypecode(constanttypecode);
                constanttype.setConstanttypename(constanttypename);


            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return constanttype;
    }
}
