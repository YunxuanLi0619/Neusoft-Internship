package com.example.servlet;

import com.example.dao.*;
import com.example.model.*;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "patientcostsServlet", value = "/patientcostsServlet")
public class patientcostsServlet extends HttpServlet {
    //2.创建数据库访问层对象
    patientcostsDao PatientcostsDao = new patientcostsDao();
    RegisterDao registerDao = new RegisterDao();
    MedicalrecordDao medicalrecordDao = new MedicalrecordDao();
    DepartmentDao departmentdao = new DepartmentDao();
    UserDao userdao = new UserDao();
    SettleCategoryDao settlecategoryDao = new SettleCategoryDao();


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        execute(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        execute(request, response);
    }

    /**
     * 前端控制器
     * 添加方法的参数名：addmethod
     * 修改：    updatemethod
     * 删除：    deletemethod
     * 根据主键查询科室信息: findid
     * 默认执行：查询全部信息
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String methodname = request.getParameter("method");
        if ("addmethod".equals(methodname)) {
            //添加操作
            addpatientcost(request, response);
        } else if ("updatemethod".equals(methodname)) {
            //修改操作
            updatepatientcost(request,response);
      } else if ("deletemethod".equals(methodname)) {
            //删除操作
        deletepatientcostsById(request,response);
        } else if ("findid".equals(methodname)) {
            //根据主键查询数据表信息
            findpatientscostsById(request,response);
        } else if("addinput".equals(methodname)){

            addinput(request,response);


        }else{
            findAll(request,response);//执行查询所有记录
        }
    }



    /**
     * 前端控制器-添加项目
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void addpatientcost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {



        //1.获取客户端输入
        int neoregistid = Integer.parseInt(request.getParameter("registid"));
        int neoinvoiceid = Integer.parseInt(request.getParameter("invoiceid"));
        int neoitemid = Integer.parseInt(request.getParameter("itemid"));
        int neoitemtype = Integer.parseInt(request.getParameter("itemtype"));
        String neoname = request.getParameter("name");
        double neoprice = Double.parseDouble(request.getParameter("price"));
        double neoamount = Double.parseDouble(request.getParameter("amount"));
        int neodeptid = Integer.parseInt(request.getParameter("deptid"));
        String neocreatetime = request.getParameter("createtime");
        int neocreateoperid = Integer.parseInt(request.getParameter("createoperid"));
        String neopaytime = request.getParameter("paytime");
        int neoregisterid = Integer.parseInt(request.getParameter("registerid"));
        int neofeetype = Integer.parseInt(request.getParameter("feetype"));
        int neobackid = Integer.parseInt(request.getParameter("backid"));
        String neotype = request.getParameter("type");
        int neostate = Integer.parseInt(request.getParameter("state"));

        //创建对象
        patientcosts Patientcosts = new patientcosts();
        Patientcosts.setRegistid(neoregistid);
        Patientcosts.setInvoiceid(neoinvoiceid);
        Patientcosts.setItemid(neoitemid);
        Patientcosts.setItemtype(neoitemtype);
        Patientcosts.setName(neoname);
        Patientcosts.setPrice(neoprice);
        Patientcosts.setAmount(neoamount);
        Patientcosts.setDeptid(neodeptid);
        Patientcosts.setCreatetime(neocreatetime);
        Patientcosts.setCreateoperid(neocreateoperid);
        Patientcosts.setPaytime(neopaytime);
        Patientcosts.setRegisterid(neoregisterid);
        Patientcosts.setFeetype(neofeetype);
        Patientcosts.setBackid(neobackid);
        Patientcosts.setType(neotype);
        Patientcosts.setState(neostate);

        //3.调用修改方法
        PatientcostsDao.addpatientcosts(Patientcosts);
        //4.跳转到成功
        findAll(request,response);


    }



    /**
     * 前端控制器-修改项目
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void updatepatientcost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        //1.获取客户端输入
        int id = Integer.parseInt(request.getParameter("id"));
        int neoregistid = Integer.parseInt(request.getParameter("registid"));
        int neoinvoiceid = Integer.parseInt(request.getParameter("invoiceid"));
        int neoitemid = Integer.parseInt(request.getParameter("itemid"));
        int neoitemtype = Integer.parseInt(request.getParameter("itemtype"));
        String neoname = request.getParameter("name");
        double neoprice = Double.parseDouble(request.getParameter("price"));
        double neoamount = Double.parseDouble(request.getParameter("amount"));
        int neodeptid = Integer.parseInt(request.getParameter("deptid"));
        String neocreatetime = request.getParameter("createtime");
        int neocreateoperid = Integer.parseInt(request.getParameter("createoperid"));
        String neopaytime = request.getParameter("paytime");
        int neoregisterid = Integer.parseInt(request.getParameter("registerid"));
        int neofeetype = Integer.parseInt(request.getParameter("feetype"));
        int neobackid = Integer.parseInt(request.getParameter("backid"));
        String neotype = request.getParameter("type");
        int neostate = Integer.parseInt(request.getParameter("state"));

        //创建对象
        patientcosts Patientcosts = new patientcosts();
        Patientcosts.setId(id);
        Patientcosts.setRegistid(neoregistid);
        Patientcosts.setInvoiceid(neoinvoiceid);
        Patientcosts.setItemid(neoitemid);
        Patientcosts.setItemtype(neoitemtype);
        Patientcosts.setName(neoname);
        Patientcosts.setPrice(neoprice);
        Patientcosts.setAmount(neoamount);
        Patientcosts.setDeptid(neodeptid);
        Patientcosts.setCreatetime(neocreatetime);
        Patientcosts.setCreateoperid(neocreateoperid);
        Patientcosts.setPaytime(neopaytime);
        Patientcosts.setRegisterid(neoregisterid);
        Patientcosts.setFeetype(neofeetype);
        Patientcosts.setBackid(neobackid);
        Patientcosts.setType(neotype);
        Patientcosts.setState(neostate);

        //3.调用修改方法
        PatientcostsDao.updatepatientcosts(Patientcosts);
        //4.跳转到显示
        findAll(request, response);
    }



    /**
     * 查询
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void findAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.调用访问方法
        List<patientcosts> Patientcost = PatientcostsDao.findAll();
        //2.跳转到显示界面
        request.setAttribute("PatientcostsObjs",Patientcost);
        request.getRequestDispatcher("/system/displaypatientcosts.jsp").forward(request,response);
    }

    /**
     * 根据编号查询
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    protected void findpatientscostsById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        //1.获取编号
        int neoid=Integer.parseInt(request.getParameter("neoid"));
        //2.调用根据编号查询
        patientcosts Patientcosts=PatientcostsDao.findpcByID(neoid);
        //3.转跳到修改显示页面
        request.setAttribute("pcobj",Patientcosts);
        request.getRequestDispatcher("/system/updatepatientcosts.jsp").forward(request,response);
    }


    /**
     * 删除
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     **/
     protected void deletepatientcostsById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        //1.获取编号
        int neoid=Integer.parseInt(request.getParameter("Nid"));
        //2.调用根据编号查询
        PatientcostsDao.deletepatientcosts(neoid);
        //3.转跳到修改显示页面
        findAll(request,response);
    }
    protected void addinput(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{

        List<Department> departments = departmentdao.findAll();
        List<Register> registers = registerDao.findAll();
        List<User> users = userdao.findAll();
        List<SettleCategory> settlecategorys = settlecategoryDao.findAll();
        List<Medicalrecord> medicalrecords = medicalrecordDao.findAll();
        request.setAttribute("registerObjs",registers);

        request.setAttribute("departmentObjs",departments);

        request.setAttribute("medicalrecordObjs", medicalrecords);

        //2.跳转到页面上
        request.setAttribute("settleCategorysObj",settlecategorys);
        request.setAttribute("userObjs",users);
        request.getRequestDispatcher("/system/addpatientcosts.jsp").forward(request,response);


    }


}
