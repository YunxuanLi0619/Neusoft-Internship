package com.example.dao;

import com.example.model.Department;
import com.example.model.User;
import com.example.util.DBCPUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * 数据库访问层--用户登录操作
 */
public class LoginDao {

    /**
     * 功能：查询用户登录信息
     * @return
     */
    public User findUser(String loginaccount,int role){
        User user= null;
        //1.获取数据库连接对象
        Connection connection =  DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql ="select id,username,password,realname " +
                "from tbl_user where username=? and usetype=?";
        try {
            pstmt = connection.prepareStatement(sql);
            pstmt.setString(1,loginaccount);
            pstmt.setInt(2,role);
            rs = pstmt.executeQuery();
            if(rs.next()){
                user =new User();
                int id= rs.getInt("id");
                String username = rs.getString("username");
                String password = rs.getString("password");
                String realname = rs.getString("realname");

                //每行记录封装为一个对象
                user.setId(id);
                user.setUsername(username);
                user.setPassword(password);
                user.setRealname(realname);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return user;
    }
}
