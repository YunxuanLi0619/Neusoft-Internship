package com.example.dao;

import com.example.model.patientcosts;
import com.example.util.DBCPUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * 数据库访问层--科室信息的增删改查操作
 */

public class patientcostsDao {
    /**
     * 添加科室操作
     * @param Patientcosts
     * @return
     */
    public boolean addpatientcosts(patientcosts Patientcosts){
        boolean flag = false;
        String sql ="insert into tbl_patientcosts(registid,invoiceid,itemid,itemtype,name,price,amount,deptid,createtime," +
                "createoperid,paytime,registerid,feetype,backid,type,state) " +
                "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        return DBCPUtil.execUpdate(sql,Patientcosts.getRegistid(),Patientcosts.getInvoiceid(), Patientcosts.getItemid()
                ,Patientcosts.getItemtype(),Patientcosts.getName(),Patientcosts.getPrice(),Patientcosts.getAmount(),
                Patientcosts.getDeptid(),Patientcosts.getCreatetime(),Patientcosts.getCreateoperid(),
                Patientcosts.getPaytime(),Patientcosts.getRegisterid(),Patientcosts.getFeetype(),Patientcosts.getBackid(),Patientcosts.getType(),Patientcosts.getState());

    }

    /**
     * 功能：根据科室编号修改科室信息
     * @param Patientcosts
     * @return
     */
    public boolean updatepatientcosts(patientcosts Patientcosts){
        boolean flag = false;
        String sql ="update tbl_patientcosts set state=? where id=?";
        flag = DBCPUtil.execUpdate(sql,Patientcosts.getState(),Patientcosts.getId());
        return flag;
    }


    /**
     * 功能：查询科室的所有信息
     * @return
     */
    public List<patientcosts> findAll(){
        List<patientcosts> patientcost = new ArrayList<>();
        //1.获取数据库连接对象
        Connection connection =  DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql ="select id,registid,invoiceid,itemid,itemtype,name,price,amount,deptid,createtime,createoperid," +
                "paytime,registerid,feetype,type,backid,state from tbl_patientcosts where state =0";
        try {
            pstmt = connection.prepareStatement(sql);
            rs = pstmt.executeQuery();
            patientcosts Patientcosts = null;
            while(rs.next()){
                Patientcosts = new patientcosts();
                int id = rs.getInt("id");
                int registid = rs.getInt("registid");
                int invoiceid = rs.getInt("invoiceid");
                int itemid = rs.getInt("itemid");
                int itemtype = rs.getInt("itemtype");
                String name = rs.getString("name");
                double price = rs.getDouble("price");
                double amount = rs.getDouble("amount");
                int deptid = rs.getInt("deptid");
                String createtime = rs.getString("createtime");
                int createoperid = rs.getInt("createoperid");
                String paytime = rs.getString("paytime");
                int registerid = rs.getInt("registerid");
                int feetype = rs.getInt("feetype");
                int backid = rs.getInt("backid");
                String type = rs.getString("type");
                int state = rs.getInt("state");


                //每行记录封装为一个对象
                Patientcosts.setId(id);
                Patientcosts.setRegistid(registid);
                Patientcosts.setInvoiceid(invoiceid);
                Patientcosts.setItemid(itemid);
                Patientcosts.setItemtype(itemtype);
                Patientcosts.setName(name);
                Patientcosts.setPrice(price);
                Patientcosts.setAmount(amount);
                Patientcosts.setDeptid(deptid);
                Patientcosts.setCreatetime(createtime);
                Patientcosts.setCreateoperid(createoperid);
                Patientcosts.setPaytime(paytime);
                Patientcosts.setRegisterid(registerid);
                Patientcosts.setFeetype(feetype);
                Patientcosts.setBackid(backid);
                Patientcosts.setType(type);
                Patientcosts.setState(state);

                //将对象添加到List集合中
                patientcost.add(Patientcosts);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return patientcost;
    }

    /**
     * 功能：根据科室编号删除科室信息
     * @param id
     * @return
     *
     * */
     public boolean deletepatientcosts(int id){
        boolean flag = false;
         String sql ="update tbl_patientcosts set state = 1 where id =?";
         flag = DBCPUtil.execUpdate(sql,id);
         return flag;
     }


    /**
     * 功能：根据主键查询科室信息
     * @param neoid
     * @return
     */
    public patientcosts findpcByID(int neoid){

        patientcosts Patientcosts = new patientcosts();        //1.获取数据库连接对象
        Connection connection =  DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql ="select id,registid,invoiceid,itemid,itemtype,name,price,amount,deptid,createtime,createoperid," +
                "paytime,registerid,feetype,backid,type,state from tbl_patientcosts where id=?";
        try {
            pstmt = connection.prepareStatement(sql);

            pstmt.setInt(1,neoid);

            rs = pstmt.executeQuery();

            if (rs.next()){

                int id = rs.getInt("id");
                int registid = rs.getInt("registid");
                int invoiceid = rs.getInt("invoiceid");
                int itemid = rs.getInt("itemid");
                int itemtype = rs.getInt("itemtype");
                String name = rs.getString("name");
                double price = rs.getDouble("price");
                double amount = rs.getDouble("amount");
                int deptid = rs.getInt("deptid");
                String createtime = rs.getString("createtime");
                int createoperid = rs.getInt("createoperid");
                String paytime = rs.getString("paytime");
                int registerid = rs.getInt("registerid");
                int feetype = rs.getInt("feetype");
                int backid = rs.getInt("backid");
                String type = rs.getString("type");
                int state = rs.getInt("state");

                //每行记录封装为一个对象
                Patientcosts.setId(id);
                Patientcosts.setRegistid(registid);
                Patientcosts.setInvoiceid(invoiceid);
                Patientcosts.setItemid(itemid);
                Patientcosts.setItemtype(itemtype);
                Patientcosts.setName(name);
                Patientcosts.setPrice(price);
                Patientcosts.setAmount(amount);
                Patientcosts.setDeptid(deptid);
                Patientcosts.setCreatetime(createtime);
                Patientcosts.setCreateoperid(createoperid);
                Patientcosts.setPaytime(paytime);
                Patientcosts.setRegisterid(registerid);
                Patientcosts.setFeetype(feetype);
                Patientcosts.setBackid(backid);
                Patientcosts.setType(type);
                Patientcosts.setState(state);


            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBCPUtil.release(connection,pstmt,rs);
        }
        return Patientcosts;
    }
}
