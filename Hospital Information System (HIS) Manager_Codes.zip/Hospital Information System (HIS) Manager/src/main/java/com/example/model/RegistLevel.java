package com.example.model;

public class RegistLevel {
    private Integer id;
    private String registcode;
    private String registname;
    private Integer sequenceno;
    private double registfee;
    private Integer registquota;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getRegistcode() {
        return registcode;
    }

    public void setRegistcode(String registcode) {
        this.registcode = registcode;
    }

    public String getRegistname() {
        return registname;
    }

    public void setRegistname(String registname) {
        this.registname = registname;
    }

    public Integer getSequenceno() {
        return sequenceno;
    }

    public void setSequenceno(Integer sequenceno) {
        this.sequenceno = sequenceno;
    }

    public double getRegistfee() {
        return registfee;
    }

    public void setRegistfee(double registfee) {
        this.registfee = registfee;
    }

    public Integer getRegistquota() {
        return registquota;
    }

    public void setRegistquota(Integer registquota) {
        this.registquota = registquota;
    }

    @Override
    public String toString() {
        return "RegistLevel{" +
                "id=" + id +
                ", registcode='" + registcode + '\'' +
                ", registname='" + registname + '\'' +
                ", sequenceno=" + sequenceno +
                ", registfee=" + registfee +
                ", registquota=" + registquota +
                '}';
    }
}
