package com.software.dao;

import com.example.dao.PrescriptiondetailedDao;
import com.example.model.Prescriptiondetailed;
import org.junit.jupiter.api.Test;

import java.util.List;

public class PDDTest {
    PrescriptiondetailedDao prescriptiondetailedDao = new PrescriptiondetailedDao();
    private Prescriptiondetailed[] PrescriptiondetailedList;


    /**
     * 单元测试--科室添加操作
     */
    @Test
    public void addMethod1(){
        //1.创建添加的科室测试用例
        Prescriptiondetailed prescriptiondetailed = new Prescriptiondetailed();
        prescriptiondetailed.setPrescriptionid(12);
        prescriptiondetailed.setDrugsid(12);
        prescriptiondetailed.setDrugsusage("口服");
        prescriptiondetailed.setDosage("一日一万粒");
        prescriptiondetailed.setFrequency("七日五次");
        prescriptiondetailed.setAmount(1.2);
        prescriptiondetailed.setState(5);

        //2.调用数据库访问层的方法实现添加操作
        boolean flag = PrescriptiondetailedDao.addPrescriptiondetailed(prescriptiondetailed);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    /**
     * 单元测试--科室信息的修改操作
     */
    @Test
    public void updatePrescriptiondetailed(){
        //1.创建修改科室测试用例
        Prescriptiondetailed prescriptiondetailed = new Prescriptiondetailed();
        prescriptiondetailed.setId(3);
        prescriptiondetailed.setState(5);


        //2.调用数据库访问层的方法实现添加操作

        boolean flag = PrescriptiondetailedDao.updatePrescriptiondetailed(prescriptiondetailed);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    /**
     * 单元测试--删除操作
     */


    @Test
    public void queryPrescriptiondetailed(){
        List<Prescriptiondetailed> PrescriptiondetailedList = PrescriptiondetailedDao.findAll();
        for(Prescriptiondetailed Prescriptiondetailed : PrescriptiondetailedList){
            System.out.println(Prescriptiondetailed);
        }
    }


}


