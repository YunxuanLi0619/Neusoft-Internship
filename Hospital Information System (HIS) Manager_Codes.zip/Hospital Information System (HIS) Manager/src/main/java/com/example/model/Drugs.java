
package com.example.model;

public class Drugs {
    private Integer id;
    private String drugscode;
    private String drugsname;
    private String drugsformat;
    private String drugsunit;
    private String manufacturer;
    private Integer drugsdosageid;
    private Integer drugstypeid;
    private double drugsprice;
    private String mnemoniccode;
    private String creationdate;
    private String lastupdatedate;
    private Integer delmark;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDrugscode() {
        return drugscode;
    }

    public void setDrugscode(String drugscode) {
        this.drugscode = drugscode;
    }

    public String getDrugsname() {
        return drugsname;
    }

    public void setDrugsname(String drugsname) {
        this.drugsname = drugsname;
    }

    public String getDrugsformat() {
        return drugsformat;
    }

    public void setDrugsformat(String drugsformat) {
        this.drugsformat = drugsformat;
    }

    public String getDrugsunit() {
        return drugsunit;
    }

    public void setDrugsunit(String drugsunit) {
        this.drugsunit = drugsunit;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public Integer getDrugsdosageid() {
        return drugsdosageid;
    }

    public void setDrugsdosageid(Integer drugsdosageid) {
        this.drugsdosageid = drugsdosageid;
    }

    public Integer getDrugstypeid() {
        return drugstypeid;
    }

    public void setDrugstypeid(Integer drugstypeid) {
        this.drugstypeid = drugstypeid;
    }



    public String getMnemoniccode() {
        return mnemoniccode;
    }

    public void setMnemoniccode(String mnemoniccode) {
        this.mnemoniccode = mnemoniccode;
    }

    public String getCreationdate() {
        return creationdate;
    }

    public void setCreationdate(String creationdate) {
        this.creationdate = creationdate;
    }

    public String getLastupdatedate() {
        return lastupdatedate;
    }

    public void setLastupdatedate(String lastupdatedate) {
        this.lastupdatedate = lastupdatedate;
    }

    public Integer getDelmark() {
        return delmark;
    }

    public void setDelmark(Integer delmark) {
        this.delmark = delmark;
    }

    public double getDrugsprice() {
        return drugsprice;
    }

    public void setDrugsprice(double drugsprice) {
        this.drugsprice = drugsprice;
    }

    @Override
    public String toString() {
        return "Drugs{" +
                "id=" + id +
                ", drugscode='" + drugscode + '\'' +
                ", drugsname='" + drugsname + '\'' +
                ", drugsformat='" + drugsformat + '\'' +
                ", drugsunit='" + drugsunit + '\'' +
                ", manufacturer='" + manufacturer + '\'' +
                ", drugsdosageid=" + drugsdosageid +
                ", drugstypeid=" + drugstypeid +
                ", drugsprice=" + drugsprice +
                ", mnemoniccode='" + mnemoniccode + '\'' +
                ", creationdate='" + creationdate + '\'' +
                ", lastupdatedate='" + lastupdatedate + '\'' +
                ", delmark=" + delmark +
                '}';
    }
}