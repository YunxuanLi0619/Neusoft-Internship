package com.software.dao;

import com.example.dao.ConstantItemDao;
import com.example.model.ConstantItem;
import org.junit.jupiter.api.Test;

import java.util.List;
public class ConstantItemDaoTest {
    //创建数据库访问层对象
    ConstantItemDao constantitemdao = new ConstantItemDao();

    /**
     * 单元测试--科室添加操作          id,constanttypeid,constantcode,constantname ,delmark
     */
    @Test
    public void addMethod1(){
        //1.创建添加的科室测试用例
        ConstantItem  constantitem = new  ConstantItem();
        constantitem.setConstanttypeid(1);
        constantitem.setConstantcode("SURGERY");
        constantitem.setConstantname("外科");


        //2.调用数据库访问层的方法实现添加操作
        boolean flag = constantitemdao.addConstantItem(constantitem);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    /**
     * 单元测试--科室信息的修改操作
     */
    @Test
    public void updateMethod(){
        //1.创建修改科室测试用例
        ConstantItem constantitem = new ConstantItem();
        constantitem.setId(27);
        constantitem.setConstanttypeid(5);
        constantitem.setConstantcode("MALE");
        constantitem.setConstantname("男");

        //2.调用数据库访问层的方法实现添加操作
        boolean flag = constantitemdao.updateConstantItem(constantitem);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    /**
     * 单元测试--删除操作
     */
    @Test
    public void deleteMethod(){
        boolean flag = constantitemdao.deleteConstantItem(5);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    @Test
    public void queryMethod(){
        List<ConstantItem> constantitemList =  constantitemdao.findAll();
        for(ConstantItem constantitem : constantitemList){
            System.out.println(constantitem);
        }
    }


}
