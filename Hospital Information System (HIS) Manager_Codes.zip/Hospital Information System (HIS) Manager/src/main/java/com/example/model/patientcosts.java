package com.example.model;

public class patientcosts {
    // id ，registid ，invoiceid ,itemid , itemtype , name , price , amount , deptid , createtime , createoperid , paytime , registerid, feetype, backid
    private  Integer id;
    private  Integer registid;
    private  Integer invoiceid;
    private  Integer itemid;
    private  Integer itemtype;
    private  String name;
    private  Double price;
    private  Double amount;
    private Integer deptid;
    private String createtime;
    private  Integer createoperid;
    private  String paytime;
    private  Integer registerid;
    private  Integer feetype;
    private  Integer backid;
    private  String type;
    private  Integer state;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getRegistid() {
        return registid;
    }

    public void setRegistid(Integer registid) {
        this.registid = registid;
    }

    public Integer getInvoiceid() {
        return invoiceid;
    }

    public void setInvoiceid(Integer invoiceid) {
        this.invoiceid = invoiceid;
    }

    public Integer getItemid() {
        return itemid;
    }

    public void setItemid(Integer itemid) {
        this.itemid = itemid;
    }

    public Integer getItemtype() {
        return itemtype;
    }

    public void setItemtype(Integer itemtype) {
        this.itemtype = itemtype;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public Integer getDeptid() {
        return deptid;
    }

    public void setDeptid(Integer deptid) {
        this.deptid = deptid;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public Integer getCreateoperid() {
        return createoperid;
    }

    public void setCreateoperid(Integer createoperid) {
        this.createoperid = createoperid;
    }

    public String getPaytime() {
        return paytime;
    }

    public void setPaytime(String paytime) {
        this.paytime = paytime;
    }

    public Integer getRegisterid() {
        return registerid;
    }

    public void setRegisterid(Integer registerid) {
        this.registerid = registerid;
    }

    public Integer getFeetype() {
        return feetype;
    }

    public void setFeetype(Integer feetype) {
        this.feetype = feetype;
    }

    public Integer getBackid() {
        return backid;
    }

    public void setBackid(Integer backid) {
        this.backid = backid;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    @Override
    public String toString() {
        return "patientcosts{" +
                "id=" + id +
                ", registid=" + registid +
                ", invoiceid=" + invoiceid +
                ", itemid=" + itemid +
                ", itemtype=" + itemtype +
                ", name='" + name + '\'' +
                ", price=" + price +
                ", amount=" + amount +
                ", deptid=" + deptid +
                ", createtime='" + createtime + '\'' +
                ", createoperid=" + createoperid +
                ", paytime='" + paytime + '\'' +
                ", registerid=" + registerid +
                ", feetype=" + feetype +
                ", backid=" + backid +
                ", type='" + type + '\'' +
                ", state=" + state +
                '}';
    }
}
