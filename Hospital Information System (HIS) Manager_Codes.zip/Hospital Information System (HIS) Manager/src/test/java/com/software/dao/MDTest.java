package com.software.dao;

import com.example.dao.MedicalrecordDao;
import com.example.model.Medicalrecord;
import org.junit.jupiter.api.Test;

import java.util.List;

public class MDTest {
    Medicalrecord medicalrecord = new Medicalrecord();


    /**
     * 单元测试--科室添加操作
     */
    @Test
    public void addMethod1(){
        //1.创建添加的科室测试用例
        Medicalrecord medicalrecord = new Medicalrecord();
        medicalrecord.setCasenumber("11");
        medicalrecord.setRegistid(11);
        medicalrecord.setReadme("肝疼");
        medicalrecord.setPresent("肝疼");
        medicalrecord.setPresenttreat("肝脏恢复正常");
        medicalrecord.setHistory("无");
        medicalrecord.setAllergy("无");
        medicalrecord.setDiagnosis("玩原神玩的");
        medicalrecord.setHandling("建议玩玩星铁");
        medicalrecord.setCasestate(3);

        //2.调用数据库访问层的方法实现添加操作
        boolean flag = MedicalrecordDao.addMedicalrecord(medicalrecord);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    /**
     * 单元测试--科室信息的修改操作
     */
    @Test
    public void updateMedicalrecord(){
        //1.创建修改科室测试用例
        Medicalrecord medicalrecord = new Medicalrecord();
        medicalrecord.setId(6);
        medicalrecord.setCasestate(2);


        //2.调用数据库访问层的方法实现添加操作

        boolean flag = MedicalrecordDao.updateMedicalrecord(medicalrecord);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    /**
     * 单元测试--删除操作
     */


    @Test
    public void queryMedicalrecord(){
        List<Medicalrecord> MedicalrecordList = MedicalrecordDao.findAll();
        for(Medicalrecord Medicalrecord : MedicalrecordList){
            System.out.println(Medicalrecord);
        }
    }


}
