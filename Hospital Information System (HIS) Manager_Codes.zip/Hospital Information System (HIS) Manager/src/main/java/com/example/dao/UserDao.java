package com.example.dao;

import com.example.model.User;

import com.example.util.DBCPUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserDao {

    /**
     * 添加科室操作
     *
     * @param user private Integer id;
     *             private String settlecode;
     *             private String settlename;
     *             private Integer sequenceno;
     *             private Integer delmark;
     * @return
     */
    public boolean addUser(User user) {
        boolean flag = false;
        String sql = "insert into tbl_user(username,password,realname,usetype,doctitleid,deptid,registleid) " +
                "values(?,?,?,?,?,?,?)";
        return DBCPUtil.execUpdate(sql, user.getUsername(), user.getPassword(),
                user.getRealname(), user.getUsetype(), user.getDoctitleid(), user.getDeptid(), user.getRegistleid());
    }

    /**
     * 功能：根据科室编号修改科室信息
     *
     * @param user
     * @return
     */
    public boolean updateUser(User user) {
        boolean flag = false;
        String sql = "update tbl_user set username=?,password=?,realname=?,usetype=?,doctitleid=?,deptid=?,registleid=? where id=?";
        flag = DBCPUtil.execUpdate(sql, user.getUsername(), user.getPassword(),
                user.getRealname(), user.getUsetype(), user.getDoctitleid(), user.getDeptid(), user.getRegistleid(), user.getId());
        return flag;
    }

    /**
     * 功能：根据科室编号删除科室信息
     *
     * @param id
     * @return
     */
    public boolean deleteUser(int id) {
        boolean flag = false;
        String sql = "delete from tbl_user where id =?";
        flag = DBCPUtil.execUpdate(sql, id);
        return flag;
    }

    /**
     * 功能：查询科室的所有信息
     *
     * @return
     */
    public List<User> findAll() {
        List<User> users = new ArrayList<>();
        //1.获取数据库连接对象
        Connection connection = DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = "select id,username,password,realname,usetype,doctitleid,deptid,registleid from tbl_user ";
        try {
            pstmt = connection.prepareStatement(sql);
            rs = pstmt.executeQuery();
            User user = null;
            while (rs.next()) {
                user = new User();
                int id = rs.getInt("id");
                String username = rs.getString("username");
                String password = rs.getString("password");
                String realname = rs.getString("realname");
                int usetype = rs.getInt("usetype");
                int doctitleid = rs.getInt("doctitleid");
                int deptid = rs.getInt("deptid");
                int registleid = rs.getInt("registleid");


                //每行记录封装为一个对象
                user.setId(id);
                user.setUsername(username);
                user.setRealname(realname);
                user.setPassword(password);
                user.setUsetype(usetype);
                user.setDoctitleid(doctitleid);
                user.setDeptid(deptid);
                user.setRegistleid(registleid);



                //将对象添加到List集合中
                users.add(user);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBCPUtil.release(connection, pstmt, rs);
        }
        return users;
    }


    /**
     * 功能：查询科室的所有信息
     *
     * @return
     */
    public User findUserByID(int userid) {
        User user = new User();
        //1.获取数据库连接对象
        Connection connection = DBCPUtil.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String sql = "select id,username,password,realname,usetype,doctitleid,deptid,registleid from tbl_user where  id=?";
        try {
            pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1, userid);
            rs = pstmt.executeQuery();

            if (rs.next()) {

                int id = rs.getInt("id");
                String username = rs.getString("username");
                String password = rs.getString("password");
                String realname = rs.getString("realname");
                int usetype = rs.getInt("usetype");
                int doctitleid = rs.getInt("doctitleid");
                int deptid = rs.getInt("deptid");
                int registleid = rs.getInt("registleid");


                //每行记录封装为一个对象
                user.setId(id);
                user.setUsername(username);
                user.setRealname(realname);
                user.setPassword(password);
                user.setUsetype(usetype);
                user.setDoctitleid(doctitleid);
                user.setDeptid(deptid);
                user.setRegistleid(registleid);



                //将对象添加到List集合中


            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBCPUtil.release(connection, pstmt, rs);
        }
        return user;
    }
}

