package com.example.servlet;

import com.example.dao.expenseclassDao;
import com.example.dao.fmeditemDao;
import com.example.model.Department;
import com.example.dao.DepartmentDao;
import com.example.model.DiseCategory;
import com.example.model.expenseclass;
import com.example.model.fmeditem;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "FmeditemServlet", value = "/FmeditemServlet")
public class FmeditemServlet extends HttpServlet {

    fmeditemDao fmeditemDao = new fmeditemDao();
    expenseclassDao ExpenseclassDao = new expenseclassDao();
    DepartmentDao departmentdao = new DepartmentDao();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request,response);

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        execute(request,response);

    }

    protected void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String methodname = request.getParameter("method");
        if ("addmethod".equals(methodname)) {
            addFmeditem(request, response);
        } else if ("updatemethod".equals(methodname)) {
            updateFmeditem(request, response);
        } else if ("deletemethod".equals(methodname)) {
            deleteFmeditemById(request,response);

        } else if ("findid".equals(methodname)) {
            findFmeditemById(request,response);


        }else if("addinput".equals(methodname)){

            addinput(request,response);
        }else{
            findAll(request, response);
        }
    }

    protected void addFmeditem(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String itemcode = request.getParameter("itemcode");
        String itemname = request.getParameter("itemname");
        String format = request.getParameter("format");
        Double price = Double.valueOf(request.getParameter("price"));
        int expclassid = Integer.parseInt(request.getParameter("expclassid"));
        int deptid = Integer.parseInt(request.getParameter("deptid"));
        String mnemoniccode = request.getParameter("mnemoniccode");
        String creationdate = request.getParameter("creationdate");
        String lastupdatedate = request.getParameter("lastupdatedate");
        int recordtype = Integer.parseInt(request.getParameter("recordtype"));


        fmeditem fmeditem = new fmeditem();
        fmeditem.setItemcode(itemcode);
        fmeditem.setItemname(itemname);
        fmeditem.setFormat(format);
        fmeditem.setPrice(price);
        fmeditem.setExpclassid(expclassid);
        fmeditem.setDeptid(deptid);
        fmeditem.setMnemoniccode(mnemoniccode);
        fmeditem.setCreationdate(creationdate);
        fmeditem.setLastupdatedate(lastupdatedate);
        fmeditem.setRecordtype(recordtype);


        fmeditemDao.addfmeditem(fmeditem);

       findAll(request,response);


    }

    protected void updateFmeditem(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        int id =Integer.parseInt(request.getParameter("id"));
        String itemcode = request.getParameter("itemcode");
        String itemname = request.getParameter("itemname");
        String format = request.getParameter("format");
        Double price = Double.valueOf(request.getParameter("price"));
        int expclassid = Integer.parseInt(request.getParameter("expclassid"));
        int deptid = Integer.parseInt(request.getParameter("deptid"));
        String mnemoniccode = request.getParameter("mnemoniccode");
        String creationdate = request.getParameter("creationdate");
        String lastupdatedate = request.getParameter("lastupdatedate");
        int recordtype = Integer.parseInt(request.getParameter("recordtype"));

        fmeditem fmeditem = new fmeditem();
        fmeditem.setId(id);
        fmeditem.setItemcode(itemcode);
        fmeditem.setItemname(itemname);
        fmeditem.setFormat(format);
        fmeditem.setPrice(price);
        fmeditem.setExpclassid(expclassid);
        fmeditem.setDeptid(deptid);
        fmeditem.setMnemoniccode(mnemoniccode);
        fmeditem.setCreationdate(creationdate);
        fmeditem.setLastupdatedate(lastupdatedate);
        fmeditem.setRecordtype(recordtype);


        fmeditemDao.updatefmeditem(fmeditem);

        findAll(request,response);


    }

    protected void findAll(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<fmeditem> fmeditems = fmeditemDao.findAll();
        request.setAttribute("fmeditemObjs", fmeditems);
        request.getRequestDispatcher("/system/displayfmeditem.jsp").forward(request, response);
    }

    protected void findFmeditemById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        int fmeditemid = Integer.parseInt(request.getParameter("fmeditemid"));
        fmeditem fmeditem = fmeditemDao.findFmeditemById(fmeditemid);
        request.setAttribute("fmeditemObj", fmeditem);
        List<expenseclass> expenseclasses = ExpenseclassDao.findAll();
        List<Department> departments = departmentdao.findAll();
        request.setAttribute("departmentObjs",departments);
        request.setAttribute("expenseclassObjs",expenseclasses);
        request.getRequestDispatcher("/system/updatefmeditem.jsp").forward(request, response);
    }

    protected void deleteFmeditemById(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int fmeditemid = Integer.parseInt(request.getParameter("fid"));
        fmeditemDao.deletefmeditem(fmeditemid);
        findAll(request, response);
    }

    protected void addinput(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        List<expenseclass> expenseclasses = ExpenseclassDao.findAll();
        List<Department> departments = departmentdao.findAll();
        request.setAttribute("departmentObjs",departments);
        request.setAttribute("expenseclassObjs",expenseclasses);
        request.getRequestDispatcher("/system/addfmeditem.jsp").forward(request,response);




    }




}





