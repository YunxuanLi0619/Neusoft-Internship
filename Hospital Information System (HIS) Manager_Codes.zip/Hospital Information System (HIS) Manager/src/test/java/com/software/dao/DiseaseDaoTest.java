package com.software.dao;

import com.example.dao.DiseaseDao;
import com.example.model.Disease;
import org.junit.jupiter.api.Test;

import java.util.List;

/**
 * 单元测试：科室数据库访问层连接数据库实现添加、修改、删除、查询的操作
 */
public class DiseaseDaoTest {

    //创建数据库访问层对象
    DiseaseDao diseaseDao = new DiseaseDao();

    /**
     * 单元测试--科室添加操作
     */
    @Test
    public void addMethod1(){
        //1.创建添加的科室测试用例
        Disease disease = new Disease();
        disease.setDiseasecode("SJ1002");
        disease.setDiseasename("神经科2");
        disease.setDiseaseicd("1");
        disease.setDiseasecategory(111);


        //2.调用数据库访问层的方法实现添加操作
        boolean flag = diseaseDao.addDisease(disease);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    /**
     * 单元测试--科室信息的修改操作
     */
    @Test
    public void updateDisease(){
        //1.创建修改科室测试用例
        Disease disease = new Disease();
        disease.setId(9);
        disease.setDiseasecode("FS1002");
        disease.setDiseasename("放射科2");
        disease.setDiseaseicd("11");
        disease.setDiseasecategory(11);


        //2.调用数据库访问层的方法实现添加操作
        boolean flag = diseaseDao.updateDisease(disease);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    /**
     * 单元测试--删除操作
     */
    @Test
    public void deleteMethod(){
        boolean flag = diseaseDao.deleteDisease(10);
        if(flag){
            System.out.println("success");
        }else{
            System.out.println("failure");
        }
    }

    @Test
    public void queryDisease(){
        List<Disease> diseaseList =  diseaseDao.findAll();
        for(Disease disease : diseaseList){
            System.out.println(disease);
        }
    }


}
